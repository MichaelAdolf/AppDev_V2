import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from stockmind.application.portfolio.add_position_use_case import AddPositionUseCase
from stockmind.application.portfolio.delete_portfolio_use_cases import DeletePurchaseLotUseCase
from stockmind.infrastructure.portfolio.portfolio_repository import PortfolioRepository
class PortfolioLotsTest(unittest.TestCase):
 def test_two_buys_are_one_aggregated_position_and_lot_can_be_deleted(self):
  with tempfile.TemporaryDirectory() as tmp:
   db=str(Path(tmp)/'p.db');comparison=type('C',(),{'entries':[]})()
   with patch('stockmind.application.portfolio.add_position_use_case.WatchlistRepository') as w,patch('stockmind.application.portfolio.add_position_use_case.ProfileComparisonDashboardUseCase') as p:
    w.return_value.load_all.return_value=[];p.return_value.load.return_value=comparison
    _,l1=AddPositionUseCase(db).execute('NVDA','2026-10-01',100,10,5)
    _,l2=AddPositionUseCase(db).execute('NVDA','2026-10-10',110,5,4)
   repo=PortfolioRepository(db);positions=repo.load_open_positions();self.assertEqual(len(positions),1);self.assertEqual(positions[0].quantity,15);self.assertAlmostEqual(positions[0].purchase_price,103.333333,places=5);self.assertEqual(positions[0].purchase_fees,9)
   DeletePurchaseLotUseCase(db).execute(l2.id);positions=repo.load_open_positions();self.assertEqual(positions[0].quantity,10);self.assertEqual(len(repo.load_lots_for_position(positions[0].id)),1)
if __name__=='__main__':unittest.main()
