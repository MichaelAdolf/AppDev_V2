# Sprint P1.1 Portfolio Lots & Corrections

- Mehrere Käufe desselben Symbols werden als Kauftranchen in einer offenen Position kumuliert.
- Gewichteter Kaufkurs und Gesamtgebühren werden aus den Tranchen berechnet.
- Bestehende P1-Positionen werden idempotent zu Initialtranchen migriert.
- Tranchen können bearbeitet oder gelöscht werden.
- Wird die letzte Tranche gelöscht, wird die leere offene Position entfernt.
- Offene Positionen und fehlerhafte abgeschlossene Trades können administrativ gelöscht werden.
- Löschen ist kein Verkauf und erzeugt keinen Trade.
- Vollständiger Verkauf arbeitet mit kumulierter Stückzahl, gewichtetem Kaufkurs und allen Kaufgebühren.
- Teilverkäufe und Nachkaufszuordnung bleiben bewusst außerhalb dieses Sprints.

Test:
`python -m unittest tests.test_portfolio_lots tests.test_portfolio_foundation`

Vor Deployment DB sichern und Add-on-Patchversion erhöhen.
