# StockMind Sprint P1: Portfolio Foundation

## Funktionsumfang

- Offene Position manuell erfassen
- Entry-Snapshot aus dem gewählten StockMind-Profil speichern
- Offene Positionen mit aktuellem DB-Kurs, Marktwert, P/L und +8-%-Ziel anzeigen
- Position vollständig schließen
- Bruttoergebnis, Gebührenergebnis und Nettoergebnis nach manuell erfasster Steuer speichern
- Trade History
- Performance für Monat, sechs Monate, laufendes Jahr, zwölf Monate und Gesamt
- Portfolio API Router

## Bewusste Grenzen

- Keine Teilverkäufe
- Keine Nachkäufe oder Durchschnittseinstand
- Keine automatische Steuerberechnung
- Noch keine automatische Exit Engine
- Broker-Ausführung bleibt manuell

## API integrieren

In `api/stockmind_api.py` ergänzen:

```python
from api.portfolio_api_router import router as portfolio_router
```

Nach der FastAPI-Initialisierung ergänzen:

```python
app.include_router(portfolio_router)
```

Danach stehen bereit:

```text
GET  /portfolio
GET  /portfolio/performance
POST /portfolio/positions
POST /portfolio/positions/{position_id}/sell
```

## Test

```powershell
python -m unittest tests.test_portfolio_foundation
```

## Deployment

Alle neuen Ordner unter `src/stockmind` sowie `api/portfolio_api_router.py`, die neue
`ui/components/portfolio_view.py` und den Test übernehmen. Die Portfolio-Tabellen
werden beim ersten Repositoryzugriff automatisch in der bestehenden SQLite-DB angelegt.
Vor dem Raspberry-Upgrade ein Datenbankbackup erstellen und die Add-on-Patchversion erhöhen.
