from datetime import date

import pandas as pd
import streamlit as st

from stockmind.application.portfolio.add_position_use_case import AddPositionUseCase
from stockmind.application.portfolio.portfolio_dashboard_use_case import PortfolioDashboardUseCase
from stockmind.application.portfolio.portfolio_performance_use_case import PortfolioPerformanceUseCase
from stockmind.application.portfolio.sell_position_use_case import SellPositionUseCase
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository


def _money(value):
    return "–" if value is None else f"{value:,.2f} €"


def render():
    result = PortfolioDashboardUseCase().load()
    st.subheader("Portfolio")
    st.caption("Manuell erfasste Positionen und abgeschlossene Trades. Käufe und Verkäufe werden weiterhin in deiner Broker-App ausgeführt.")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Investiert", _money(result.invested_amount))
    c2.metric("Marktwert", _money(result.market_value))
    c3.metric("Unrealisiert", _money(result.unrealized_profit))
    c4.metric("Realisiert netto", _money(result.realized_net_profit))

    open_tab, add_tab, sell_tab, history_tab, performance_tab = st.tabs([
        "Offene Positionen", "Position hinzufügen", "Position verkaufen",
        "Trade History", "Performance",
    ])

    with open_tab:
        if not result.positions:
            st.info("Noch keine offenen Positionen vorhanden.")
        else:
            rows = []
            for item in result.positions:
                p = item.position
                rows.append({
                    "Aktie": f"{p.company_name} ({p.symbol})",
                    "Kaufdatum": p.purchase_date,
                    "Stück": p.quantity,
                    "Einstand": p.purchase_price,
                    "Aktuell": item.current_price,
                    "Investiert €": round(item.invested_amount, 2),
                    "Marktwert €": round(item.market_value, 2) if item.market_value is not None else None,
                    "P/L €": round(item.unrealized_profit, 2) if item.unrealized_profit is not None else None,
                    "P/L %": round(item.unrealized_return_pct * 100, 2) if item.unrealized_return_pct is not None else None,
                    "+8 % Ziel": round(item.target_price, 2),
                    "Abstand %": round(item.target_distance_pct * 100, 2) if item.target_distance_pct is not None else None,
                    "Tage": item.holding_days,
                    "Profil": p.entry_profile,
                    "Signal": item.current_signal,
                    "Score": item.current_score,
                })
            st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)

    with add_tab:
        watchlist = [x for x in WatchlistRepository().load_all() if x.active]
        if not watchlist:
            st.warning("Die Watchlist enthält keine aktiven Aktien.")
        else:
            labels = {f"{x.company_name} ({x.symbol})": x.symbol for x in watchlist}
            with st.form("add_portfolio_position"):
                label = st.selectbox("Aktie", list(labels))
                purchase_date = st.date_input("Kaufdatum", value=date.today())
                col1, col2, col3 = st.columns(3)
                purchase_price = col1.number_input("Kaufpreis", min_value=0.01, step=0.01)
                quantity = col2.number_input("Stückzahl", min_value=0.0001, step=1.0, format="%.4f")
                purchase_fees = col3.number_input("Kaufgebühren", min_value=0.0, step=0.01)
                entry_profile = st.selectbox("Entry-Profil", ["conservative", "balanced", "aggressive"], index=1)
                note = st.text_area("Notiz", value="")
                submitted = st.form_submit_button("Position hinzufügen", type="primary")
            if submitted:
                try:
                    AddPositionUseCase().execute(
                        symbol=labels[label], purchase_date=purchase_date,
                        purchase_price=purchase_price, quantity=quantity,
                        purchase_fees=purchase_fees,
                        entry_profile=entry_profile, note=note,
                    )
                    st.success("Position wurde hinzugefügt.")
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))

    with sell_tab:
        if not result.positions:
            st.info("Keine offene Position zum Verkaufen vorhanden.")
        else:
            choices = {
                f"{x.position.company_name} ({x.position.symbol}) · {x.position.quantity:g} Stück": x.position.id
                for x in result.positions
            }
            with st.form("sell_portfolio_position"):
                label = st.selectbox("Position", list(choices))
                sale_date = st.date_input("Verkaufsdatum", value=date.today())
                col1, col2, col3 = st.columns(3)
                sale_price = col1.number_input("Verkaufspreis", min_value=0.01, step=0.01)
                sale_fees = col2.number_input("Verkaufsgebühren", min_value=0.0, step=0.01)
                tax_paid = col3.number_input("Tatsächlich belastete Steuer", min_value=0.0, step=0.01)
                exit_reason = st.selectbox("Exit-Grund", ["MANUAL", "TARGET_REACHED", "TIME_LIMIT", "STOP_LOSS", "SIGNAL_DETERIORATION"])
                note = st.text_area("Verkaufsnotiz", value="")
                submitted = st.form_submit_button("Position vollständig verkaufen", type="primary")
            if submitted:
                try:
                    trade = SellPositionUseCase().execute(
                        position_id=choices[label], sale_date=sale_date,
                        sale_price=sale_price, sale_fees=sale_fees,
                        tax_paid=tax_paid, exit_reason=exit_reason, note=note,
                    )
                    st.success(f"Trade abgeschlossen. Nettoergebnis: {_money(trade.net_profit)}")
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))

    with history_tab:
        if not result.trades:
            st.info("Noch keine abgeschlossenen Trades vorhanden.")
        else:
            st.dataframe(pd.DataFrame([{
                "Aktie": f"{t.company_name} ({t.symbol})",
                "Kauf": t.purchase_date,
                "Verkauf": t.sale_date,
                "Stück": t.quantity,
                "Kaufkurs": t.purchase_price,
                "Verkaufskurs": t.sale_price,
                "Brutto €": round(t.gross_profit, 2),
                "Nach Gebühren €": round(t.profit_after_fees, 2),
                "Steuer €": round(t.tax_paid, 2),
                "Netto €": round(t.net_profit, 2),
                "Netto %": round(t.net_return_pct * 100, 2),
                "Tage": t.holding_days,
                "Profil": t.entry_profile,
                "Exit": t.exit_reason,
            } for t in result.trades]), width="stretch", hide_index=True)

    with performance_tab:
        perf = PortfolioPerformanceUseCase().load()
        labels = {"month": "Dieser Monat", "six_months": "Letzte 6 Monate", "ytd": "Seit 01.01.", "twelve_months": "Letzte 12 Monate", "all": "Gesamt"}
        rows = []
        for key, label in labels.items():
            item = perf[key]
            rows.append({
                "Zeitraum": label,
                "Trades": item["trade_count"],
                "Gewinner": item["winner_count"],
                "Win Rate %": round(item["win_rate"] * 100, 2),
                "Brutto €": round(item["gross_profit"], 2),
                "Nach Gebühren €": round(item["profit_after_fees"], 2),
                "Steuer €": round(item["tax_paid"], 2),
                "Netto €": round(item["net_profit"], 2),
                "Ø Haltedauer": round(item["average_holding_days"], 1),
            })
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)
