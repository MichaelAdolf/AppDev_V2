from datetime import datetime
from uuid import uuid4

from stockmind.application.dashboard.use_cases.profile_comparison_dashboard_use_case import ProfileComparisonDashboardUseCase
from stockmind.domain.portfolio.portfolio_position import PortfolioPosition
from stockmind.infrastructure.portfolio.portfolio_repository import PortfolioRepository
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository


class AddPositionUseCase:
    def __init__(self, database_path: str | None = None):
        self._repository = PortfolioRepository(database_path)

    def execute(self, symbol, purchase_date, purchase_price, quantity,
                purchase_fees=0.0, entry_profile="balanced", note=""):
        symbol = symbol.upper().strip()
        if purchase_price <= 0 or quantity <= 0:
            raise ValueError("Kaufpreis und Stückzahl müssen größer als 0 sein.")
        if purchase_fees < 0:
            raise ValueError("Kaufgebühren dürfen nicht negativ sein.")

        watch = next(
            (x for x in WatchlistRepository().load_all() if x.symbol.upper() == symbol),
            None,
        )
        company_name = watch.company_name if watch else symbol
        comparison = ProfileComparisonDashboardUseCase().load(symbol, "5y", 3)
        selected = next(
            (x for x in comparison.entries if x.profile_name == entry_profile),
            None,
        )
        buy_count = len({
            x.profile_name for x in comparison.entries
            if x.signal == "BUY" or x.current_buy_signal is True
        })
        now = datetime.now().isoformat(timespec="seconds")
        position = PortfolioPosition(
            id=str(uuid4()), symbol=symbol, company_name=company_name,
            purchase_date=str(purchase_date), purchase_price=float(purchase_price),
            quantity=float(quantity), purchase_fees=float(purchase_fees),
            entry_profile=entry_profile,
            entry_signal=("BUY" if selected and selected.current_buy_signal is True else selected.signal if selected else None),
            entry_opportunity_score=selected.score if selected else None,
            entry_confidence=selected.confidence if selected else None,
            entry_risk=selected.risk_level if selected else None,
            entry_target_hit_rate=selected.target_hit_rate if selected else None,
            entry_sample_count=selected.complete_period_count if selected else 0,
            entry_profile_buy_count=buy_count,
            entry_buy_period_start=selected.active_period_start if selected else None,
            note=note.strip(), status="OPEN", created_at=now, updated_at=now,
        )
        self._repository.add_position(position)
        return position
