from datetime import date

from stockmind.application.portfolio.models.portfolio_dashboard_result import PortfolioDashboardResult, PortfolioPositionView
from stockmind.infrastructure.history.chart_data_repository import ChartDataRepository
from stockmind.infrastructure.history.latest_analysis_repository import LatestAnalysisRepository
from stockmind.infrastructure.portfolio.portfolio_repository import PortfolioRepository


class PortfolioDashboardUseCase:
    def __init__(self, database_path: str | None = None):
        self._database_path = database_path

    def load(self) -> PortfolioDashboardResult:
        portfolio = PortfolioRepository(self._database_path)
        chart = ChartDataRepository(self._database_path)
        latest_by_profile = {
            profile: {x.symbol.upper(): x for x in LatestAnalysisRepository(self._database_path).load_all(profile)}
            for profile in ("conservative", "balanced", "aggressive")
        }
        views = []
        for position in portfolio.load_open_positions():
            points = chart.load_by_symbol(position.symbol)
            current_price = points[-1].close_price if points else None
            invested = position.purchase_price * position.quantity + position.purchase_fees
            market_value = current_price * position.quantity if current_price is not None else None
            unrealized = market_value - invested if market_value is not None else None
            return_pct = unrealized / invested if unrealized is not None and invested else None
            target_price = position.purchase_price * 1.08
            distance = (target_price / current_price - 1.0) if current_price else None
            current = latest_by_profile.get(position.entry_profile, {}).get(position.symbol.upper())
            views.append(PortfolioPositionView(
                position=position, current_price=current_price,
                market_value=market_value, invested_amount=invested,
                unrealized_profit=unrealized, unrealized_return_pct=return_pct,
                target_price=target_price, target_distance_pct=distance,
                holding_days=(date.today() - date.fromisoformat(position.purchase_date)).days,
                current_signal=current.signal if current else None,
                current_score=current.opportunity_score if current else None,
                current_confidence=current.confidence if current else None,
                current_risk=current.risk_level if current else None,
            ))
        trades = portfolio.load_trades()
        return PortfolioDashboardResult(
            positions=views, trades=trades,
            invested_amount=sum(x.invested_amount for x in views),
            market_value=sum(x.market_value or 0.0 for x in views),
            unrealized_profit=sum(x.unrealized_profit or 0.0 for x in views),
            realized_net_profit=sum(x.net_profit for x in trades),
        )
