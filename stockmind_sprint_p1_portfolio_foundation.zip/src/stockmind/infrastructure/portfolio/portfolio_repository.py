import sqlite3

from stockmind.domain.portfolio.portfolio_position import PortfolioPosition
from stockmind.domain.portfolio.portfolio_trade import PortfolioTrade
from stockmind.shared.config.settings import Settings


class PortfolioRepository:
    def __init__(self, database_path: str | None = None):
        self._database_path = database_path or Settings.load().database_path
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(self._database_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self):
        connection = self._connect()
        try:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS portfolio_positions (
                    id TEXT PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    company_name TEXT NOT NULL,
                    purchase_date TEXT NOT NULL,
                    purchase_price REAL NOT NULL,
                    quantity REAL NOT NULL,
                    purchase_fees REAL NOT NULL DEFAULT 0,
                    entry_profile TEXT NOT NULL,
                    entry_signal TEXT,
                    entry_opportunity_score REAL,
                    entry_confidence REAL,
                    entry_risk TEXT,
                    entry_target_hit_rate REAL,
                    entry_sample_count INTEGER NOT NULL DEFAULT 0,
                    entry_profile_buy_count INTEGER NOT NULL DEFAULT 0,
                    entry_buy_period_start TEXT,
                    note TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'OPEN',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_portfolio_positions_status
                ON portfolio_positions(status, symbol);

                CREATE TABLE IF NOT EXISTS portfolio_trades (
                    id TEXT PRIMARY KEY,
                    position_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    company_name TEXT NOT NULL,
                    purchase_date TEXT NOT NULL,
                    purchase_price REAL NOT NULL,
                    sale_date TEXT NOT NULL,
                    sale_price REAL NOT NULL,
                    quantity REAL NOT NULL,
                    purchase_fees REAL NOT NULL,
                    sale_fees REAL NOT NULL,
                    tax_paid REAL NOT NULL,
                    gross_profit REAL NOT NULL,
                    profit_after_fees REAL NOT NULL,
                    net_profit REAL NOT NULL,
                    gross_return_pct REAL NOT NULL,
                    net_return_pct REAL NOT NULL,
                    holding_days INTEGER NOT NULL,
                    entry_profile TEXT NOT NULL,
                    entry_signal TEXT,
                    entry_opportunity_score REAL,
                    exit_reason TEXT NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(position_id) REFERENCES portfolio_positions(id)
                );

                CREATE INDEX IF NOT EXISTS idx_portfolio_trades_sale_date
                ON portfolio_trades(sale_date, symbol);
            """)
            connection.commit()
        finally:
            connection.close()

    def add_position(self, position: PortfolioPosition):
        connection = self._connect()
        try:
            connection.execute("""
                INSERT INTO portfolio_positions (
                    id, symbol, company_name, purchase_date, purchase_price,
                    quantity, purchase_fees, entry_profile, entry_signal,
                    entry_opportunity_score, entry_confidence, entry_risk,
                    entry_target_hit_rate, entry_sample_count,
                    entry_profile_buy_count, entry_buy_period_start, note,
                    status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, self._position_row(position))
            connection.commit()
        finally:
            connection.close()

    def load_position(self, position_id: str) -> PortfolioPosition | None:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT * FROM portfolio_positions WHERE id = ?",
                (position_id,),
            ).fetchone()
        finally:
            connection.close()
        return self._position_from_row(row) if row else None

    def load_open_positions(self) -> list[PortfolioPosition]:
        connection = self._connect()
        try:
            rows = connection.execute("""
                SELECT * FROM portfolio_positions
                WHERE status = 'OPEN'
                ORDER BY purchase_date DESC, symbol
            """).fetchall()
        finally:
            connection.close()
        return [self._position_from_row(row) for row in rows]

    def close_position(self, position_id: str, updated_at: str, trade: PortfolioTrade):
        connection = self._connect()
        try:
            connection.execute("BEGIN")
            cursor = connection.execute("""
                UPDATE portfolio_positions
                SET status = 'CLOSED', updated_at = ?
                WHERE id = ? AND status = 'OPEN'
            """, (updated_at, position_id))
            if cursor.rowcount != 1:
                raise ValueError("Position wurde nicht gefunden oder ist bereits geschlossen.")
            connection.execute("""
                INSERT INTO portfolio_trades (
                    id, position_id, symbol, company_name, purchase_date,
                    purchase_price, sale_date, sale_price, quantity,
                    purchase_fees, sale_fees, tax_paid, gross_profit,
                    profit_after_fees, net_profit, gross_return_pct,
                    net_return_pct, holding_days, entry_profile, entry_signal,
                    entry_opportunity_score, exit_reason, note, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, self._trade_row(trade))
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def load_trades(self) -> list[PortfolioTrade]:
        connection = self._connect()
        try:
            rows = connection.execute("""
                SELECT * FROM portfolio_trades
                ORDER BY sale_date DESC, symbol
            """).fetchall()
        finally:
            connection.close()
        return [self._trade_from_row(row) for row in rows]

    def _position_row(self, p):
        return (
            p.id, p.symbol, p.company_name, p.purchase_date, p.purchase_price,
            p.quantity, p.purchase_fees, p.entry_profile, p.entry_signal,
            p.entry_opportunity_score, p.entry_confidence, p.entry_risk,
            p.entry_target_hit_rate, p.entry_sample_count,
            p.entry_profile_buy_count, p.entry_buy_period_start, p.note,
            p.status, p.created_at, p.updated_at,
        )

    def _trade_row(self, t):
        return (
            t.id, t.position_id, t.symbol, t.company_name, t.purchase_date,
            t.purchase_price, t.sale_date, t.sale_price, t.quantity,
            t.purchase_fees, t.sale_fees, t.tax_paid, t.gross_profit,
            t.profit_after_fees, t.net_profit, t.gross_return_pct,
            t.net_return_pct, t.holding_days, t.entry_profile, t.entry_signal,
            t.entry_opportunity_score, t.exit_reason, t.note, t.created_at,
        )

    def _position_from_row(self, row):
        return PortfolioPosition(**dict(row))

    def _trade_from_row(self, row):
        return PortfolioTrade(**dict(row))
