from datetime import date

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from stockmind.application.portfolio.add_position_use_case import AddPositionUseCase
from stockmind.application.portfolio.portfolio_dashboard_use_case import PortfolioDashboardUseCase
from stockmind.application.portfolio.portfolio_performance_use_case import PortfolioPerformanceUseCase
from stockmind.application.portfolio.sell_position_use_case import SellPositionUseCase

router = APIRouter(prefix="/portfolio", tags=["Portfolio"])


class AddPositionRequest(BaseModel):
    symbol: str
    purchase_date: date
    purchase_price: float = Field(gt=0)
    quantity: float = Field(gt=0)
    purchase_fees: float = Field(default=0, ge=0)
    entry_profile: str = "balanced"
    note: str = ""


class SellPositionRequest(BaseModel):
    sale_date: date
    sale_price: float = Field(gt=0)
    sale_fees: float = Field(default=0, ge=0)
    tax_paid: float = Field(default=0, ge=0)
    exit_reason: str = "MANUAL"
    note: str = ""


def as_dict(value):
    from dataclasses import asdict, is_dataclass
    if is_dataclass(value): return asdict(value)
    if isinstance(value, list): return [as_dict(x) for x in value]
    if isinstance(value, dict): return {k: as_dict(v) for k, v in value.items()}
    return value


@router.get("")
def get_portfolio():
    return as_dict(PortfolioDashboardUseCase().load())


@router.get("/performance")
def get_portfolio_performance():
    return PortfolioPerformanceUseCase().load()


@router.post("/positions")
def add_position(request: AddPositionRequest):
    try:
        return as_dict(AddPositionUseCase().execute(**request.model_dump()))
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error))


@router.post("/positions/{position_id}/sell")
def sell_position(position_id: str, request: SellPositionRequest):
    try:
        return as_dict(SellPositionUseCase().execute(position_id=position_id, **request.model_dump()))
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error))
