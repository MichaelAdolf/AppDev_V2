# Sprint P2 Portfolio Intelligence & Daily Mail

- +8-%-Ziel und 60-Tage-Fenster je offener Position überwachen
- Entry-Snapshot mit aktuellem Score, Confidence, Risk und Signal vergleichen
- Transparente Attention Reasons statt automatischem SELL
- Position Intelligence im Streamlit Portfolio
- Performance nach Entry-Profil
- Portfolio-Alerts und Portfolioübersicht in der Daily Mail
- API: GET /portfolio/intelligence

Interpretation: TARGET_REACHED und TIME_WINDOW_EXCEEDED sind CRITICAL im Sinne von „Exit prüfen“; weitere Verschlechterungen sind ATTENTION. Dies ist noch keine Exit Engine und kein automatisches Verkaufssignal.

Tests:
python -m unittest tests.test_portfolio_intelligence tests.test_portfolio_lots tests.test_portfolio_foundation
