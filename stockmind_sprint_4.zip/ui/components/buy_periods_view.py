import pandas as pd
import streamlit as st

from stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case import (
    BuyPeriodDashboardUseCase,
)


OUTCOME_LABELS = {
    "TARGET_HIT": "Ziel erreicht",
    "BELOW_TARGET": "Positiv unter Ziel",
    "FLAT": "Seitwärts",
    "NEGATIVE": "Negativ",
    "INCOMPLETE_WINDOW": "Noch offen",
}


def render(
    symbol: str,
    profile_name: str,
    analysis_period: str = "5y",
    max_gap_days: int = 3,
):
    result = BuyPeriodDashboardUseCase().load(
        symbol=symbol,
        profile_name=profile_name,
        analysis_period=analysis_period,
        max_gap_days=max_gap_days,
    )
    stats = result.statistics

    st.caption(
        f"Profil: {profile_name} | Historie: {analysis_period} | "
        f"maximale Gap: {max_gap_days} Kalendertage"
    )

    if result.active_period:
        period = result.active_period
        st.success(
            "Aktive BUY-Periode: "
            f"seit {period.start_date}, "
            f"{period.calendar_duration_days} Kalendertage, "
            f"{period.buy_signal_count} BUY-Signale"
        )
    else:
        st.info("Aktuell besteht für dieses Profil keine aktive BUY-Periode.")

    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Perioden", result.period_count)
    col2.metric("Vollständig", stats.complete_period_count)
    col3.metric("Offen", stats.incomplete_period_count)
    col4.metric("Target Hit", f"{stats.target_hit_rate:.1%}")
    col5.metric("Ø Tage bis Ziel", f"{stats.average_days_to_target:.1f}")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Unter Ziel", f"{stats.below_target_rate:.1%}")
    col2.metric("Flat", f"{stats.flat_rate:.1%}")
    col3.metric("Negativ", f"{stats.negative_rate:.1%}")
    col4.metric(
        "Ø Periodendauer",
        f"{stats.average_calendar_duration_days:.1f} Tage",
    )

    if not result.periods:
        st.info("Keine BUY-Perioden für diese Auswahl vorhanden.")
        return

    rows = []
    for period in result.periods:
        rows.append({
            "Start": period.start_date,
            "Ende": period.end_date,
            "Kalendertage": period.calendar_duration_days,
            "BUY-Tage": period.buy_signal_count,
            "Gap-Tage": period.gap_days_total,
            "Größte Gap": period.largest_gap_days,
            "Entry": round(period.entry_price, 2),
            "Outcome": OUTCOME_LABELS.get(period.outcome, period.outcome),
            "Tage bis Ziel": period.days_to_target,
            "Return am Fensterende %": (
                round(period.window_end_return_pct, 2)
                if period.window_end_return_pct is not None else None
            ),
            "Max Gain %": (
                round(period.max_gain_pct, 2)
                if period.max_gain_pct is not None else None
            ),
            "Max Drawdown %": (
                round(period.max_drawdown_pct, 2)
                if period.max_drawdown_pct is not None else None
            ),
            "Vollständig": period.is_complete,
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True)
