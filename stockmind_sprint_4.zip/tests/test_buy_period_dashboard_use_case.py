import unittest
from unittest.mock import patch

from stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case import (
    BuyPeriodDashboardUseCase,
)
from stockmind.domain.history.buy_period_entry import BuyPeriodEntry


class BuyPeriodDashboardUseCaseTest(unittest.TestCase):
    @patch("stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case.BuyPeriodRepository")
    def test_rates_only_use_complete_periods(self, repository_type):
        repository_type.return_value.load_by_symbol.return_value = [
            self._period("TARGET_HIT", True, "2025-01-01"),
            self._period("BELOW_TARGET", True, "2025-03-01"),
            self._period("INCOMPLETE_WINDOW", False, "2026-09-20"),
        ]
        result = BuyPeriodDashboardUseCase().load("AAPL", "balanced", "5y")
        self.assertEqual(result.statistics.complete_period_count, 2)
        self.assertEqual(result.statistics.incomplete_period_count, 1)
        self.assertEqual(result.statistics.target_hit_rate, 0.5)
        self.assertEqual(result.statistics.below_target_rate, 0.5)

    def _period(self, outcome, complete, start_date):
        return BuyPeriodEntry(
            symbol="AAPL", profile_name="balanced", analysis_period="5y",
            start_date=start_date, end_date=start_date,
            calendar_duration_days=1, buy_signal_count=1,
            gap_days_total=0, largest_gap_days=0, entry_price=100.0,
            target_pct=0.08, outcome=outcome,
            target_hit=outcome == "TARGET_HIT", days_to_target=10,
            window_end_date=None, window_end_return_pct=2.0,
            max_gain_pct=9.0, max_drawdown_pct=-2.0,
            is_complete=complete,
        )


if __name__ == "__main__":
    unittest.main()
