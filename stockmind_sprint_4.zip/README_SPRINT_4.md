# StockMind Sprint 4

## Inhalt

Sprint 4 macht die profilabhängigen BUY-Perioden in API und Streamlit nutzbar.

- BUY-Perioden-Detailansicht folgt dem im Hauptdashboard gewählten Profil.
- Neue Streamlit-Komponente `buy_periods_view.py`.
- Neue Streamlit-Komponente `profile_comparison_view.py`.
- Profilvergleich zeigt Conservative, Balanced und Aggressive gleichzeitig.
- API-Endpoint `/stock/{symbol}/buy-periods` erhält `profile_name`,
  `analysis_period` und `max_gap_days`.
- Neuer API-Endpoint `/stock/{symbol}/buy-periods/profile-comparison`.
- Bestehendes `profile_comparison_result.py` wird erweitert. Eine Datei namens
  `profile_comparison_dashboard_result.py` ist nicht erforderlich.

## Übernahme

1. Git-Checkpoint erstellen.
2. Datenbank sichern.
3. Paket in den Projektroot kopieren, bestehende Dateien ersetzen.
4. Vor dem Raspberry-Deployment lokal testen.

## Tests

```powershell
python -m unittest tests.test_buy_period_dashboard_use_case
python -m unittest tests.test_buy_period_builder
python -m unittest tests.test_buy_period_repository
python scripts/test_daily_buy_signals.py
python -m unittest tests.test_daily_buy_signal_repository
python tests/test_historical_outcomes.py
python scripts/test_historical_success_engine.py
```

## API-Test

```powershell
uvicorn api.stockmind_api:app --reload
```

Danach in Swagger prüfen:

- `GET /stock/{symbol}/buy-periods`
- `GET /stock/{symbol}/buy-periods/profile-comparison`

## Dashboard-Test

```powershell
streamlit run ui/streamlit_app.py
```

Prüfen:

- Wechsel des Hauptprofils ändert BUY-Perioden im Detailtab.
- Profilvergleich zeigt alle drei Profile.
- Target-Hit-, Below-Target-, Flat- und Negative-Raten werden angezeigt.
- Unvollständige Perioden gehen nicht in die Raten ein.

## Deployment

Für das Add-on müssen die geänderten Ordner `api`, `src` und `ui` erneut in den
lokalen Add-on-Build-Kontext kopiert und das Add-on neu gebaut werden.
