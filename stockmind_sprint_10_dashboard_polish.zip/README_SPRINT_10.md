# StockMind Sprint 10: Dashboard Structure & Final Polish

## Ziel

Dieser Sprint ändert ausschließlich die sichtbare Dashboard-Struktur. Fachlogik,
Persistenz, Scoring, BUY-Perioden und historische Analytics bleiben unverändert.

## Hauptbereiche

Das Dashboard trennt nun drei Ebenen sichtbar:

1. Markt & Watchlist
2. Aktienauswahl
3. Einzelaktienanalyse

Die bestehende Aktienauswahl erhält beim Aufruf aus `streamlit_app.py` keine zweite
eigene Überschrift, damit der Bereich nicht doppelt beschriftet wird.

## Tab Übersicht

Reihenfolge:

1. Aktuelle Einschätzung
2. Decision Intelligence
3. Aktuelle Bewertung inklusive 5-Jahres-Kurschart
4. Technisch vs. Fundamental

Der separate Block `Historische BUY-Perioden-Evidenz` wurde entfernt. Seine
wesentlichen Informationen bleiben über die obere Trefferquote, aktuelle
Einschätzung, Decision Intelligence und Historienansicht verfügbar.

## Tab Historie & BUY-Perioden

Der Abschnitt `Technische Detailanalyse: Historische Setups` inklusive Setup-KPIs
und Setup-Tabelle wurde aus der sichtbaren UI entfernt.

Die zugrunde liegenden Historical-Setup-Daten, Repositories und Refresh-Prozesse
werden ausdrücklich nicht gelöscht oder verändert.

## Test

```powershell
streamlit run ui/streamlit_app.py
```

Prüfen:

- Sidebar unverändert.
- Haupttabs funktionieren unverändert.
- Drei Hauptbereiche sind visuell klar getrennt.
- Aktienauswahl erscheint nur einmal beschriftet.
- Tab 1 besitzt exakt die neue Reihenfolge.
- Separater Historical-Evidence-Block ist entfernt.
- Tab 3 enthält keine Historical-Setup-Detailsektion mehr.
- Tabs Analyse, Indikatoren, Profilvergleich, Fundamentaldaten und Glossar bleiben
  funktional unverändert.

Keine Datenbankmigration und kein Refresh sind für Sprint 10 erforderlich.
