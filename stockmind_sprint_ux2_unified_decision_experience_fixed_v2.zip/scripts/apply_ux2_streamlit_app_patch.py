from pathlib import Path

p = Path("ui/streamlit_app.py")
text = p.read_text(encoding="utf-8")

old = "render_stock_decision_summary(selected_symbol)"
new = "render_stock_decision_summary(selected_symbol, profile)"
if new not in text:
    if old not in text:
        raise SystemExit("Stock decision summary call not found.")
    text = text.replace(old, new, 1)

old2 = """standard_profile = profile
if profile == "individual":
    active = FittedProfileRepository().load_active(selected_symbol)
    standard_profile = active.base_profile if active else "balanced"
"""
new2 = "standard_profile = profile"
if old2 in text:
    text = text.replace(old2, new2, 1)
elif new2 not in text:
    raise SystemExit("Profile fallback block not found.")

p.write_text(text, encoding="utf-8")
print(f"Patched {p}")
