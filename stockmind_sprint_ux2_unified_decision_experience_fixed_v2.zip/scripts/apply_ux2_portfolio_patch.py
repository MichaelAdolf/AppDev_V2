from pathlib import Path

p = Path("ui/components/portfolio_view.py")
text = p.read_text(encoding="utf-8")

import_line = "from stockmind.application.exit.portfolio_exit_use_case import PortfolioExitUseCase\n"
anchor = "from components.portfolio_exit_view import render as render_portfolio_exit\n"
if import_line not in text:
    if anchor not in text:
        raise SystemExit("Portfolio import anchor not found.")
    text = text.replace(anchor, anchor + import_line, 1)

old = """    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Investiert", _money(result.invested_amount))"""
new = """    decisions = PortfolioExitUseCase().load()
    s1, s2, s3 = st.columns(3)
    s1.metric("🔴 EXIT REVIEW", sum(x.status == "EXIT_REVIEW" for x in decisions))
    s2.metric("🟡 WATCH", sum(x.status == "WATCH" for x in decisions))
    s3.metric("🔵 HOLD", sum(x.status == "HOLD" for x in decisions))
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Investiert", _money(result.invested_amount))"""
if new not in text:
    if old not in text:
        raise SystemExit("Portfolio metric block not found.")
    text = text.replace(old, new, 1)

p.write_text(text, encoding="utf-8")
print(f"Patched {p}")
