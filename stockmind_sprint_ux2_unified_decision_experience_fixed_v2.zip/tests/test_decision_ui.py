import unittest
from components.decision_ui import label,normalize
class DecisionUiTest(unittest.TestCase):
 def test_all_product_decisions_have_consistent_labels(self):
  self.assertEqual(label('BUY'),'🟢 BUY');self.assertEqual(label('HOLD'),'🔵 HOLD');self.assertEqual(label('WATCH'),'🟡 WATCH');self.assertEqual(label('EXIT_REVIEW'),'🔴 EXIT REVIEW')
 def test_unknown_decision_becomes_no_data(self):self.assertEqual(normalize('UNKNOWN'),'NO_DATA')
if __name__=='__main__':unittest.main()
