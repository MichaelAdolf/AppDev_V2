# Sprint UX2: Unified Decision Experience

## Einheitliche Sprache
- 🟢 BUY: Einstieg prüfen
- 🔵 HOLD: kein Handlungsbedarf
- 🟡 WATCH: Position beobachten
- 🔴 EXIT REVIEW: Verkauf prüfen
- ⚪ NO DATA / NICHT AKTIV

## Geänderte Ansichten
- Watchlist: Decision-first Cards und Tabelle
- Top Movers: aktuelles Signal plus Veränderungsgrund
- Aktienanalyse: ausgewähltes Profil prominent, Profilvergleich, Portfolio und Exit
- Portfolio: Status-Zähler für EXIT REVIEW, WATCH und HOLD
- Exit Intelligence: einheitliche Cards und Begriffe

## Integration
1. ZIP entpacken.
2. Patches ausführen:
```powershell
python scripts/apply_ux2_streamlit_app_patch.py
python scripts/apply_ux2_portfolio_patch.py
```
3. Syntax prüfen:
```powershell
python -m py_compile ui/streamlit_app.py ui/components/portfolio_view.py
```
4. Smoke Test:
```powershell
streamlit run ui/streamlit_app.py
```

## Fachliche Grenze
UX2 verändert keine Tradingregel, keine Score-Berechnung und keine Exit-Logik. Es ändert ausschließlich Darstellung und Informationshierarchie.
