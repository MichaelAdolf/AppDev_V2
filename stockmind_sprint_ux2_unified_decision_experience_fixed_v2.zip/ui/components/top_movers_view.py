import pandas as pd
import streamlit as st
from components.decision_ui import label,render_card
from stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case import DailyIntelligenceDashboardUseCase

def change(v):return '-' if v is None else f'{v:+.1f}'
def render(profile_name):
 d=DailyIntelligenceDashboardUseCase().load(profile_name);st.subheader('Top Movers & Entscheidungen');st.caption('Was hat sich seit dem vorherigen Handelstag verändert und welche Entscheidung gilt aktuell?')
 c1,c2,c3,c4,c5=st.columns(5);c1.metric('Aktien',d.stock_count);c2.metric('Heute relevant',d.relevant_count);c3.metric('Neue BUY-Perioden',d.new_buy_period_count);c4.metric('Signaländerungen',d.signal_change_count);c5.metric('Konsens',d.consensus_count)
 relevant=[x for x in d.items if x.relevance_priority>0]
 if relevant:
  for x in relevant[:5]:render_card(x.current_signal,f'{x.company_name} ({x.symbol})',[('Score',f'{x.current_score:.1f}'),('Δ Score',change(x.score_change)),('Confidence',f'{x.current_confidence:.1%}'),('Hist. Hit',f'{x.target_hit_rate:.1%}')],f'{x.relevance_status} · Profil {x.profile_name} · {x.profile_consensus}')
 else:st.info('Keine besonderen Veränderungen im vorhandenen Datenstand.')
 st.subheader('Alle Bewegungen');movers=sorted([x for x in d.items if x.score_change is not None],key=lambda x:x.score_change,reverse=True)
 st.dataframe(pd.DataFrame([{'Entscheidung':label(x.current_signal),'Symbol':x.symbol,'Unternehmen':x.company_name,'Profil':x.profile_name,'Ereignis':x.relevance_status,'Score vorher':round(x.previous_score,1),'Score aktuell':round(x.current_score,1),'Δ Score':round(x.score_change,1),'Confidence %':round(x.current_confidence*100,1),'Konsens':x.profile_consensus} for x in movers]),width='stretch',hide_index=True) if movers else st.info('Noch keine zwei Replay-Handelstage vorhanden.')
