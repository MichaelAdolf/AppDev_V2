import pandas as pd
import streamlit as st
from components.decision_ui import label,render_card
from stockmind.application.dashboard.use_cases.watchlist_dashboard_use_case import WatchlistDashboardUseCase
from stockmind.application.dashboard.use_cases.alerts_dashboard_use_case import AlertsDashboardUseCase

def render_alert(alert):
 message=f'**{alert.title}: {alert.symbol}**  {alert.message}  Profil: `{alert.profile_name}` | Auslöser: {alert.reason}'
 {'success':st.success,'warning':st.warning,'error':st.error}.get(alert.severity,st.info)(message)
def render(profile_name):
 dashboard=WatchlistDashboardUseCase().load(profile_name);results=sorted(dashboard.stocks,key=lambda x:x.opportunity_score,reverse=True)
 st.subheader('Watchlist Entscheidungen');st.caption(f'Ausgewähltes Profil: {profile_name.title()}. Entscheidung zuerst, Kennzahlen als Begründung.')
 c1,c2,c3,c4,c5=st.columns(5);c1.metric('Aktien',dashboard.stock_count);c2.metric('🟢 BUY',dashboard.buy_count);c3.metric('🔵 HOLD',dashboard.hold_count);c4.metric('🔴 SELL',dashboard.sell_count);c5.metric('Hot',dashboard.hot_opportunities)
 buys=[x for x in results if x.signal=='BUY']
 if buys:
  st.subheader('Heute Einstieg prüfen')
  for item in buys[:5]:
   render_card('BUY',f'{item.company_name} ({item.symbol})',[('Score',f'{item.opportunity_score:.1f}'),('Confidence',f'{item.confidence:.1%}'),('Hist. Evidenz',f'{item.historical_success_rate:.1%}'),('Risiko',item.risk_level)],f'Profil: {profile_name.title()}')
 st.subheader('Gesamte Watchlist')
 st.dataframe(pd.DataFrame([{'Entscheidung':label(x.signal),'Symbol':x.symbol,'Unternehmen':x.company_name,'Profil':profile_name.title(),'Opportunity Score':round(x.opportunity_score,1),'Confidence %':round(x.confidence*100,1),'Hist. Evidenz %':round(x.historical_success_rate*100,1),'Risiko':x.risk_level,'Individual':label(x.fitted_signal) if x.fitted_active else '⚪ Nicht aktiv'} for x in results]),width='stretch',hide_index=True)
 st.divider();st.subheader('Alerts');alerts=AlertsDashboardUseCase().load(profile_name)
 if alerts:
  for alert in alerts[:10]:render_alert(alert)
 else:st.success('Keine besonderen Alerts vorhanden.')
