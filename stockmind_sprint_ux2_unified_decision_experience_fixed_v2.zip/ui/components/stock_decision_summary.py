import pandas as pd
import streamlit as st
from components.decision_ui import label,render_banner,render_card
from stockmind.application.dashboard.use_cases.profile_comparison_dashboard_use_case import ProfileComparisonDashboardUseCase
from stockmind.application.exit.portfolio_exit_use_case import PortfolioExitUseCase
from stockmind.application.portfolio.portfolio_intelligence_use_case import PortfolioIntelligenceUseCase

def render(symbol,selected_profile='balanced'):
 symbol=symbol.upper();comparison=ProfileComparisonDashboardUseCase().load(symbol,'5y',3);entries={x.profile_name:x for x in comparison.entries};selected=entries.get(selected_profile)
 st.subheader('Entscheidungsübersicht')
 if selected:
  signal='BUY' if selected.current_buy_signal is True else selected.signal
  render_banner(signal,f'{selected_profile.title()} Entry',f'Score {selected.score:.1f} · Confidence {selected.confidence:.1%} · Hist. Trefferquote {selected.target_hit_rate:.1%} · Sample {selected.complete_period_count} · Risiko {selected.risk_level}')
 else:render_banner('NO_DATA',f'{selected_profile.title()} Entry','Für dieses Profil liegen noch keine aktuellen Analysedaten vor.')
 st.markdown('#### Entry-Profile')
 st.dataframe(pd.DataFrame([{'Profil':x.profile_name.title(),'Entscheidung':label('BUY' if x.current_buy_signal is True else x.signal),'Score':round(x.score,1),'Confidence %':round(x.confidence*100,1),'Hist. Trefferquote %':round(x.target_hit_rate*100,1),'Sample':x.complete_period_count,'Risiko':x.risk_level} for x in comparison.entries]),width='stretch',hide_index=True)
 portfolio=next((x for x in PortfolioIntelligenceUseCase().load() if x.symbol.upper()==symbol),None);exit_decision=next((x for x in PortfolioExitUseCase().load() if x.symbol.upper()==symbol),None)
 st.markdown('#### Portfolio & Exit')
 if not portfolio:st.info('⚪ Nicht im Portfolio. Keine Exit-Entscheidung erforderlich.');return
 c1,c2,c3,c4=st.columns(4);c1.metric('Stück',f'{portfolio.quantity:g}');c2.metric('Ø Kaufkurs',f'{portfolio.weighted_purchase_price:.2f} €');c3.metric('P/L','–' if portfolio.unrealized_profit is None else f'{portfolio.unrealized_profit:+.2f} €',None if portfolio.unrealized_return_pct is None else f'{portfolio.unrealized_return_pct:+.1%}');c4.metric('Tag',f'{portfolio.holding_days}/60')
 if exit_decision:render_card(exit_decision.status,'Exit Entscheidung',[('Strategie',exit_decision.strategy_name),('Validation',exit_decision.validation_status)],f"Gründe: {', '.join(exit_decision.reasons) or 'keine'} · {exit_decision.action_text}")
