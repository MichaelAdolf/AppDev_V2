import streamlit as st

DECISIONS={
 'BUY':('🟢','BUY','Einstieg prüfen','success'),
 'HOLD':('🔵','HOLD','Kein Handlungsbedarf','info'),
 'SELL':('🔴','SELL','Signal kritisch prüfen','error'),
 'WATCH':('🟡','WATCH','Position beobachten','warning'),
 'EXIT_REVIEW':('🔴','EXIT REVIEW','Verkauf prüfen','error'),
 'NO_DATA':('⚪','NO DATA','Keine aktuelle Bewertung','info'),
 'NOT_ACTIVE':('⚪','NICHT AKTIV','Keine aktive Individual-Strategie','info'),
}
def normalize(value):
 key=(value or 'NO_DATA').upper();return key if key in DECISIONS else 'NO_DATA'
def label(value,with_action=False):
 icon,title,action,_=DECISIONS[normalize(value)];return f'{icon} {title}' + (f' · {action}' if with_action else '')
def render_banner(value,title=None,detail=None):
 icon,name,action,severity=DECISIONS[normalize(value)];message=f'**{title or name}:** {icon} {name} · {action}'
 if detail:message+=f'  \n{detail}'
 getattr(st,severity)(message)
def render_card(value,title,metrics=None,caption=None):
 with st.container(border=True):
  icon,name,action,_=DECISIONS[normalize(value)];st.markdown(f'### {icon} {title}');st.markdown(f'**{name}**  ');st.caption(action)
  if metrics:
   cols=st.columns(len(metrics))
   for col,(metric_name,metric_value) in zip(cols,metrics):col.metric(metric_name,metric_value)
  if caption:st.caption(caption)
