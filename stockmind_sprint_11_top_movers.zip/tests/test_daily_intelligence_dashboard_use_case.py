import unittest
from types import SimpleNamespace
from unittest.mock import patch

from stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case import (
    DailyIntelligenceDashboardUseCase,
)


class DailyIntelligenceDashboardUseCaseTest(unittest.TestCase):
    def test_relevance_priority(self):
        use_case = DailyIntelligenceDashboardUseCase()
        status, priority = use_case._relevance(
            new_buy_period=True,
            signal_changed=True,
            current_signal="BUY",
            profile_buy_count=3,
            score_change=8.0,
            confidence=0.9,
            has_active_period=True,
        )
        self.assertEqual(status, "Neue BUY-Periode")
        self.assertEqual(priority, 100)

    def test_score_change_uses_previous_available_replay_day(self):
        with (
            patch("stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case.LatestAnalysisRepository") as latest_type,
            patch("stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case.WatchlistRepository") as watchlist_type,
            patch("stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case.HistoricalOpportunityRepository") as history_type,
            patch("stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case.BuyPeriodDashboardUseCase") as period_type,
            patch("stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case.ProfileComparisonDashboardUseCase") as comparison_type,
        ):
            latest_type.return_value.load_all.return_value = [
                SimpleNamespace(
                    symbol="AAPL", opportunity_score=80.0,
                    confidence=0.8, signal="BUY", risk_level="LOW",
                )
            ]
            watchlist_type.return_value.load_all.return_value = [
                SimpleNamespace(
                    symbol="AAPL", company_name="Apple Inc.", active=True,
                )
            ]
            history_type.return_value.load_by_symbol.return_value = [
                SimpleNamespace(
                    trading_date="2026-09-24", opportunity_score=70.0,
                    confidence=0.7, signal="HOLD", risk_level="MEDIUM",
                ),
                SimpleNamespace(
                    trading_date="2026-09-25", opportunity_score=80.0,
                    confidence=0.8, signal="BUY", risk_level="LOW",
                ),
            ]
            stats = SimpleNamespace(
                target_hit_rate=0.82,
                complete_period_count=40,
                sample_quality="MEDIUM",
            )
            period_type.return_value.load.return_value = SimpleNamespace(
                active_period=SimpleNamespace(
                    start_date="2026-09-25",
                    calendar_duration_days=1,
                ),
                statistics=stats,
            )
            comparison_type.return_value.load.return_value = SimpleNamespace(
                entries=[
                    SimpleNamespace(profile_name="conservative", signal="BUY", current_buy_signal=True),
                    SimpleNamespace(profile_name="balanced", signal="BUY", current_buy_signal=True),
                    SimpleNamespace(profile_name="aggressive", signal="BUY", current_buy_signal=True),
                ]
            )
            result = DailyIntelligenceDashboardUseCase().load("balanced")
            self.assertEqual(result.items[0].score_change, 10.0)
            self.assertTrue(result.items[0].signal_changed)
            self.assertTrue(result.items[0].new_buy_period)
            self.assertEqual(result.items[0].profile_buy_count, 3)


if __name__ == "__main__":
    unittest.main()
