# StockMind Sprint 11: Top Movers & Daily Intelligence

## Inhalt

Der bislang leere Top-Movers-Tab wird zum Daily Intelligence Center für alle
aktiven Watchlist-Aktien.

Enthalten sind:

- Heute relevante Aktien
- Neue BUY-Perioden
- Signaländerungen
- Opportunity Score Movers
- Profil-Konsens
- Historische Trefferquote mit Stichprobengröße und Sample Quality

## Methodik

- Der aktuelle Zustand stammt aus `latest_analysis`.
- Veränderungen verwenden den neuesten und den vorherigen verfügbaren Eintrag des
  Historical Opportunity Replay.
- Relevanz ist transparent priorisiert:
  1. Neue BUY-Periode
  2. Neues BUY-Signal
  3. Profil-Konsens 3/3 BUY
  4. Score-Anstieg ab 5 Punkten
  5. Laufende BUY-Periode
  6. Andere Signaländerung
  7. Hohe Confidence
- Es wird kein neuer fachlicher Opportunity-Score erzeugt.
- Strategy Validation und Auswahl eines besten Profils sind nicht Bestandteil.

## Tests

```powershell
python -m unittest tests.test_daily_intelligence_dashboard_use_case
```

Erwartung:

```text
Ran 2 tests
OK
```

## Dashboard

```powershell
streamlit run ui/streamlit_app.py
```

Der Top-Movers-Tab erhält das in der Sidebar gewählte Profil.

## Voraussetzungen

Für Tagesvergleiche müssen mindestens zwei Historical-Opportunity-Replay-Tage
vorhanden sein. Ohne zwei Tage zeigt StockMind die aktuelle Lage, aber keine
Score- oder Signalveränderung.

Keine Datenbankmigration und kein zusätzlicher Refresh sind erforderlich.
