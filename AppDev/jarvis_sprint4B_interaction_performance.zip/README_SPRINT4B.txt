Sprint 4B - Interaction / Service Performance

Geaenderte Dateien:
- lib/services/voice_service.dart
- lib/services/real_home_assistant_service.dart
- lib/services/jarvis_background_bridge.dart

Bewusst NICHT geaendert, weil Verhalten bzw. Schnittstellen stabil bleiben sollen:
- audio_service.dart
- speech_output_service.dart
- thinking_feedback_service.dart
- conversation_service.dart
- home_assistant_service.dart
- jarvis_wakeword_bus.dart
- jarvis_wakeword_control.dart
- jarvis_wakeword_service.dart
- home_screen.dart
- jarvis_controller.dart
- Native Android Dateien

Wichtige Analysepunkte fuer spaetere Iteration:
- home_screen wartet in thinking aktuell per 40-ms Polling auf responseReady.
- HomeScreen verwendet weiterhin 1200 ms festen Delay zwischen Native Wakeword Stop und Flutter STT.
- ForegroundService startet fuer externe Events die Activity ueber zwei Wege.
- Es existieren native und Dart WebSocket-Implementierungen; Nutzung vor Loeschung pruefen.
- JarvisBackgroundService hat aktuell nur Lifecycle/Logging-Logik.

Nach Einspielen:
flutter clean
flutter pub get
flutter analyze
flutter run --profile
