Sprint 4A - Rendering Performance

Ersetzen:
- ambient_particles.dart
- ambient_connections.dart
- background_grid.dart
- hud_overlay.dart
- jarvis_circle.dart

Bewusst unverändert:
- home_screen.dart
- jarvis_controller.dart
- jarvis_layout.dart
- hud_panel.dart
- conversation_timeline.dart

Danach:
flutter clean
flutter pub get
flutter analyze
flutter run --profile
