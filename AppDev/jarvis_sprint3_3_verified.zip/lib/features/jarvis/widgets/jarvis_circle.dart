import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../../../core/jarvis_state.dart';

class JarvisCircle extends StatefulWidget {
  final JarvisState state;
  final double size;

  const JarvisCircle({
    super.key,
    required this.state,
    this.size = 240,
  });

  @override
  State<JarvisCircle> createState() => _JarvisCircleState();
}

class _JarvisCircleState extends State<JarvisCircle>
    with TickerProviderStateMixin {
  late final AnimationController _pulseController;

  late final AnimationController _outerRotation;
  late final AnimationController _middleRotation;
  late final AnimationController _innerRotation;
  late final AnimationController _scannerRotation;
  late final AnimationController _rippleController;
  late final AnimationController _voiceRingController;

  late final Animation<double> _pulse;

  double get _scale => widget.size / 240.0;
  double _s(double value) => value * _scale;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _pulse = Tween<double>(
      begin: 1.0,
      end: 1.08,
    ).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );

    _outerRotation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();

    _middleRotation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat(reverse: true);

    _innerRotation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _scannerRotation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _rippleController = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1800
      ),
    )..repeat();
  
    _voiceRingController = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 550,
        ),
    )..repeat();
  
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _outerRotation.dispose();
    _middleRotation.dispose();
    _innerRotation.dispose();
    _scannerRotation.dispose();
    _rippleController.dispose();
    _voiceRingController.dispose();

    super.dispose();
  }

  Color _color() {
    switch (widget.state) {
      case JarvisState.idle:
        return Colors.cyanAccent;
      case JarvisState.listening:
        return Colors.blueAccent;
      case JarvisState.thinking:
        return Colors.orangeAccent;
      case JarvisState.speaking:
        return Colors.greenAccent;
      case JarvisState.error:
        return Colors.redAccent;
    }
  }



  double _pulseSpeedFactor() {
    switch (widget.state) {
      case JarvisState.idle:
        return 1.00;
      case JarvisState.listening:
        return 1.03;
      case JarvisState.thinking:
        return 0.98;
      case JarvisState.speaking:
        return 1.04;
      case JarvisState.error:
        return 1.06;
    }
  }

  double _scannerOpacity() {
    switch (widget.state) {
      case JarvisState.idle:
        return 0.45;
      case JarvisState.listening:
        return 0.90;
      case JarvisState.thinking:
        return 0.75;
      case JarvisState.speaking:
        return 0.85;
      case JarvisState.error:
        return 1.00;
    }
  }

  double _scannerSweepAngle() {
    switch (widget.state) {
      case JarvisState.idle:
        return math.pi / 5.5;
      case JarvisState.listening:
        return math.pi / 3.8;
      case JarvisState.thinking:
        return math.pi / 4.5;
      case JarvisState.speaking:
        return math.pi / 3.5;
      case JarvisState.error:
        return math.pi / 3.0;
    }
  }

  Widget _rotatingRing({
    required AnimationController controller,
    required double size,
    required Color color,
    required double strokeWidth,
    double opacity = 0.8,
  }) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, child) {
        return Transform.rotate(
          angle: controller.value * 2 * math.pi,
          child: child,
        );
      },
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: color.withValues(alpha: opacity),
            width: strokeWidth,
          ),
        ),
      ),
    );
  }

  Widget _scannerRing({
    required double size,
    required Color color,
  }) {
    return AnimatedBuilder(
      animation: _scannerRotation,
      builder: (context, child) {
        return Transform.rotate(
          angle: _scannerRotation.value * 2 * math.pi,
          child: CustomPaint(
            size: Size.square(size),
            painter: _ScannerRingPainter(
              color: color,
              opacity: _scannerOpacity(),
              sweepAngle: _scannerSweepAngle(),
            ),
          ),
        );
      },
    );
  }

  Widget _radialTickRing({
    required double size,
    required Color color,
  }) {
    return CustomPaint(
      size: Size.square(size),
      painter: _TickRingPainter(
        color: color,
      ),
    );
  }

  Widget _dataRing({
    required double size,
    required Color color,
  }) {
    return AnimatedBuilder(
      animation: _middleRotation,
      builder: (context, child) {
        return Transform.rotate(
          angle: _middleRotation.value * 2 * math.pi,
          child: CustomPaint(
            size: Size.square(size),
            painter: _DataRingPainter(
              color: color,
            ),
          ),
        );
      },
    );
  }

  Widget _rippleRing({
    required Color color,
    required double delay,
  }) {
    return AnimatedBuilder(
      animation: _rippleController,
      builder: (context, child) {
        double progress = 
          ( _rippleController.value + delay) % 1.0;
          return Opacity(
          opacity: (1- progress) * 0.35,
          child: Container(
            width: _s(140),
            height: _s(140),
            decoration : BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: color,
                width: 2,
              ),
            ),
          ),
        );
      }
    );
  }

  Widget _voiceReactiveRing({
    required Color color,
  }) {
    return AnimatedBuilder(
      animation: _voiceRingController, 
      builder: (context, child) {
        return CustomPaint(
          size: Size.square(_s(160))
          painter: _VoiceRingPainter(
            color: color,
            progress:
              _voiceRingController.value,
            speaking:
              widget.state == JarvisState.speaking,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final color = _color();

    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulse.value * _pulseSpeedFactor(),
          child: SizedBox(
            width: widget.size,
            height: widget.size,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Dezente technische Tick-Markierungen außen
                _radialTickRing(
                  size: _s(230),
                  color: color,
                ),

                // Äußerer Ring
                _rotatingRing(
                  controller: _outerRotation,
                  size: _s(215),
                  color: color,
                  strokeWidth: 1.5,
                  opacity: 0.45,
                ),

                // Scanner-Bogen
                _scannerRing(
                  size: _s(213),
                  color: color,
                ),

                _dataRing(
                  size: _s(205),
                  color: color,
                ),

                // Mittlerer Ring
                _rotatingRing(
                  controller: _middleRotation,
                  size: _s(190),
                  color: color,
                  strokeWidth: 2,
                  opacity: 0.65,
                ),

                // Innerer Ring
                _rotatingRing(
                  controller: _innerRotation,
                  size: _s(160),
                  color: color,
                  strokeWidth: 2,
                  opacity: 0.75,
                ),

                if (widget.state == JarvisState.speaking)
                  _rippleRing(
                    color: color, 
                    delay: 0,
                  ),

                if (widget.state == JarvisState.speaking)
                  _rippleRing(
                    color: color, 
                    delay: 0.4,
                  ),

                if (widget.state == JarvisState.speaking)
                  _rippleRing(
                    color: color, 
                    delay: 0.8,
                  ),

                _voiceReactiveRing(
                  color: color,
                ),

                // Glowing Circle
                /*
                Container(
                  width: 160,
                  height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: color,
                      width: 4,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: color.withValues(alpha: 0.55),
                        blurRadius: _glow(),
                        spreadRadius: 6,
                      ),
                    ],
                  ),
                ),
                */

                // Innerer transparenter Layer
                Container(
                  width: _s(122),
                  height: _s(122),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: color.withValues(alpha: 0.25),
                      width: 1,
                    ),
                    color: color.withValues(alpha: 0.04),
                  ),
                ),

                // Kern
                Container(
                  width: _s(82),
                  height: _s(82),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withValues(alpha: 0.18),
                    boxShadow: [
                      BoxShadow(
                        color: color.withValues(alpha: 0.80),
                        blurRadius: 24,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),

                // Innerer Punkt
                Container(
                  width: _s(28),
                  height: _s(28),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withValues(alpha: 0.75),
                    boxShadow: [
                      BoxShadow(
                        color: color.withValues(alpha: 0.9),
                        blurRadius: 18,
                        spreadRadius: 3,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ScannerRingPainter extends CustomPainter {
  final Color color;
  final double opacity;
  final double sweepAngle;

  _ScannerRingPainter({
    required this.color,
    required this.opacity,
    required this.sweepAngle,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;

    final scannerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        colors: [
          color.withValues(alpha: 0.0),
          color.withValues(alpha: opacity * 0.35),
          color.withValues(alpha: opacity),
          color.withValues(alpha: 0.0),
        ],
        stops: const [
          0.0,
          0.35,
          0.70,
          1.0,
        ],
      ).createShader(rect);

    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 13
      ..strokeCap = StrokeCap.round
      ..color = color.withValues(alpha: opacity * 0.18)
      ..maskFilter = const MaskFilter.blur(
        BlurStyle.normal,
        8,
      );

    final arcRect = Rect.fromCircle(
      center: size.center(Offset.zero),
      radius: size.width / 2 - 10,
    );

    canvas.drawArc(
      arcRect,
      -math.pi / 2,
      sweepAngle,
      false,
      glowPaint,
    );

    canvas.drawArc(
      arcRect,
      -math.pi / 2,
      sweepAngle,
      false,
      scannerPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _ScannerRingPainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.opacity != opacity ||
        oldDelegate.sweepAngle != sweepAngle;
  }
}

class _TickRingPainter extends CustomPainter {
  final Color color;

  _TickRingPainter({
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radiusOuter = size.width / 2 - 6;
    final radiusInnerShort = radiusOuter - 7;
    final radiusInnerLong = radiusOuter - 14;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.22)
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;

    const tickCount = 64;

    for (int i = 0; i < tickCount; i++) {
      final angle = (2 * math.pi / tickCount) * i;

      final isLongTick = i % 8 == 0;
      final innerRadius = isLongTick ? radiusInnerLong : radiusInnerShort;

      final outer = Offset(
        center.dx + math.cos(angle) * radiusOuter,
        center.dy + math.sin(angle) * radiusOuter,
      );

      final inner = Offset(
        center.dx + math.cos(angle) * innerRadius,
        center.dy + math.sin(angle) * innerRadius,
      );

      canvas.drawLine(
        inner,
        outer,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _TickRingPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

class _DataRingPainter
  extends CustomPainter {
  final Color color;

  _DataRingPainter({
    required this.color,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final center = size.center(Offset.zero);

    final radius = size.width / 2 - 8;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.35)
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < 40; i++) {
      if (i % 3 == 0) continue;

      final angle = (2 * math.pi / 40) * i;

      final outer = Offset(
        center.dx + math.cos(angle) * radius,
        center.dy + math.sin(angle) * radius,
        );

      final inner = Offset (
        center.dx + math.cos(angle) * (radius - 8),
        center.dy + math.sin(angle) * (radius - 8),
      );

      canvas.drawLine(
        inner,
        outer,
        paint,
      );
    }
  }
  @override
  bool shouldRepaint(_) => true;
}

/*
class _VoiceRingPainter extends CustomPainter {

final Color color; final double progress; final bool speaking;

_VoiceRingPainter({ required this.color, required this.progress, required this.speaking, });

@override void paint( Canvas canvas, Size size, ) {

final center =
    size.center(Offset.zero);

final radius =
    size.width / 2 - 3;

const pointCount = 540;

final path = Path();

for (int i = 0;
    i < pointCount;
    i++) {

  final angle =
      (2 * math.pi /
              pointCount) *
          i;

  double offset = 0;

  if (speaking) {
    final t = progress * 100.0;

    final plasma1 =
        math.sin(
          angle *12 +
          t,
        ) *
        2.0;

    final plasma2 =
        math.sin(
          angle * 20 -
          t * 0.8,
        ) *
        1.5;

    final plasma3 =
        math.sin(
          angle * 32 +
          t * 0.5,
        ) *
        1.1;

    final plasma4 =
        math.sin(
          angle * 48 +
          t * 0.25,
        ) *
        0.7;
    

    offset =
        plasma1 +
        plasma2 +
        plasma3 +
        plasma4;
  }

  offset *=1.8;

  final r =
      radius + (speaking ? offset : 0);

  final x =
      center.dx +
      math.cos(angle) * r;

  final y =
      center.dy +
      math.sin(angle) * r;

  if (i == 0) {
    path.moveTo(x, y);
  } else {
    path.lineTo(x, y);
  }
}

path.close();

final glowPaint = Paint()
  ..style = PaintingStyle.stroke
  ..strokeWidth = 6
  ..color = color.withValues(
    alpha: 0.18,
  )
  ..maskFilter =
      const MaskFilter.blur(
    BlurStyle.normal,
    8,
  );

final paint = Paint()
  ..style = PaintingStyle.stroke
  ..strokeWidth = 1.8
  ..color = color;

canvas.drawPath(
  path,
  glowPaint,
);

canvas.drawPath(
  path,
  paint,
);

}

@override bool shouldRepaint( covariant _VoiceRingPainter oldDelegate) => true; }
*/
/*
class _VoiceRingPainter
    extends CustomPainter {

  final Color color;
  final double progress;
  final bool speaking;

  _VoiceRingPainter({
    required this.color,
    required this.progress,
    required this.speaking,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final center =
        size.center(Offset.zero);

    final radius =
        size.width / 2 - 3;

    final path = Path();

    const pointCount = 220;

    for (int i = 0;
        i <= pointCount;
        i++) {

      final angle =
          (2 * math.pi /
                  pointCount) *
              i;

      double offset = 0;

      if (speaking) {

        final wave1 =
            math.sin(
              angle * 2.0 +
                  progress * 2.5,
            );

        final wave2 =
            math.sin(
              angle * 3.5 -
                  progress * 1.7,
            );

        offset =
            wave1 * 3 +
            wave2 * 1.5;
      }

      final r =
          radius + offset;

      final x =
          center.dx +
          math.cos(angle) * r;

      final y =
          center.dy +
          math.sin(angle) * r;

      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    path.close();

    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8
      ..color = color.withValues(
        alpha: 0.12,
      )
      ..maskFilter =
          const MaskFilter.blur(
        BlurStyle.normal,
        8,
      );

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = color.withValues(
        alpha: 0.95,
      );

    canvas.drawPath(
      path,
      glowPaint,
    );

    canvas.drawPath(
      path,
      paint,
    );
  }

  @override
  bool shouldRepaint(
      covariant _VoiceRingPainter
          oldDelegate) {
    return true;
  }
}
*/


//Gut aber buggy, vielleicht ist die Folgeversion besser
class _VoiceRingPainter
    extends CustomPainter {

  final Color color;
  final double progress;
  final bool speaking;

  _VoiceRingPainter({
    required this.color,
    required this.progress,
    required this.speaking,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {

    final center =
        size.center(Offset.zero);

    const segmentCount = 96;

    final baseRadius =
        size.width / 2 - 6;

    final linePaint = Paint()
      ..color = color.withValues(
        alpha: speaking ? 0.95 : 0.45,
      )
      ..strokeWidth = 2.1
      ..strokeCap = StrokeCap.round;

    final glowPaint = Paint()
      ..color = color.withValues(
        alpha: speaking ? 0.18 : 0.08,
      )
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round
      ..maskFilter =
          const MaskFilter.blur(
        BlurStyle.normal,
        6,
      );

    for (int i = 0;
        i < segmentCount;
        i++) {

      final angle =
          (2 * math.pi /
                  segmentCount) *
              i;

      double amplitude = 2;

      if (speaking) {

        final wave1 =
            math.sin(
              angle * 6 +
                  progress *
                      math.pi *
                      10,
            );

        final wave2 =
            math.sin(
              angle * 17 -
                  progress *
                      math.pi *
                      8,
            );

        final wave3 =
            math.sin(
              angle * 31 +
                  progress *
                      math.pi *
                      5,
            );

        amplitude =
            3 +
            ((wave1 +
                        wave2 +
                        wave3) /
                    3)
                .abs() *
                18;
      }

      final startRadius =
          baseRadius;

      final endRadius =
          baseRadius + amplitude;

      final start = Offset(
        center.dx +
            math.cos(angle) *
                startRadius,
        center.dy +
            math.sin(angle) *
                startRadius,
      );

      final end = Offset(
        center.dx +
            math.cos(angle) *
                endRadius,
        center.dy +
            math.sin(angle) *
                endRadius,
      );

      canvas.drawLine(
        start,
        end,
        glowPaint,
      );

      canvas.drawLine(
        start,
        end,
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(
      covariant _VoiceRingPainter
          oldDelegate) {
    return true;
  }
}
