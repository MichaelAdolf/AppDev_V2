import 'package:flutter/material.dart';

enum JarvisLayoutClass { compact, standard, wide }

@immutable
class JarvisLayout {
  const JarvisLayout._({
    required this.layoutClass,
    required this.viewport,
    required this.outerPadding,
    required this.gap,
    required this.panelGap,
    required this.orbSize,
    required this.controlSize,
    required this.conversationHeight,
    required this.titleFontSize,
  });

  final JarvisLayoutClass layoutClass;
  final Size viewport;
  final double outerPadding;
  final double gap;
  final double panelGap;
  final double orbSize;
  final double controlSize;
  final double conversationHeight;
  final double titleFontSize;

  bool get isCompact => layoutClass == JarvisLayoutClass.compact;
  bool get isStandard => layoutClass == JarvisLayoutClass.standard;
  bool get isWide => layoutClass == JarvisLayoutClass.wide;

  double get maxContentWidth => isWide ? 1180 : 720;

  static JarvisLayout from(BoxConstraints constraints) {
    final width = constraints.maxWidth;
    final height = constraints.maxHeight;
    final shortestSide = width < height ? width : height;

    final layoutClass = width >= 900
        ? JarvisLayoutClass.wide
        : width >= 430
            ? JarvisLayoutClass.standard
            : JarvisLayoutClass.compact;

    final outerPadding = switch (layoutClass) {
      JarvisLayoutClass.compact => 12.0,
      JarvisLayoutClass.standard => 18.0,
      JarvisLayoutClass.wide => 24.0,
    };

    final gap = switch (layoutClass) {
      JarvisLayoutClass.compact => 10.0,
      JarvisLayoutClass.standard => 14.0,
      JarvisLayoutClass.wide => 18.0,
    };

    final desiredOrb = shortestSide * (layoutClass == JarvisLayoutClass.wide ? 0.42 : 0.58);
    final orbMax = layoutClass == JarvisLayoutClass.wide ? 330.0 : 270.0;
    final orbSize = desiredOrb.clamp(190.0, orbMax).toDouble();

    return JarvisLayout._(
      layoutClass: layoutClass,
      viewport: Size(width, height),
      outerPadding: outerPadding,
      gap: gap,
      panelGap: gap,
      orbSize: orbSize,
      controlSize: (orbSize * 0.21).clamp(50.0, 66.0).toDouble(),
      conversationHeight: (height * 0.15).clamp(118.0, 165.0).toDouble(),
      titleFontSize: (orbSize * 0.115).clamp(24.0, 34.0).toDouble(),
    );
  }
}
