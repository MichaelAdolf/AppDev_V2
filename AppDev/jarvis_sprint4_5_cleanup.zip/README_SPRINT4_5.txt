Sprint 4.5 - Architecture Cleanup & Stabilisierung

ZU ERSETZEN:
- lib/main.dart
- lib/features/jarvis/logic/jarvis_controller.dart
- android/app/src/main/kotlin/com/example/jarvis_app/JarvisForegroundService.kt
- pubspec.yaml

BEWUSST UNVERÄNDERT:
- AndroidManifest.xml: registriert bereits nur JarvisForegroundService.
- MainActivity.kt: ist jetzt der einzige Activity-Öffnungs-/Event-Bridge-Pfad und benötigt keine Änderung.
- device_wake_service.dart: wird von main.dart für externe Events und Wakeword aktiv verwendet.
- jarvis_background_bridge.dart, jarvis_wakeword_bus.dart, jarvis_wakeword_control.dart: aktiver Flutter-Native-Pfad.
- home_assistant_service.dart, real_home_assistant_service.dart, conversation_service.dart: aktive Request-Kette.
- mock_home_assistant_service.dart: als Test-/Entwicklungsimplementierung behalten.

BEREINIGT:
- Doppelten Activity-Start in JarvisForegroundService entfernt.
- Unbenutzten JarvisIntentParser aus JarvisController entfernt.
- print() in main.dart auf debugPrint() umgestellt.
- web_socket_channel aus pubspec entfernt, da der bereitgestellte aktive Runtime-WebSocket nativ ist und der Dart ExternalTriggerService zur Löschung vorgesehen ist.

TEST:
flutter clean
flutter pub get
flutter analyze
flutter run --profile
