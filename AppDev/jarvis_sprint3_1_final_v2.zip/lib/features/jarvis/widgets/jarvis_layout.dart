import 'package:flutter/material.dart';

enum JarvisLayoutClass { compact, standard, landscape, wide }

@immutable
class JarvisLayout {
  const JarvisLayout._({
    required this.layoutClass,
    required this.viewport,
    required this.outerPadding,
    required this.gap,
    required this.orbSize,
    required this.controlSize,
    required this.conversationHeight,
    required this.titleFontSize,
  });

  final JarvisLayoutClass layoutClass;
  final Size viewport;
  final double outerPadding;
  final double gap;
  final double orbSize;
  final double controlSize;
  final double conversationHeight;
  final double titleFontSize;

  bool get isCompact => layoutClass == JarvisLayoutClass.compact;
  bool get isLandscape => layoutClass == JarvisLayoutClass.landscape;
  bool get isWide => layoutClass == JarvisLayoutClass.wide;
  bool get usesLandscapeComposition => isLandscape || isWide;
  double get panelGap => gap;
  double get maxContentWidth => usesLandscapeComposition ? 1500 : 720;

  static JarvisLayout from(BoxConstraints constraints) {
    final width = constraints.maxWidth;
    final height = constraints.maxHeight;
    final landscape = width > height;

    final layoutClass = landscape
        ? (width >= 1100 ? JarvisLayoutClass.wide : JarvisLayoutClass.landscape)
        : (width < 430 ? JarvisLayoutClass.compact : JarvisLayoutClass.standard);

    final outerPadding = switch (layoutClass) {
      JarvisLayoutClass.compact => 10.0,
      JarvisLayoutClass.standard => 10.0,
      JarvisLayoutClass.landscape => 10.0,
      JarvisLayoutClass.wide => 16.0,
    };

    final gap = switch (layoutClass) {
      JarvisLayoutClass.compact => 10.0,
      JarvisLayoutClass.standard => 14.0,
      JarvisLayoutClass.landscape => 10.0,
      JarvisLayoutClass.wide => 14.0,
    };

    final desiredOrb = landscape ? height * 0.38 : width * 0.54;
    final orbMin = landscape ? 145.0 : 185.0;
    final orbMax = landscape ? 215.0 : 270.0;
    final orbSize = desiredOrb.clamp(orbMin, orbMax).toDouble();

    return JarvisLayout._(
      layoutClass: layoutClass,
      viewport: Size(width, height),
      outerPadding: outerPadding,
      gap: gap,
      orbSize: orbSize,
      controlSize: (orbSize * 0.24).clamp(48.0, 62.0).toDouble(),
      conversationHeight: landscape
          ? (height * 0.17).clamp(78.0, 105.0).toDouble()
          : (height * 0.15).clamp(118.0, 158.0).toDouble(),
      titleFontSize: landscape
          ? (orbSize * 0.13).clamp(22.0, 28.0).toDouble()
          : (orbSize * 0.115).clamp(24.0, 34.0).toDouble(),
    );
  }
}
