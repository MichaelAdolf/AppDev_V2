Sprint 4C - Interaction Coordination

Replace:
- lib/features/jarvis/ui/home_screen.dart
- lib/features/jarvis/logic/jarvis_controller.dart
- lib/services/jarvis_wakeword_control.dart
- android/app/src/main/kotlin/com/example/jarvis_app/MainActivity.kt
- android/app/src/main/kotlin/com/example/jarvis_app/JarvisForegroundService.kt

Changes:
- Remove fixed 1200 ms microphone handover delay.
- Native stopWakeword now returns whether the SpeechRecognizer has been destroyed and mic ownership transferred to Flutter.
- Remove 40 ms response polling. Controller exposes event-based waitForResponse via Completer.
- Sprint 2 thinking phrase behavior remains: feedback completes before the final response transition.

Not changed:
- voice_service.dart
- thinking_feedback_service.dart
- speech_output_service.dart
- wakeword bus / background bridge
- background service

After replacing:
flutter clean
flutter pub get
flutter analyze
flutter run --profile
