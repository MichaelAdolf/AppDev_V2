# StockMind Sprint 5

## Inhalt

Sprint 5 integriert die BUY-Perioden in die eigentliche StockMind Intelligence.

- Vollständige BUY-Perioden haben Vorrang als historische Evidenz.
- Ohne vollständige BUY-Perioden bleibt die Setup-Historie als Fallback aktiv.
- Confidence und Opportunity Score verwenden dieselbe historische Evidenz.
- Explainability nennt Evidenzquelle, Stichprobe und Outcome-Verteilung.
- Stock-Detail-Dashboard zeigt die verwendete Evidenzquelle.
- Neuer Jarvis-Endpunkt: `/jarvis/stock-analysis/{symbol}`.

## Entscheidungsregel

```text
complete_buy_periods > 0
→ historische Evidenz = Target-Hit-Rate der BUY-Perioden

complete_buy_periods == 0
→ historische Evidenz = bisherige Setup-Erfolgsrate
```

Die Evidence Sample Quality verwendet weiterhin die bekannten Schwellen:

- ab 50 Fällen: HIGH
- ab 20 Fällen: MEDIUM
- ab 1 Fall: LOW
- 0 Fälle: NO_SAMPLE

## Tests

```powershell
python -m unittest tests.test_historical_evidence_service
python -m unittest tests.test_opportunity_period_evidence
python -m unittest tests.test_buy_period_dashboard_use_case
python -m unittest tests.test_buy_period_builder
python -m unittest tests.test_buy_period_repository
python scripts/test_daily_buy_signals.py
python -m unittest tests.test_daily_buy_signal_repository
python tests/test_historical_outcomes.py
python scripts/test_historical_success_engine.py
```

## Daten aktualisieren

Nach Übernahme muss die tägliche Analyse erneut laufen, damit Latest Analysis,
Analysis History und Explainability mit Periodenevidenz neu geschrieben werden:

```powershell
python scripts/run_daily_refresh.py
```

## API und Dashboard

```powershell
uvicorn api.stockmind_api:app --reload
streamlit run ui/streamlit_app.py
```

Swagger prüfen:

- `GET /stock/{symbol}/summary`
- `GET /jarvis/stock-analysis/{symbol}`

## Deployment

Nach lokalem Test `api`, `src` und `ui` in den Add-on-Build-Kontext übernehmen,
Add-on neu bauen und anschließend über Node-RED den Refresh auslösen.
