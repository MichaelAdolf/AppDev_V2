from dataclasses import dataclass


@dataclass(frozen=True)
class HistoricalEvidenceResult:
    success_rate: float
    sample_quality: str
    source: str
    sample_count: int
    target_hit_rate: float
    below_target_rate: float
    flat_rate: float
    negative_rate: float
    incomplete_count: int
    average_similarity: float | None = None
    active_period_start: str | None = None
    active_period_duration_days: int | None = None
    active_period_buy_signal_count: int | None = None
