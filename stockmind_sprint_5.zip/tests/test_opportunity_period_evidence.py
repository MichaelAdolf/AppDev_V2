import unittest
from types import SimpleNamespace

from stockmind.domain.scoring.opportunity_score_engine import OpportunityScoreEngine


class OpportunityPeriodEvidenceTest(unittest.TestCase):
    def test_historical_component_uses_period_rate(self):
        result = OpportunityScoreEngine().calculate(
            quality_result=SimpleNamespace(quality="MEDIUM"),
            confidence_result=SimpleNamespace(confidence=0.5),
            historical_success_result=SimpleNamespace(
                success_rate=0.8,
                source="BUY_PERIODS",
            ),
            risk_result=SimpleNamespace(level="LOW"),
            profile=SimpleNamespace(
                opportunity_profile=SimpleNamespace(
                    quality_weight=0.25,
                    confidence_weight=0.25,
                    historical_weight=0.40,
                    risk_weight=0.10,
                )
            ),
        )
        self.assertEqual(result.historical_component, 32.0)
        self.assertEqual(result.historical_source, "BUY_PERIODS")
        self.assertEqual(result.historical_rate, 0.8)


if __name__ == "__main__":
    unittest.main()
