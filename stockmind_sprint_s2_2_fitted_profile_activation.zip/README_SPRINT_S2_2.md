# Sprint S2.2 Fitted Profile Activation

- Nur VALIDATED Kandidaten können manuell ACTIVE werden.
- Genau ein ACTIVE Fitted Profile je Aktie.
- Deaktivierung setzt auf VALIDATED zurück.
- Standardprofile bleiben unverändert und werden weiterhin angezeigt.
- Watchlist und Daily Mail zeigen das aktive Fitted-Signal zusätzlich an.
- Das Fitted-Signal basiert aktuell transparent auf den vier validierten Schwellen und liefert BUY bei 4/4 erfüllten Bedingungen, sonst HOLD.
- Keine automatische Aktivierung und kein automatischer Trade.

Tests:
python -m unittest tests.test_fitted_profile_activation tests.test_fitted_profile_validation tests.test_fitted_profile_search
