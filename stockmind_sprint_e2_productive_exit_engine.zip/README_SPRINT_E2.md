# Sprint E2 Productive Exit Engine

## Verhalten
- Pro Entry-Profil wird der bestplatzierte ROBUST_CANDIDATE aus Cross-Stock Validation gewählt.
- Gibt es keinen robusten Kandidaten, wird transparent auf BASELINE_8PCT_60D zurückgefallen.
- Ausgabe: HOLD, WATCH oder EXIT_REVIEW.
- Keine automatische Order und kein automatischer Verkauf.
- Daily Mail zeigt EXIT_REVIEW getrennt von WATCH/HOLD.

## Streamlit Integration
In `ui/components/portfolio_view.py` ergänzen:
```python
from components.portfolio_exit_view import render as render_portfolio_exit
```
Füge in der Tab-Liste direkt nach `Position Intelligence` einen neuen Tab `Exit Intelligence` ein. Danach müssen alle bisherigen Tab-Indizes ab 1 um eins erhöht werden. Im neuen `with tabs[1]:`:
```python
render_portfolio_exit()
```
Alternativ kann `render_portfolio_exit()` direkt am Ende von `with tabs[0]:` eingebunden werden, ohne Indizes zu ändern.

## Tests
python -m unittest tests.test_productive_exit_engine tests.test_portfolio_intelligence tests.test_cross_stock_exit_validation

## Performancehinweis
Cross-Stock Validation kann rechenintensiv sein. Der Selector cached die Auswahl innerhalb eines Use-Case-Laufs. Eine persistierte Strategie-Konfiguration kann später ergänzt werden, ist für E2 bewusst noch nicht erforderlich.
