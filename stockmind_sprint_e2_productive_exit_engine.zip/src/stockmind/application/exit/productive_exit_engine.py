from datetime import date
from stockmind.domain.exit.exit_decision import ExitDecision

class ProductiveExitEngine:
    def evaluate(self,item,strategy,source,validation_status,prices):
        reasons=[];status='HOLD'
        if item.current_price is None:
            return ExitDecision(item.position_id,item.symbol,item.entry_profile,'WATCH',strategy.name,source,validation_status,['NO_CURRENT_PRICE'],'Kursdaten prüfen')
        start=date.fromisoformat(item.first_purchase_date);points=[p for p in prices if p.trading_date>=item.first_purchase_date];entry=item.weighted_purchase_price;current=item.current_price
        if current>=entry*(1+strategy.target_pct):reasons.append('TARGET_REACHED')
        if item.holding_days>=strategy.max_holding_days:reasons.append('TIME_LIMIT_REACHED')
        if strategy.stop_loss_pct is not None and current<=entry*(1-strategy.stop_loss_pct):reasons.append('STOP_LOSS_REACHED')
        if strategy.trailing_stop_pct is not None and points:
            peak=max(float(p.high_price if p.high_price is not None else p.close_price) for p in points)
            if peak>entry and current<=peak*(1-strategy.trailing_stop_pct):reasons.append('TRAILING_STOP_REACHED')
        if strategy.score_drop is not None and item.score_change is not None and item.score_change<=-strategy.score_drop:reasons.append('SCORE_DROP_REACHED')
        if strategy.confidence_drop is not None and item.confidence_change is not None and item.confidence_change<=-strategy.confidence_drop:reasons.append('CONFIDENCE_DROP_REACHED')
        if strategy.exit_on_sell and item.current_signal=='SELL':reasons.append('SIGNAL_SELL')
        if strategy.exit_on_hold and item.current_signal in ('HOLD','SELL'):reasons.append('SIGNAL_HOLD')
        if strategy.exit_on_high_risk and item.current_risk=='HIGH':reasons.append('RISK_HIGH')
        if reasons:status='EXIT_REVIEW'
        elif item.remaining_strategy_days<=14 or item.attention_level=='ATTENTION':status='WATCH'
        action='Verkauf prüfen' if status=='EXIT_REVIEW' else 'Position beobachten' if status=='WATCH' else 'Position halten'
        return ExitDecision(item.position_id,item.symbol,item.entry_profile,status,strategy.name,source,validation_status,reasons,action)
