from stockmind.application.exit.cross_stock_exit_validation_use_case import CrossStockExitValidationUseCase
from stockmind.domain.exit.exit_strategy import ExitStrategy

class ExitStrategySelectionUseCase:
    FALLBACK='BASELINE_8PCT_60D'
    def __init__(self,database_path=None):
        self._database_path=database_path
        self._cache={}
    def select(self,profile_name):
        if profile_name in self._cache:return self._cache[profile_name]
        result=CrossStockExitValidationUseCase(self._database_path).analyze(profile_name)
        robust=[x for x in result['summaries'] if x.recommendation_status=='ROBUST_CANDIDATE']
        if robust:
            selected=robust[0];answer=(self._strategy(selected.strategy_name),'CROSS_STOCK_VALIDATED',selected.recommendation_status)
        else:
            answer=(self._strategy(self.FALLBACK),'FALLBACK_BASELINE','INSUFFICIENT_VALIDATION')
        self._cache[profile_name]=answer;return answer
    def _strategy(self,name):
        return next((x for x in ExitStrategy.research_candidates() if x.name==name),ExitStrategy(self.FALLBACK))
