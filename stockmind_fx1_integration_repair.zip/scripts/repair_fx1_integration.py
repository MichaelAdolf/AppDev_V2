from pathlib import Path
import re
import py_compile

EUR_IMPORT = (
    "from stockmind.application.currency.eur_market_data_service "
    "import EurMarketDataService"
)


def remove_all_import_occurrences(text: str) -> str:
    # Remove both valid and accidentally inserted inline occurrences.
    pattern = re.compile(
        r"\s*from\s+stockmind\.application\.currency\."
        r"eur_market_data_service\s+import\s+EurMarketDataService\s*"
    )
    return pattern.sub("\n", text)


def insert_safe_import(text: str) -> str:
    text = remove_all_import_occurrences(text)
    # Insert before the first import. This cannot split a parenthesized import.
    match = re.search(r"(?m)^(?:from|import)\s+", text)
    if not match:
        return EUR_IMPORT + "\n" + text.lstrip("\n")
    return text[: match.start()] + EUR_IMPORT + "\n" + text[match.start() :]


def repair_analyze_stock():
    path = Path("src/stockmind/application/use_cases/analyze_stock_use_case.py")
    text = insert_safe_import(path.read_text(encoding="utf-8"))

    # Remove the direct Yahoo ticker/history block regardless of whitespace.
    pattern = re.compile(
        r"(?ms)^\s*ticker\s*=\s*yf\.Ticker\(\s*symbol\s*\)\s*"
        r"^\s*data\s*=\s*ticker\.history\(\s*period\s*=\s*[\"']5y[\"']\s*\)"
    )
    replacement = (
        "        data = EurMarketDataService().history(\n"
        "            symbol,\n"
        "            period=\"5y\"\n"
        "        ).data_eur"
    )
    if "EurMarketDataService().history(" not in text:
        text, count = pattern.subn(replacement, text, count=1)
        if count != 1:
            raise SystemExit(f"AnalyzeStock Yahoo history block not found: {path}")

    path.write_text(text, encoding="utf-8")
    py_compile.compile(str(path), doraise=True)
    print(f"Repaired and compiled {path}")


def repair_individual_backfill():
    path = Path(
        "src/stockmind/application/strategy/individual_history_backfill_use_case.py"
    )
    text = insert_safe_import(path.read_text(encoding="utf-8"))
    old = re.compile(
        r"yf\.Ticker\(\s*symbol\s*\)\.history\(\s*"
        r"period\s*=\s*self\.ANALYSIS_PERIOD\s*\)\.copy\(\)"
    )
    replacement = (
        "EurMarketDataService().history("
        "symbol, period=self.ANALYSIS_PERIOD).data_eur.copy()"
    )
    if replacement not in text:
        text, count = old.subn(replacement, text, count=1)
        if count != 1:
            raise SystemExit(f"Individual backfill history block not found: {path}")
    path.write_text(text, encoding="utf-8")
    py_compile.compile(str(path), doraise=True)
    print(f"Repaired and compiled {path}")


def repair_indicator_refresh():
    path = Path("scripts/refresh_indicator_chart_data.py")
    text = insert_safe_import(path.read_text(encoding="utf-8"))

    # Replace common direct-yfinance history variants, including a ticker variable.
    direct_patterns = [
        re.compile(
            r"yf\.Ticker\(\s*symbol\s*\)\.history\(\s*"
            r"period\s*=\s*[\"']5y[\"']\s*\)"
        ),
        re.compile(
            r"ticker\.history\(\s*period\s*=\s*[\"']5y[\"']\s*\)"
        ),
    ]
    replacement = 'EurMarketDataService().history(symbol, period="5y").data_eur'
    if replacement not in text:
        changed = 0
        for pattern in direct_patterns:
            text, count = pattern.subn(replacement, text, count=1)
            changed += count
            if count:
                break
        if not changed:
            raise SystemExit(
                f"Indicator Yahoo history call not found in {path}. "
                "Please provide the current file for a direct replacement."
            )

    # Guard the TA library against empty/short histories (e.g. invalid MUV2).
    func_match = re.search(
        r"(?m)^(\s*)def\s+build_indicator_points\s*\(\s*symbol[^)]*\)\s*:\s*$",
        text,
    )
    if not func_match:
        raise SystemExit(f"build_indicator_points function not found: {path}")

    # Insert after the EUR data assignment, inside build_indicator_points.
    guard = "if data.empty or len(data) < 60:\n        return []"
    if guard not in text:
        assignment = re.compile(
            r"(?m)^(\s*)data\s*=\s*EurMarketDataService\(\)\.history\("
            r"symbol,\s*period=[\"']5y[\"']\)\.data_eur\s*$"
        )
        match = assignment.search(text, func_match.end())
        if not match:
            raise SystemExit(f"EUR data assignment not found in {path}")
        indent = match.group(1)
        guard_text = (
            match.group(0)
            + "\n"
            + indent
            + "if data.empty or len(data) < 60:\n"
            + indent
            + "    return []"
        )
        text = text[: match.start()] + guard_text + text[match.end() :]

    # Do not erase existing indicator history when a symbol has no valid data.
    # Patch the common main-loop pattern around replace_for_symbol.
    if "Skipping indicator refresh" not in text:
        pattern = re.compile(
            r"(?m)^(\s*)points\s*=\s*build_indicator_points\(\s*symbol\s*\)\s*$"
        )
        match = pattern.search(text)
        if match:
            indent = match.group(1)
            insertion = (
                match.group(0)
                + "\n"
                + indent
                + "if not points:\n"
                + indent
                + "    print(f\"Skipping indicator refresh for {symbol}: "
                "no valid EUR market data\")\n"
                + indent
                + "    continue"
            )
            text = text[: match.start()] + insertion + text[match.end() :]

    path.write_text(text, encoding="utf-8")
    py_compile.compile(str(path), doraise=True)
    print(f"Repaired and compiled {path}")


repair_analyze_stock()
repair_individual_backfill()
repair_indicator_refresh()
print("FX1 integration repair complete.")
