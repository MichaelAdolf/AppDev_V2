import unittest
import pandas as pd

from stockmind.application.currency.eur_market_data_service import EurMarketDataService


class Fx1ShortHistoryGuardTest(unittest.TestCase):
    def test_empty_frame_remains_empty_after_conversion(self):
        data = pd.DataFrame(columns=["Open", "High", "Low", "Close"])
        rates = pd.Series(dtype=float)
        converted = EurMarketDataService.convert_frame(data, rates)
        self.assertTrue(converted.empty)
        self.assertEqual(converted.attrs["currency"], "EUR")


if __name__ == "__main__":
    unittest.main()
