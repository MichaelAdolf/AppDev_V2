# FX1 integration repair

This repair addresses three observed issues:

1. The previous import insertion split a parenthesized import in `analyze_stock_use_case.py`, causing a SyntaxError.
2. `refresh_indicator_chart_data.py` used a different Yahoo history-call shape and was not patched.
3. Invalid symbols such as `MUV2` returned an empty history, but the TA ADX implementation received fewer than 14 rows and raised `ValueError: negative dimensions are not allowed`.

## Apply

From the project root:

```powershell
python scripts/repair_fx1_integration.py
```

The script repairs and compiles:

- `analyze_stock_use_case.py`
- `individual_history_backfill_use_case.py`
- `refresh_indicator_chart_data.py`

## Verify

```powershell
python -m py_compile `
  src/stockmind/application/use_cases/analyze_stock_use_case.py `
  src/stockmind/application/strategy/individual_history_backfill_use_case.py `
  scripts/refresh_indicator_chart_data.py

python -m unittest `
  tests.test_fx1_short_history_guard `
  tests.test_eur_market_data_service `
  tests.test_chart_data_repository_quality `
  tests.test_exit_strategy_research `
  tests.test_productive_exit_engine
```

## Rebuild

Re-run:

```powershell
python scripts/rebuild_eur_market_data.py
```

For `MUV2`, the expected behavior is now:

```text
Skipping MUV2: no valid chart data
Skipping indicator refresh for MUV2: no valid EUR market data
```

The rebuild should continue with the remaining symbols.
