# Sprint UX1: Navigation & Information Architecture

## Neue Hauptnavigation
- Watchlist
- Top Movers
- Portfolio
- Aktienanalyse
- Strategien

## Sidebar
- Aktie auswählen
- Profil auswählen
- Individual erscheint nur, wenn für die ausgewählte Aktie ein ACTIVE Fitted Profile existiert
- Watchlist verwalten

## Portfolio
Research wurde entfernt. Portfolio enthält nur operative Positionen, Exit Intelligence, Käufe, Verkäufe, Trades und Performance.

## Aktienanalyse
Die links ausgewählte Aktie wird verwendet. Oberhalb der bestehenden Detailanalyse erscheint eine Entscheidungsübersicht mit Conservative, Balanced, Aggressive, Individual, Portfolio-Status und Exit-Status.

## Strategien
Entry-/Individual-Research und Exit-Research sind in einem eigenen Haupttab gebündelt.

## Bewusste Grenzen
- Keine Tradingregel wurde geändert.
- Individual verwendet im darunterliegenden alten Stock-Detail weiterhin sein Base Profile; die neue Summary zeigt das echte Individual-Signal separat.
- Einheitliche große BUY/HOLD/WATCH/EXIT_REVIEW-Cards folgen in UX2.

## Smoke Test
```powershell
streamlit run ui/streamlit_app.py
```

Prüfen:
1. Sidebar-Aktienauswahl steuert Aktienanalyse.
2. Individual erscheint nur bei aktivem Fitted Profile.
3. Portfolio enthält keine Research-Tabs mehr.
4. Strategien enthält Entry- und Exit-Research.
5. Aktienanalyse zeigt Profilvergleich, Portfolio-Status und Exit-Status.
