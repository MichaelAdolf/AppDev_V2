# StockMind 3.0.1 Market Data Hardening

This is a permanent source-code integration for the Home Assistant add-on.
No repair script is required after deployment.

## Protection layers

1. `refresh_chart_data.py` skips incoming rows without a finite Close.
2. `ChartDataRepository` rejects invalid writes, removes legacy NULL rows during initialization, and filters invalid reads.
3. `ExitSimulationUseCase` defensively ignores invalid Close values and invalid OHLC components.

## Deployment

Copy the files into the StockMind repository, increment the add-on version to `3.0.1`, rebuild the add-on image, and install the rebuilt image in Home Assistant.

The repository initialization runs automatically whenever `ChartDataRepository` is instantiated. Existing `close_price IS NULL` rows are therefore removed automatically after the new add-on starts.

## Tests

```powershell
python -m unittest tests.test_chart_data_repository_quality tests.test_exit_simulation_missing_close tests.test_exit_strategy_research tests.test_exit_research_validation tests.test_productive_exit_engine
```

## Expected runtime behavior

- Existing invalid rows are cleaned automatically.
- New invalid Yahoo Finance rows are skipped.
- A single bad symbol or day cannot crash Portfolio Exit Intelligence.
- Empty or wholly invalid periods are excluded from research summaries rather than simulated with invented data.
