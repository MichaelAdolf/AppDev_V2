import math
import unittest
from types import SimpleNamespace

from stockmind.application.exit.exit_simulation_use_case import ExitSimulationUseCase
from stockmind.domain.exit.exit_strategy import ExitStrategy


class ExitSimulationMissingCloseTest(unittest.TestCase):
    def test_invalid_close_rows_are_ignored(self):
        period = SimpleNamespace(
            symbol="TEST",
            profile_name="balanced",
            start_date="2026-01-01",
            entry_price=100.0,
        )
        prices = [
            SimpleNamespace(
                trading_date="2026-01-01",
                close_price=None,
                high_price=None,
                low_price=None,
            ),
            SimpleNamespace(
                trading_date="2026-01-02",
                close_price=math.nan,
                high_price=math.nan,
                low_price=math.nan,
            ),
            SimpleNamespace(
                trading_date="2026-01-03",
                close_price=108.5,
                high_price=109.0,
                low_price=99.0,
            ),
        ]
        result = ExitSimulationUseCase().simulate(
            period, prices, [], ExitStrategy("BASELINE")
        )
        self.assertIsNotNone(result)
        self.assertEqual(result.exit_reason, "TARGET_REACHED")

    def test_only_invalid_rows_return_no_result(self):
        period = SimpleNamespace(
            symbol="TEST",
            profile_name="balanced",
            start_date="2026-01-01",
            entry_price=100.0,
        )
        prices = [SimpleNamespace(
            trading_date="2026-01-01",
            close_price=None,
            high_price=None,
            low_price=None,
        )]
        result = ExitSimulationUseCase().simulate(
            period, prices, [], ExitStrategy("BASELINE")
        )
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
