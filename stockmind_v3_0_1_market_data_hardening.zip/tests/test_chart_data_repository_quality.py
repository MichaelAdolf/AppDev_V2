import math
import sqlite3
import tempfile
import unittest
from pathlib import Path

from stockmind.domain.history.chart_point import ChartPoint
from stockmind.infrastructure.history.chart_data_repository import ChartDataRepository


class ChartDataRepositoryQualityTest(unittest.TestCase):
    def test_invalid_close_values_are_not_persisted(self):
        with tempfile.TemporaryDirectory() as tmp:
            database = str(Path(tmp) / "stockmind.db")
            repository = ChartDataRepository(database)
            repository.upsert_points([
                ChartPoint("TEST", "2026-01-01", None, None, None, None),
                ChartPoint("TEST", "2026-01-02", math.nan, None, None, None),
                ChartPoint("TEST", "2026-01-03", 100.0, None, None, None),
            ])
            points = repository.load_by_symbol("TEST")
            self.assertEqual(len(points), 1)
            self.assertEqual(points[0].close_price, 100.0)

    def test_initialize_removes_legacy_null_close_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            database = str(Path(tmp) / "stockmind.db")
            connection = sqlite3.connect(database)
            connection.execute("""
                CREATE TABLE chart_data (
                    symbol TEXT NOT NULL,
                    trading_date TEXT NOT NULL,
                    close_price REAL,
                    bollinger_upper REAL,
                    bollinger_middle REAL,
                    bollinger_lower REAL,
                    PRIMARY KEY (symbol, trading_date)
                )
            """)
            connection.execute(
                "INSERT INTO chart_data VALUES (?, ?, ?, ?, ?, ?)",
                ("TEST", "2026-01-01", None, None, None, None),
            )
            connection.commit()
            connection.close()

            repository = ChartDataRepository(database)
            self.assertEqual(repository.load_by_symbol("TEST"), [])


if __name__ == "__main__":
    unittest.main()
