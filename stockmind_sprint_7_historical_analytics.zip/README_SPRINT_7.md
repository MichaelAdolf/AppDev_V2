# StockMind Sprint 7: Historical Analytics & Decision UX

## Inhalt

- Historischer Opportunity Replay für jeden auswertbaren Handelstag über 5 Jahre.
- Replay wird getrennt je Symbol und Profil persistiert.
- Kein Look-Ahead bei Indikatoren oder historischer BUY-Perioden-Evidenz.
- Übersichtskurs zeigt alle verfügbaren fünf Jahre.
- Investment Summary mit Signal, aktiver BUY-Periode, Stichprobe und Trefferquote.
- Tab `Historie` und Tab `BUY-Perioden` werden zu `Historie & BUY-Perioden` zusammengeführt.
- BUY-Perioden-Chart: grün = Ziel erreicht, rot = Ziel nicht erreicht, grau = offen.
- Historische Setups bleiben als technische Detailanalyse erhalten.
- `Stärken` wird zu `Erfüllte Kriterien`.

## Reihenfolge der Datenaktualisierung

Vor dem ersten Dashboard-Test:

```powershell
python scripts/refresh_chart_data.py
python scripts/refresh_historical_setups.py
python scripts/refresh_historical_opportunities.py
```

Der Opportunity Replay verwendet die bereits gespeicherten BUY-Perioden. Deshalb
muss `refresh_historical_setups.py` vor dem Replay laufen.

## Tests

```powershell
python -m unittest tests.test_historical_opportunity_repository
python -m unittest tests.test_historical_opportunity_no_lookahead
```

Danach alle bestehenden Regressionstests aus Sprint 1 bis 6 ausführen.

## Laufzeit-Hinweis

Der erstmalige Replay berechnet pro Watchlist-Symbol, Profil und historischem
Handelstag die Analyse neu. Der Vorgang erfolgt synchron und schreibt anschließend
kompakte Tagesergebnisse in `historical_opportunities`. Streamlit liest danach nur
aus SQLite und führt den Replay nicht beim Rendern aus.

## Dashboard

```powershell
streamlit run ui/streamlit_app.py
```

## Deployment

Nach lokalem Test die Ordner `src`, `scripts`, `tests` und `ui` in den relevanten
Projekt- beziehungsweise Add-on-Kontext übernehmen. Auf dem Raspberry anschließend
zuerst Chartdaten, Historical Setups und Historical Opportunities aktualisieren.
