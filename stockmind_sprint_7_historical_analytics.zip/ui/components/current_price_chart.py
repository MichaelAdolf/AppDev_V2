import plotly.graph_objects as go
import streamlit as st
from stockmind.infrastructure.history.chart_data_repository import ChartDataRepository


def render(symbol: str):
    points = ChartDataRepository().load_by_symbol(symbol)
    if not points:
        st.warning("Keine Kursdaten vorhanden.")
        return
    fig = go.Figure(go.Scatter(
        x=[point.trading_date for point in points],
        y=[point.close_price for point in points],
        mode="lines", name="Schlusskurs",
        line=dict(color="#1f77b4", width=2),
    ))
    fig.update_layout(
        title="Kursverlauf über 5 Jahre",
        xaxis_title="Datum", yaxis_title="Kurs",
        hovermode="x unified", showlegend=False,
    )
    st.plotly_chart(fig, width="stretch")
