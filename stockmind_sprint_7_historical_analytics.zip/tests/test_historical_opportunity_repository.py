import tempfile
import unittest
from pathlib import Path
from stockmind.domain.history.historical_opportunity_entry import HistoricalOpportunityEntry
from stockmind.infrastructure.history.historical_opportunity_repository import HistoricalOpportunityRepository

class HistoricalOpportunityRepositoryTest(unittest.TestCase):
    def test_replace_and_load_profile_specific_daily_entries(self):
        with tempfile.TemporaryDirectory() as directory:
            repo=HistoricalOpportunityRepository(str(Path(directory)/"test.db"))
            entries=[HistoricalOpportunityEntry(
                "AAPL","balanced","2026-01-02",72.0,0.75,0.7,30,
                "BUY_PERIODS_REPLAY","MEDIUM","BUY","HIGH"
            )]
            repo.replace_for("AAPL","balanced",entries)
            loaded=repo.load_by_symbol("AAPL","balanced")
            self.assertEqual(len(loaded),1)
            self.assertEqual(loaded[0].trading_date,"2026-01-02")
            self.assertEqual(loaded[0].historical_sample_count,30)

if __name__ == "__main__": unittest.main()
