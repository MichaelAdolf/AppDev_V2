import sqlite3
import tempfile
import unittest
from pathlib import Path
from stockmind.application.history.historical_opportunity_replay_use_case import HistoricalOpportunityReplayUseCase

class HistoricalOpportunityNoLookAheadTest(unittest.TestCase):
    def test_only_completed_periods_before_trading_date_are_used(self):
        with tempfile.TemporaryDirectory() as directory:
            db=str(Path(directory)/"test.db")
            connection=sqlite3.connect(db)
            connection.execute("""CREATE TABLE buy_periods (
                symbol TEXT, profile_name TEXT, analysis_period TEXT,
                outcome TEXT, is_complete INTEGER, window_end_date TEXT
            )""")
            connection.executemany("INSERT INTO buy_periods VALUES (?, ?, ?, ?, ?, ?)",[
                ("AAPL","balanced","5y","TARGET_HIT",1,"2025-01-01"),
                ("AAPL","balanced","5y","NEGATIVE",1,"2025-03-01"),
                ("AAPL","balanced","5y","TARGET_HIT",1,"2026-01-01"),
            ])
            connection.commit(); connection.close()
            replay=HistoricalOpportunityReplayUseCase(db)
            evidence=replay._evidence_before("AAPL","balanced","2025-06-01")
            self.assertEqual(evidence.sample_count,2)
            self.assertEqual(evidence.success_rate,0.5)

if __name__ == "__main__": unittest.main()
