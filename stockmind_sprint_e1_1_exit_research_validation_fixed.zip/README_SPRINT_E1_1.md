# Sprint E1.1: Exit Research Validation

## Änderungen
- Chart-Historie speichert zusätzlich Open, High und Low.
- Bestehende SQLite-Tabelle wird per ALTER TABLE kompatibel erweitert.
- Ein vollständiger Chart-Refresh füllt historische OHLC-Werte rückwirkend.
- Incremental Refresh schreibt neue OHLC-Tage automatisch weiter.
- Target, Stop Loss und Trailing Stop werden auf High/Low simuliert.
- Wenn Target und Schutz-Exit im selben Tagesbalken liegen, gewinnt konservativ der Schutz-Exit.
- Chronologischer 70/30 Train-/Validation-Split.
- Mindeststichprobe: 12 Train- und 5 Validation-Perioden.
- Erste expandierende Walk-Forward-Auswertung mit 5 Validation-Perioden pro Fold.
- Keine Regel wird produktiv aktiviert.

## Einmalige Datenmigration
Nach Integration muss einmal ein vollständiger Chart-Refresh ausgeführt werden:

```powershell
python scripts/refresh_chart_data.py
```

Ohne diesen Lauf bleiben bestehende historische open/high/low-Spalten NULL. Die UI warnt in diesem Fall.

## Tests
```powershell
python -m unittest tests.test_exit_research_validation tests.test_exit_strategy_research tests.test_portfolio_intelligence
```

## Deployment
Vor Upgrade die SQLite-DB sichern und die Add-on-Patchversion erhöhen. Anschließend einmal Full Chart Refresh durchführen; der normale Daily Refresh führt OHLC inkrementell fort.
