# Sprint IND2.1: Individual Daily Pipeline

## Ziel
Ein ACTIVE Individual wird bei jedem normalen Daily Refresh automatisch als viertes Profil verarbeitet. Der manuelle Aufruf von RunIndividualAnalysisUseCase entfällt.

## Incremental Lifecycle
Für ACTIVE Individual läuft derselbe bestehende Lifecycle:
1. Daily BUY Signal upsert
2. offene Historical Setups aktualisieren
3. BUY-Perioden aus persistierten Signalen/Setups neu bilden
4. neuesten Historical Opportunity Replay-Tag ergänzen
5. ältere unvollständige Replay-Outcomes aktualisieren
6. Latest Analysis, Analysis History und Analysis Detail aktualisieren

## Verhalten
- ACTIVE Individual: wird als Profil `individual` ergänzt.
- VALIDATED/CANDIDATE/DEGRADED, aber nicht ACTIVE: sauberer Skip.
- Kein Individual: bestehende drei Profile laufen unverändert.
- Wiederholung am selben Handelstag: vorhandene Repository-Keys und `get_latest_date` verhindern Duplikate.

## Integration
1. ZIP entpacken.
2. Patch anwenden:
```powershell
python scripts/apply_ind2_1_daily_pipeline_patch.py
```
3. Syntax prüfen:
```powershell
python -m py_compile src/stockmind/application/refresh/true_incremental_symbol_refresh_use_case.py src/stockmind/application/history/historical_opportunity_replay_use_case.py src/stockmind/application/refresh/refresh_coordinator.py
```
4. Tests:
```powershell
python -m unittest tests.test_individual_daily_refresh_policy tests.test_individual_daily_refresh_use_case tests.test_fitted_profile_activation
```
5. Normalen Refresh ausführen. Danach muss kein manueller Individual-Aufruf mehr erfolgen.

## Hinweis zur Historie
Die fortlaufende Individual-Historie wächst ab Aktivierung mit jedem Daily Refresh. Der Sprint schreibt nicht rückwirkend alle historischen Individual-Daily-Signale neu, weil die robuste historische Evidenz bereits aus der Out-of-Sample-Validation stammt. Ein optionaler Full Backfill kann später separat ergänzt werden.
