from pathlib import Path


def patch(path_value, replacements, imports=()):
    path = Path(path_value)
    text = path.read_text(encoding="utf-8")
    for anchor, line in imports:
        if line not in text:
            if anchor not in text:
                raise SystemExit(f"Import anchor not found in {path}: {anchor}")
            text = text.replace(anchor, anchor + line, 1)
    for old, new, label in replacements:
        if new in text:
            continue
        if old not in text:
            raise SystemExit(f"Patch block not found in {path}: {label}")
        text = text.replace(old, new, 1)
    path.write_text(text, encoding="utf-8")
    print(f"Patched {path}")


patch(
    "src/stockmind/application/refresh/true_incremental_symbol_refresh_use_case.py",
    [
        (
            "for profile_name in PROFILES:",
            "for profile_name in IndividualDailyRefreshPolicy().profile_names(symbol, PROFILES):",
            "dynamic profile loop",
        ),
        (
            "profile=ProfileRepository().get_by_name(profile_name),",
            "profile=ProfileRepository().get_by_name(profile_name, symbol=symbol),",
            "symbol-aware Daily BUY profile",
        ),
    ],
    imports=[
        (
            "from stockmind.application.history.refresh_buy_periods_use_case import RefreshBuyPeriodsUseCase\n",
            "from stockmind.application.refresh.individual_daily_refresh_policy import IndividualDailyRefreshPolicy\n",
        ),
    ],
)

patch(
    "src/stockmind/application/history/historical_opportunity_replay_use_case.py",
    [
        (
            "profile = ProfileRepository().get_by_name(profile_name)",
            "profile = ProfileRepository().get_by_name(profile_name, symbol=symbol)",
            "symbol-aware replay profile",
        ),
    ],
)

patch(
    "src/stockmind/application/refresh/refresh_coordinator.py",
    [
        (
            'if mode=="bootstrap":BootstrapStockUseCase().execute(symbol)\n                else:DailySymbolRefreshUseCase().execute(symbol)',
            'if mode=="bootstrap":\n                    BootstrapStockUseCase().execute(symbol)\n                    IndividualDailyRefreshUseCase().execute(symbol)\n                else:\n                    DailySymbolRefreshUseCase().execute(symbol)',
            "bootstrap individual analysis",
        ),
    ],
    imports=[
        (
            "from stockmind.application.refresh.daily_symbol_refresh_use_case import DailySymbolRefreshUseCase\n",
            "from stockmind.application.refresh.individual_daily_refresh_use_case import IndividualDailyRefreshUseCase\n",
        ),
    ],
)
