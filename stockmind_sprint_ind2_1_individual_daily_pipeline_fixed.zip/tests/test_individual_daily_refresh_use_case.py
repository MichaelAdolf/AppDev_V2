import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.refresh.individual_daily_refresh_use_case import IndividualDailyRefreshUseCase
class IndividualDailyRefreshUseCaseTest(unittest.TestCase):
 @patch('stockmind.application.refresh.individual_daily_refresh_use_case.RunIndividualAnalysisUseCase')
 @patch('stockmind.application.refresh.individual_daily_refresh_use_case.IndividualDailyRefreshPolicy')
 def test_active_individual_refreshes_latest_analysis(self,policy,runner):
  policy.return_value.evaluate.return_value=SimpleNamespace(symbol='NVDA',enabled=True,profile_id='p1',version=2,reason='ACTIVE_INDIVIDUAL')
  result=IndividualDailyRefreshUseCase().execute('NVDA');runner.return_value.execute.assert_called_once_with('NVDA');self.assertTrue(result.refreshed)
 @patch('stockmind.application.refresh.individual_daily_refresh_use_case.RunIndividualAnalysisUseCase')
 @patch('stockmind.application.refresh.individual_daily_refresh_use_case.IndividualDailyRefreshPolicy')
 def test_missing_active_individual_is_clean_skip(self,policy,runner):
  policy.return_value.evaluate.return_value=SimpleNamespace(symbol='NVDA',enabled=False,profile_id=None,version=None,reason='NO_ACTIVE_INDIVIDUAL')
  result=IndividualDailyRefreshUseCase().execute('NVDA');runner.return_value.execute.assert_not_called();self.assertFalse(result.refreshed)
if __name__=='__main__':unittest.main()
