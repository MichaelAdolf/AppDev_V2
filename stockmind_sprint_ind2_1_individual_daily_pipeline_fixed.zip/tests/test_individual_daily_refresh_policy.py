import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.refresh.individual_daily_refresh_policy import IndividualDailyRefreshPolicy
class IndividualDailyRefreshPolicyTest(unittest.TestCase):
 @patch('stockmind.application.refresh.individual_daily_refresh_policy.FittedProfileRepository')
 def test_active_individual_is_added_as_fourth_profile(self,repo):
  repo.return_value.load_active.return_value=SimpleNamespace(id='p1',version=3)
  profiles=IndividualDailyRefreshPolicy().profile_names('NVDA',['conservative','balanced','aggressive'])
  self.assertEqual(profiles,['conservative','balanced','aggressive','individual'])
 @patch('stockmind.application.refresh.individual_daily_refresh_policy.FittedProfileRepository')
 def test_non_active_individual_keeps_standard_profiles_unchanged(self,repo):
  repo.return_value.load_active.return_value=None
  profiles=IndividualDailyRefreshPolicy().profile_names('NVDA',['conservative','balanced','aggressive'])
  self.assertEqual(profiles,['conservative','balanced','aggressive'])
if __name__=='__main__':unittest.main()
