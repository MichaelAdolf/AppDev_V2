Sprint 5 - UX & Visual Polish

WICHTIG: speech_waveform.dart wird bewusst NICHT verwendet und NICHT benoetigt.

Zu ersetzen:
- lib/features/jarvis/ui/home_screen.dart
- lib/features/jarvis/widgets/ambient_particles.dart
- lib/features/jarvis/widgets/ambient_connections.dart
- lib/features/jarvis/widgets/hud_panel.dart
- lib/features/jarvis/widgets/hud_overlay.dart
- lib/features/jarvis/widgets/conversation_timeline.dart
- lib/features/jarvis/widgets/jarvis_circle.dart

Unveraendert/mitgeliefert nur als Layoutbasis:
- jarvis_layout.dart
- background_grid.dart

Sprint-Ziele:
- Ambient Particles wieder sichtbarer und lebendiger, ohne setState pro Frame.
- Connections staerker, schnellere Shimmer-Bewegung und klarere Nodes.
- Orb-Pulsdauer nach State differenziert.
- COMMAND zeigt READY/LISTENING/PROCESSING/RESPONDING/ERROR statt permanent WAITING.
- ENTITY nutzt Response-State und Fehlerfarbe.
- J.A.R.V.I.S Titel wechselt weich mit State-Farbe.
- Conversation Log: neueste Eintraege zuerst sichtbar, aeltere Turns graduell schwaecher.
- Responsive Layout aus Sprint 3 bleibt unangetastet.
- Audio/Wakeword/Node-RED Logik bleibt unangetastet.

Test:
flutter clean
flutter pub get
flutter analyze
flutter run --profile
