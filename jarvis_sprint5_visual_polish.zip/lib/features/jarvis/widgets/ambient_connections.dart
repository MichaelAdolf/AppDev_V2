import 'dart:math' as math;
import 'package:flutter/material.dart';
class AmbientConnections extends StatefulWidget {const AmbientConnections({super.key});@override State<AmbientConnections> createState()=>_AmbientConnectionsState();}
class _AmbientConnectionsState extends State<AmbientConnections> with SingleTickerProviderStateMixin {
 late final AnimationController _controller;late final List<_HudConnection> _connections;
 @override void initState(){super.initState();_connections=_createConnections();_controller=AnimationController(vsync:this,duration:const Duration(seconds:10))..repeat();}
 List<_HudConnection> _createConnections()=>const [
  _HudConnection(points:[Offset(.04,.13),Offset(.22,.13),Offset(.30,.19),Offset(.46,.19)],phase:0),_HudConnection(points:[Offset(.56,.12),Offset(.73,.12),Offset(.79,.18),Offset(.96,.18)],phase:.09),
  _HudConnection(points:[Offset(.06,.30),Offset(.24,.30),Offset(.30,.36),Offset(.43,.36)],phase:.18),_HudConnection(points:[Offset(.58,.29),Offset(.72,.29),Offset(.78,.35),Offset(.94,.35)],phase:.27),
  _HudConnection(points:[Offset(.03,.49),Offset(.18,.49),Offset(.25,.55),Offset(.40,.55)],phase:.36),_HudConnection(points:[Offset(.60,.49),Offset(.75,.49),Offset(.82,.55),Offset(.97,.55)],phase:.45),
  _HudConnection(points:[Offset(.08,.67),Offset(.23,.67),Offset(.31,.73),Offset(.47,.73)],phase:.54),_HudConnection(points:[Offset(.54,.67),Offset(.69,.67),Offset(.77,.73),Offset(.92,.73)],phase:.63),
  _HudConnection(points:[Offset(.03,.84),Offset(.21,.84),Offset(.27,.89),Offset(.45,.89)],phase:.72),_HudConnection(points:[Offset(.56,.84),Offset(.73,.84),Offset(.80,.90),Offset(.97,.90)],phase:.81),
  _HudConnection(points:[Offset(.18,.23),Offset(.18,.39),Offset(.24,.45)],phase:.14),_HudConnection(points:[Offset(.82,.22),Offset(.82,.40),Offset(.76,.46)],phase:.59),
 ];
 @override void dispose(){_controller.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>IgnorePointer(child:RepaintBoundary(child:CustomPaint(painter:_AmbientConnectionPainter(connections:_connections,animation:_controller),size:Size.infinite)));
}
class _HudConnection {final List<Offset> points;final double phase;const _HudConnection({required this.points,required this.phase});}
class _AmbientConnectionPainter extends CustomPainter {
 final List<_HudConnection> connections;final Animation<double> animation;_AmbientConnectionPainter({required this.connections,required this.animation}):super(repaint:animation);
 @override void paint(Canvas canvas,Size size){for(final c in connections){final path=_path(c.points,size);_base(canvas,path);_glow(canvas,path);_shimmer(canvas,path,c.phase);_nodes(canvas,c.points,size,c.phase);}}
 Path _path(List<Offset> pts,Size s){final p=Path();if(pts.isEmpty)return p;final first=Offset(pts.first.dx*s.width,pts.first.dy*s.height);p.moveTo(first.dx,first.dy);for(var i=1;i<pts.length;i++){final q=Offset(pts[i].dx*s.width,pts[i].dy*s.height);p.lineTo(q.dx,q.dy);}return p;}
 void _base(Canvas c,Path p)=>c.drawPath(p,Paint()..style=PaintingStyle.stroke..strokeWidth=1.15..strokeCap=StrokeCap.round..color=Colors.cyanAccent.withValues(alpha:.13));
 void _glow(Canvas c,Path p)=>c.drawPath(p,Paint()..style=PaintingStyle.stroke..strokeWidth=4..strokeCap=StrokeCap.round..color=Colors.cyanAccent.withValues(alpha:.045)..maskFilter=const MaskFilter.blur(BlurStyle.normal,5));
 void _shimmer(Canvas c,Path p,double phase){for(final m in p.computeMetrics()){if(m.length<=0)continue;final prog=(animation.value+phase)%1;final start=m.length*prog;final span=m.length*.28;final end=math.min(start+span,m.length);final sp=m.extractPath(start,end);c.drawPath(sp,Paint()..style=PaintingStyle.stroke..strokeWidth=2.4..strokeCap=StrokeCap.round..color=Colors.cyanAccent.withValues(alpha:.48)..maskFilter=const MaskFilter.blur(BlurStyle.normal,2));final tangent=m.getTangentForOffset(end);if(tangent!=null){c.drawCircle(tangent.position,6,Paint()..color=Colors.cyanAccent.withValues(alpha:.12)..maskFilter=const MaskFilter.blur(BlurStyle.normal,7));c.drawCircle(tangent.position,2.4,Paint()..color=Colors.cyanAccent.withValues(alpha:.8));}}}
 void _nodes(Canvas c,List<Offset> pts,Size s,double phase){final pulse=.65+.35*math.sin((animation.value+phase)*math.pi*2).abs();for(final p in pts){final pos=Offset(p.dx*s.width,p.dy*s.height);c.drawCircle(pos,6,Paint()..color=Colors.cyanAccent.withValues(alpha:.10*pulse)..maskFilter=const MaskFilter.blur(BlurStyle.normal,7));c.drawCircle(pos,2.2,Paint()..color=Colors.cyanAccent.withValues(alpha:.48*pulse));}}
 @override bool shouldRepaint(covariant _AmbientConnectionPainter old)=>old.connections!=connections||old.animation!=animation;
}
