import 'dart:math' as math;
import 'package:flutter/material.dart';

class AmbientParticles extends StatefulWidget {
  const AmbientParticles({super.key});
  @override State<AmbientParticles> createState()=>_AmbientParticlesState();
}
class _AmbientParticlesState extends State<AmbientParticles> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_Particle> particles;
  @override void initState(){super.initState();particles=List.generate(48,(_)=>_Particle.random());_controller=AnimationController(vsync:this,duration:const Duration(seconds:22))..repeat();}
  @override void dispose(){_controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>RepaintBoundary(child:CustomPaint(painter:_ParticlePainter(particles,_controller),size:Size.infinite));
}
class _Particle {final double x,y,radius,speed,phase;const _Particle({required this.x,required this.y,required this.radius,required this.speed,required this.phase});
 factory _Particle.random(){final r=math.Random();return _Particle(x:r.nextDouble(),y:r.nextDouble(),radius:1.1+r.nextDouble()*2.4,speed:.035+r.nextDouble()*.07,phase:r.nextDouble()*math.pi*2);}}
class _ParticlePainter extends CustomPainter {
 final List<_Particle> particles;final Animation<double> animation;
 _ParticlePainter(this.particles,this.animation):super(repaint:animation);
 @override void paint(Canvas canvas,Size size){final t=animation.value;for(final p in particles){final y=(p.y+t*p.speed)%1.0;final x=(p.x+math.sin(t*math.pi*2+p.phase)*.004).clamp(0.0,1.0);final pulse=.72+.28*math.sin(t*math.pi*2+p.phase).abs();final pos=Offset(x*size.width,y*size.height);canvas.drawCircle(pos,p.radius*2.8,Paint()..color=Colors.cyanAccent.withValues(alpha:.025*pulse)..maskFilter=const MaskFilter.blur(BlurStyle.normal,5));canvas.drawCircle(pos,p.radius,Paint()..color=Colors.cyanAccent.withValues(alpha:.25*pulse));}}
 @override bool shouldRepaint(covariant _ParticlePainter oldDelegate)=>oldDelegate.particles!=particles||oldDelegate.animation!=animation;
}
