import 'package:flutter/material.dart';
class HudOverlay extends StatelessWidget {const HudOverlay({super.key});@override Widget build(BuildContext context)=>const IgnorePointer(child:RepaintBoundary(child:CustomPaint(painter:_HudPainter(),size:Size.infinite)));}
class _HudPainter extends CustomPainter {const _HudPainter();
 @override void paint(Canvas c,Size s){_corners(c,s);_lines(c,s);_centerMarks(c,s);}
 void _corners(Canvas c,Size s){final glow=Paint()..color=Colors.cyanAccent.withValues(alpha:.08)..strokeWidth=4..maskFilter=const MaskFilter.blur(BlurStyle.normal,4);final p=Paint()..color=Colors.cyanAccent.withValues(alpha:.26)..strokeWidth=1.3;const m=15.0,l=45.0;for(final q in <List<Offset>>[[const Offset(m,m),const Offset(m+l,m)],[const Offset(m,m),const Offset(m,m+l)],[Offset(s.width-m,m),Offset(s.width-m-l,m)],[Offset(s.width-m,m),Offset(s.width-m,m+l)],[Offset(m,s.height-m),Offset(m+l,s.height-m)],[Offset(m,s.height-m),Offset(m,s.height-m-l)],[Offset(s.width-m,s.height-m),Offset(s.width-m-l,s.height-m)],[Offset(s.width-m,s.height-m),Offset(s.width-m,s.height-m-l)]]){c.drawLine(q[0],q[1],glow);c.drawLine(q[0],q[1],p);}}
 void _lines(Canvas c,Size s){final p=Paint()..color=Colors.cyanAccent.withValues(alpha:.045)..strokeWidth=.8;for(double y=100;y<s.height;y+=80)c.drawLine(Offset(40,y),Offset(s.width-40,y),p);}
 void _centerMarks(Canvas c,Size s){final p=Paint()..color=Colors.cyanAccent.withValues(alpha:.16)..strokeWidth=1;final x=s.width/2;c.drawLine(Offset(x-16,22),Offset(x-5,22),p);c.drawLine(Offset(x+5,22),Offset(x+16,22),p);}
 @override bool shouldRepaint(covariant _HudPainter old)=>false;
}
