# Sprint S2.1 Fitted Profile Validation

- Validiert gespeicherte Fitted Candidates chronologisch mit 70 % Train und 30 % Validation.
- Benchmark ist das unveränderte Ausgangsprofil derselben Aktie.
- Walk-Forward nutzt drei expandierende Zeitfenster.
- Status: VALIDATED, DEGRADED, FAILED oder INSUFFICIENT_SAMPLE.
- Mindeststichprobe: 12 Train- und 5 Validation-Perioden.
- VALIDATED erlaubt noch keine Aktivierung. Aktivierung folgt in S2.2.

Tests:
python -m unittest tests.test_fitted_profile_validation tests.test_fitted_profile_search tests.test_profile_validation
