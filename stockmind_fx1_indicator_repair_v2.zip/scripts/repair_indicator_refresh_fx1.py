from pathlib import Path
import re
import py_compile

path = Path('scripts/refresh_indicator_chart_data.py')
text = path.read_text(encoding='utf-8')

IMPORT = 'from stockmind.application.currency.eur_market_data_service import EurMarketDataService'
if IMPORT not in text:
    # Safe insertion before first import, never inside a parenthesized import.
    m = re.search(r'(?m)^(?:from|import)\s+', text)
    text = (text[:m.start()] + IMPORT + '\n' + text[m.start():]) if m else IMPORT + '\n' + text

# Find the function using a deliberately tolerant signature search.
func = re.search(r'(?m)^(?P<indent>\s*)def\s+build_indicator_points\s*\([^)]*\)\s*:', text)
if not func:
    raise SystemExit('build_indicator_points function not found; current file differs materially.')
base_indent = func.group('indent')
body_indent = base_indent + '    '

# Determine function end.
start = func.end()
next_def = re.search(r'(?m)^' + re.escape(base_indent) + r'def\s+', text[start:])
end = start + next_def.start() if next_def else len(text)
body = text[start:end]

# Replace any common Yahoo-history pattern in this function body.
patterns = [
    re.compile(r'yf\.Ticker\(\s*symbol\s*\)\.history\([^)]*period\s*=\s*[\"\']5y[\"\'][^)]*\)', re.S),
    re.compile(r'ticker\.history\([^)]*period\s*=\s*[\"\']5y[\"\'][^)]*\)', re.S),
]
replacement = 'EurMarketDataService().history(symbol, period="5y").data_eur'
if replacement not in body:
    changed = 0
    for pattern in patterns:
        body, n = pattern.subn(replacement, body, count=1)
        changed += n
        if n:
            break
    if not changed:
        # Fall back to replacing the first assignment whose RHS contains .history and period 5y.
        assignment = re.compile(r'(?m)^(\s*)data\s*=.*history.*5y.*$')
        m = assignment.search(body)
        if not m:
            raise SystemExit('Could not locate the 5y market-history assignment inside build_indicator_points.')
        body = body[:m.start()] + m.group(1) + 'data = ' + replacement + body[m.end():]

# Add guard directly after the EUR data assignment with the actual indentation.
if 'if data.empty or len(data) < 60:' not in body:
    assignment = re.search(r'(?m)^(\s*)data\s*=\s*EurMarketDataService\(\)\.history\(symbol, period="5y"\)\.data_eur\s*$', body)
    if not assignment:
        raise SystemExit('EUR data assignment found but could not insert short-history guard.')
    indent = assignment.group(1)
    replacement_assignment = assignment.group(0) + '\n' + indent + 'if data.empty or len(data) < 60:\n' + indent + '    return []'
    body = body[:assignment.start()] + replacement_assignment + body[assignment.end():]

text = text[:start] + body + text[end:]

# Guard the main loop. Support multiline call formatting.
if 'Skipping indicator refresh for' not in text:
    points_call = re.search(r'(?ms)^(?P<indent>\s*)points\s*=\s*build_indicator_points\(\s*symbol\s*\)\s*$', text)
    if points_call:
        indent = points_call.group('indent')
        guarded = points_call.group(0) + '\n' + indent + 'if not points:\n' + indent + '    print(f"Skipping indicator refresh for {symbol}: no valid EUR market data")\n' + indent + '    continue'
        text = text[:points_call.start()] + guarded + text[points_call.end():]

path.write_text(text, encoding='utf-8')
py_compile.compile(str(path), doraise=True)
print(f'Repaired and compiled {path}')
