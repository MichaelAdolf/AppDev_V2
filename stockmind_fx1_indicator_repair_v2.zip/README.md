# FX1 Indicator Repair v2
Run from the project root:

```powershell
python scripts/repair_indicator_refresh_fx1.py
python -m py_compile scripts/refresh_indicator_chart_data.py
python scripts/rebuild_eur_market_data.py
```

Expected for invalid symbols such as MUV2:
`Skipping indicator refresh for MUV2: no valid EUR market data`
