from dataclasses import dataclass


@dataclass(frozen=True)
class ProfileSignalMailItem:
    profile_name: str
    signal: str
    target_hit_rate: float
    complete_period_count: int
    sample_quality: str


@dataclass(frozen=True)
class StockMailItem:
    symbol: str
    company_name: str
    profiles: list[ProfileSignalMailItem]
    has_buy_signal: bool


@dataclass(frozen=True)
class DailyMailResult:
    trading_date: str | None
    previous_trading_date: str | None
    subject: str
    buy_signal_stocks: list[StockMailItem]
    changes: list[dict]
    watchlist: list[StockMailItem]
