from stockmind.application.notifications.daily_mail_renderer import DailyMailRenderer
from stockmind.application.notifications.daily_mail_use_case import DailyMailUseCase
from stockmind.infrastructure.notifications.daily_mail_log_repository import DailyMailLogRepository
from stockmind.infrastructure.notifications.smtp_mail_sender import SmtpMailSender

class SendDailyMailUseCase:
    def execute(self,force=False):
        result=DailyMailUseCase().build();log=DailyMailLogRepository()
        if result.trading_date and log.was_sent(result.trading_date) and not force:
            return {"status":"skipped","reason":"already_sent","trading_date":result.trading_date,"subject":result.subject,"buy_signal_stock_count":len(result.buy_signal_stocks),"change_count":len(result.changes)}
        html=DailyMailRenderer().render(result);SmtpMailSender().send(result.subject,html);log.mark_sent(result.trading_date,result.subject)
        return {"status":"sent","trading_date":result.trading_date,"subject":result.subject,"buy_signal_stock_count":len(result.buy_signal_stocks),"change_count":len(result.changes)}
    def preview(self):
        result=DailyMailUseCase().build();return result,DailyMailRenderer().render(result)
