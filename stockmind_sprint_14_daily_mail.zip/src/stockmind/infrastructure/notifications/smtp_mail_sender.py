import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class SmtpMailSender:
    def __init__(self):
        self.host=os.getenv("SMTP_HOST","").strip();self.port=int(os.getenv("SMTP_PORT","587"));self.user=os.getenv("SMTP_USER","").strip();self.password=os.getenv("SMTP_PASS","");self.recipient=os.getenv("SMTP_TO","").strip();self.sender=os.getenv("SMTP_FROM",self.user).strip()
    def validate(self):
        missing=[name for name,value in (("SMTP_HOST",self.host),("SMTP_USER",self.user),("SMTP_PASS",self.password),("SMTP_TO",self.recipient),("SMTP_FROM",self.sender)) if not value]
        if missing:raise ValueError("Fehlende SMTP-Konfiguration: "+", ".join(missing))
    def send(self,subject,html):
        self.validate();msg=MIMEMultipart("alternative");msg["Subject"]=subject;msg["From"]=self.sender;msg["To"]=self.recipient;msg.attach(MIMEText(html,"html","utf-8"))
        with smtplib.SMTP(self.host,self.port) as server:
            server.ehlo();server.starttls();server.ehlo();server.login(self.user,self.password);server.sendmail(self.sender,[self.recipient],msg.as_string())
