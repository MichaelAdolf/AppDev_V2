import argparse
from stockmind.application.notifications.send_daily_mail_use_case import SendDailyMailUseCase

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--force",action="store_true");args=parser.parse_args();print(SendDailyMailUseCase().execute(force=args.force))
if __name__=="__main__":main()
