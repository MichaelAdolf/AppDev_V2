# StockMind Sprint 14: Daily Trading Mail & Notification Automation

## Ziel

Die Daily Mail liest ausschließlich die aktuellen StockMind-V2-Ergebnisse. Es gibt
keine separate Rule Engine, BUY-Periodenberechnung oder Trefferquotenlogik in der
Mail-Pipeline.

## Mailbereiche

1. Header mit Datenstand und kompakten Counts
2. Aktuelle Kaufsignale: Nur Aktien mit mindestens einem BUY in Conservative,
   Balanced oder Aggressive. Bei BUY werden Target-Hit-Rate, vollständige
   Periodenanzahl und Sample Quality gezeigt.
3. Änderungen zum vorherigen verfügbaren Handelstag
4. Gesamte Watchlist mit Signalstatus aller drei Profile

## Trigger

Manuell:

```powershell
python scripts/send_daily_mail.py
python scripts/send_daily_mail.py --force
```

API:

```text
GET  /notifications/daily-mail/preview
POST /notifications/daily-mail
POST /notifications/daily-mail?force=true
```

Node-RED sollte produktiv erst `/refresh` aufrufen und nur nach erfolgreicher Antwort
`/notifications/daily-mail` auslösen.

## SMTP Environment

```text
SMTP_HOST
SMTP_PORT
SMTP_USER
SMTP_PASS
SMTP_TO
SMTP_FROM   optional; Default = SMTP_USER
```

Credentials werden nicht im Code gespeichert.

`config.yaml` und `run.sh` waren für die Kernimplementierung nicht notwendig. Für das
Home-Assistant-Add-on müssen die SMTP-Werte später in dessen tatsächlicher Add-on-
Konfiguration/Startumgebung als Environment bereitgestellt werden. Der genaue Pfad
hängt von deinem lokalen Add-on-Build-Kontext ab.

## Deduplizierung

Die Tabelle `daily_mail_log` verhindert einen zweiten automatischen Versand desselben
`trading_date`. `force=true` bzw. `--force` erlaubt einen bewussten erneuten Versand.

## Tests

```powershell
python -m unittest tests.test_daily_mail_use_case
```

Danach API starten und zunächst den Preview-Endpunkt prüfen. Für den ersten echten
Versand anschließend SMTP-Environment setzen und den POST-Endpunkt aufrufen.
