# Sprint E1 Exit Strategy Research

## Inhalt
- Simulation auf vollständigen historischen BUY-Perioden
- Baseline +8 % / Tag 60
- Stop Loss 5 % und 8 %
- Trailing Stop 4 % und 6 %
- Score Drop 10 und 15 Punkte
- Confidence Drop 15 Prozentpunkte
- Exit bei HOLD, SELL oder Risk HIGH
- Vergleichskennzahlen: positive Rate, Ziel vor Exit, Return, Median, Haltedauer, Drawdown, Best/Worst

## Wichtig
Dies ist reine Research-Logik. Keine Strategie wird produktiv aktiviert, keine Position automatisch verkauft und die Daily Mail bleibt unverändert.

## Streamlit Integration
In `ui/components/portfolio_view.py` ergänzen:
```python
from components.exit_strategy_research_view import render as render_exit_research
```
Dann einen zusätzlichen Portfolio-Tab `Exit Strategy Research` anlegen und darin `render_exit_research()` aufrufen. Alternativ kann die View zunächst separat getestet werden.

## Test
`python -m unittest tests.test_exit_strategy_research tests.test_portfolio_intelligence`
