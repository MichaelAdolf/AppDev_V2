from dataclasses import dataclass

@dataclass(frozen=True)
class FxRate:
    trading_date: str
    source_currency: str
    target_currency: str
    rate: float
