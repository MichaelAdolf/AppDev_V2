import math,sqlite3
from datetime import datetime
from stockmind.shared.config.settings import Settings
class CurrencyRepository:
 def __init__(self,database_path=None):self._database_path=database_path or Settings.load().database_path;self._initialize()
 def _connect(self):c=sqlite3.connect(self._database_path);c.row_factory=sqlite3.Row;return c
 def _initialize(self):
  c=self._connect();c.executescript("""
  CREATE TABLE IF NOT EXISTS market_instruments(symbol TEXT PRIMARY KEY,source_currency TEXT NOT NULL,updated_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS fx_rates(trading_date TEXT NOT NULL,source_currency TEXT NOT NULL,target_currency TEXT NOT NULL,rate REAL NOT NULL,PRIMARY KEY(trading_date,source_currency,target_currency));
  """);c.commit();c.close()
 def save_instrument_currency(self,symbol,currency):
  c=self._connect();c.execute("INSERT OR REPLACE INTO market_instruments VALUES(?,?,?)",(symbol.upper(),currency.upper(),datetime.now().isoformat(timespec='seconds')));c.commit();c.close()
 def load_instrument_currency(self,symbol):
  c=self._connect();r=c.execute('SELECT source_currency FROM market_instruments WHERE symbol=?',(symbol.upper(),)).fetchone();c.close();return r[0] if r else None
 def replace_rates(self,source,target,series):
  if source==target:return
  rows=[]
  for index,value in series.items():
   if value is not None and math.isfinite(float(value)):rows.append((index.date().isoformat(),source,target,float(value)))
  c=self._connect();c.executemany('INSERT OR REPLACE INTO fx_rates VALUES(?,?,?,?)',rows);c.commit();c.close()
