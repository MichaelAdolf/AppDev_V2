from pathlib import Path
import re


def add_import(text, import_line):
    if import_line in text:
        return text
    lines = text.splitlines()
    insert_at = 0
    while insert_at < len(lines) and (
        lines[insert_at].startswith("import ")
        or lines[insert_at].startswith("from ")
        or not lines[insert_at].strip()
    ):
        insert_at += 1
    lines.insert(insert_at, import_line)
    return "\n".join(lines) + "\n"


def patch_analyze_stock():
    path = Path("src/stockmind/application/use_cases/analyze_stock_use_case.py")
    text = path.read_text(encoding="utf-8")
    text = add_import(
        text,
        "from stockmind.application.currency.eur_market_data_service import EurMarketDataService",
    )
    pattern = re.compile(
        r"\s*ticker\s*=\s*yf\.Ticker\(\s*symbol\s*\)\s*"
        r"data\s*=\s*ticker\.history\(\s*period\s*=\s*[\"']5y[\"']\s*\)",
        re.MULTILINE,
    )
    replacement = (
        "\n        data = EurMarketDataService().history(\n"
        "            symbol,\n"
        "            period=\"5y\"\n"
        "        ).data_eur"
    )
    if ".data_eur" not in text:
        text, count = pattern.subn(replacement, text, count=1)
        if count != 1:
            raise SystemExit(f"AnalyzeStock Yahoo history block not found: {path}")
    path.write_text(text, encoding="utf-8")
    print(f"Patched {path}")


def patch_individual_backfill():
    path = Path(
        "src/stockmind/application/strategy/individual_history_backfill_use_case.py"
    )
    text = path.read_text(encoding="utf-8")
    text = add_import(
        text,
        "from stockmind.application.currency.eur_market_data_service import EurMarketDataService",
    )
    pattern = re.compile(
        r"yf\.Ticker\(symbol\)\.history\(period=self\.ANALYSIS_PERIOD\)\.copy\(\)"
    )
    replacement = (
        "EurMarketDataService().history("
        "symbol, period=self.ANALYSIS_PERIOD).data_eur.copy()"
    )
    if replacement not in text:
        text, count = pattern.subn(replacement, text, count=1)
        if count != 1:
            raise SystemExit(f"Individual backfill history block not found: {path}")
    path.write_text(text, encoding="utf-8")
    print(f"Patched {path}")


def patch_indicator_refresh():
    path = Path("scripts/refresh_indicator_chart_data.py")
    text = path.read_text(encoding="utf-8")
    text = add_import(
        text,
        "from stockmind.application.currency.eur_market_data_service import EurMarketDataService",
    )
    pattern = re.compile(
        r"yf\.Ticker\(symbol\)\.history\(\s*period\s*=\s*[\"']5y[\"']\s*\)"
    )
    replacement = (
        "EurMarketDataService().history(symbol, period=\"5y\").data_eur"
    )
    if replacement not in text:
        text, count = pattern.subn(replacement, text, count=1)
        if count != 1:
            raise SystemExit(f"Indicator history block not found: {path}")
    path.write_text(text, encoding="utf-8")
    print(f"Patched {path}")


patch_analyze_stock()
patch_individual_backfill()
patch_indicator_refresh()
