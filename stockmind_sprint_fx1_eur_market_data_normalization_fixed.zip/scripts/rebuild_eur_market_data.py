from scripts.refresh_chart_data import main as refresh_chart
from scripts.refresh_indicator_chart_data import main as refresh_indicators

def main():
 print('Rebuilding all market history in EUR...');refresh_chart();refresh_indicators();print('EUR market-data rebuild complete. Run the normal StockMind refresh next to rebuild dependent histories.')
if __name__=='__main__':main()
