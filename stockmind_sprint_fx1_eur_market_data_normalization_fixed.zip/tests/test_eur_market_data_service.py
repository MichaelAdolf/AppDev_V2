import unittest
import pandas as pd
from stockmind.application.currency.eur_market_data_service import EurMarketDataService
class EurMarketDataServiceTest(unittest.TestCase):
 def test_ohlc_is_converted_with_historical_rate(self):
  index=pd.to_datetime(['2026-01-02','2026-01-05']);data=pd.DataFrame({'Open':[100,110],'High':[105,115],'Low':[95,108],'Close':[102,112]},index=index);rates=pd.Series([.9,.8],index=index);eur=EurMarketDataService.convert_frame(data,rates);self.assertAlmostEqual(eur.loc[index[0],'Close'],91.8);self.assertAlmostEqual(eur.loc[index[1],'High'],92.0);self.assertEqual(eur.attrs['currency'],'EUR')
if __name__=='__main__':unittest.main()
