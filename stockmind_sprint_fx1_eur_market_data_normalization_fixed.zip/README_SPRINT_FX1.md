# FX1: EUR Market Data Normalization

## Invariant
All StockMind market prices are stored and processed in EUR. Original source OHLC, source currency and historical FX rate remain persisted for auditing. Manual portfolio purchase/sale prices continue to be interpreted as EUR.

## Historical FX
Each trading day uses its historical source-currency-to-EUR rate. Direct Yahoo pair `<SOURCE>EUR=X` is preferred; fallback is inverse `EUR<SOURCE>=X`. Exchange holidays use the last known FX rate. Only an initial gap may use the first available quote.

## Integration
1. Back up the SQLite database.
2. Extract package.
3. Apply integration:
```powershell
python scripts/apply_fx1_integration_patch.py
```
4. Tests:
```powershell
python -m unittest tests.test_eur_market_data_service tests.test_chart_data_repository_quality tests.test_exit_strategy_research tests.test_productive_exit_engine
```
5. Full rebuild (mandatory once):
```powershell
python scripts/rebuild_eur_market_data.py
```
6. Run normal `/refresh` to rebuild dependent BUY periods, opportunities, latest analyses and active Individual histories.
7. Increment add-on version and rebuild the HA image.

## Critical migration rule
Do not mix old local-currency rows with new EUR rows. The one-time full rebuild is mandatory for the existing database. Standard and Individual analyses must be regenerated after the rebuild.

## Portfolio
Existing manually entered purchase prices are assumed to already be EUR and are not converted. Current market prices become EUR, so P/L comparisons become currency-consistent.
