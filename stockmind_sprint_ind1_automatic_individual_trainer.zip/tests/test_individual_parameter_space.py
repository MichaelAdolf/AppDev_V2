import unittest
from stockmind.application.strategy.individual_parameter_space import IndividualParameterSpace
class IndividualParameterSpaceTest(unittest.TestCase):
 def test_space_is_broad_and_independent(self):
  space=IndividualParameterSpace();values=space.combinations();self.assertIn((15.0,.05,10.0,5.0),values);self.assertIn((45.0,.5,40.0,45.0),values);self.assertGreater(len(values),5000);self.assertEqual(len(space.sampled(180)),180)
if __name__=='__main__':unittest.main()
