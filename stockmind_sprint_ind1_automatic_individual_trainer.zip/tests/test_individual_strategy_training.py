import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.strategy.individual_strategy_training_use_case import IndividualStrategyTrainingUseCase
class IndividualStrategyTrainingTest(unittest.TestCase):
 @patch('stockmind.application.strategy.individual_strategy_training_use_case.FittedProfileValidationUseCase')
 @patch('stockmind.application.strategy.individual_strategy_training_use_case.SaveFittedProfileCandidateUseCase')
 @patch('stockmind.application.strategy.individual_strategy_training_use_case.IndividualStrategyOptimizer')
 def test_best_validated_candidate_is_proposed(self,optimizer,save,validator):
  candidate=SimpleNamespace(objective_score=70,rsi_oversold_threshold=25,bollinger_lower_threshold=.2,adx_trend_strength_threshold=20,stochastic_oversold_threshold=15)
  optimizer.return_value.optimize.return_value={'searched_candidate_count':180,'candidates':[candidate]};save.return_value.execute.return_value=SimpleNamespace(id='p1',version=1)
  metrics=SimpleNamespace(target_hit_rate=.8,sample_count=8);validator.return_value.validate.return_value=SimpleNamespace(status='VALIDATED',validation=metrics,benchmark_validation=SimpleNamespace(target_hit_rate=.7),stable_fold_rate=.67)
  result=IndividualStrategyTrainingUseCase().execute('NVDA');self.assertEqual(result.status,'PROPOSAL_READY');self.assertEqual(result.proposed_profile_id,'p1')
if __name__=='__main__':unittest.main()
