from dataclasses import dataclass

@dataclass(frozen=True)
class IndividualTrainingCandidateResult:
    profile_id: str
    version: int
    status: str
    objective_score: float
    validation_target_hit_rate: float
    validation_sample_count: int
    benchmark_target_hit_rate: float
    stable_fold_rate: float
    rsi_oversold_threshold: float
    bollinger_lower_threshold: float
    adx_trend_strength_threshold: float
    stochastic_oversold_threshold: float

@dataclass(frozen=True)
class IndividualStrategyTrainingResult:
    symbol: str
    status: str
    searched_candidate_count: int
    validated_candidate_count: int
    proposed_profile_id: str | None
    proposed_version: int | None
    candidates: list[IndividualTrainingCandidateResult]
    reasons: list[str]
