from dataclasses import dataclass
from itertools import product

@dataclass(frozen=True)
class IndividualParameterSpace:
    rsi_values: tuple[float,...] = tuple(float(x) for x in range(15,46,3))
    bollinger_values: tuple[float,...] = tuple(round(x/100,2) for x in range(5,51,5))
    adx_values: tuple[float,...] = tuple(float(x) for x in range(10,41,5))
    stochastic_values: tuple[float,...] = tuple(float(x) for x in range(5,46,5))

    def combinations(self):
        return list(product(self.rsi_values,self.bollinger_values,self.adx_values,self.stochastic_values))

    def sampled(self,max_candidates=180):
        values=self.combinations()
        if len(values)<=max_candidates:return values
        # Deterministic, even coverage over the entire independent search space.
        step=(len(values)-1)/(max_candidates-1)
        return [values[round(i*step)] for i in range(max_candidates)]
