import pandas as pd
import streamlit as st
from stockmind.application.strategy.activate_fitted_profile_use_case import ActivateFittedProfileUseCase,DeactivateFittedProfileUseCase
from stockmind.application.strategy.cross_stock_profile_validation_use_case import CrossStockProfileValidationUseCase
from stockmind.application.strategy.fitted_profile_candidate_use_case import SaveFittedProfileCandidateUseCase
from stockmind.application.strategy.fitted_profile_search_use_case import FittedProfileSearchUseCase
from stockmind.application.strategy.fitted_profile_signal_use_case import FittedProfileSignalUseCase
from stockmind.application.strategy.fitted_profile_validation_use_case import FittedProfileValidationUseCase
from stockmind.application.strategy.individual_strategy_training_use_case import IndividualStrategyTrainingUseCase
from stockmind.application.strategy.profile_validation_use_case import ProfileValidationUseCase
from stockmind.infrastructure.strategy.fitted_profile_repository import FittedProfileRepository
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository

def render():
 st.subheader('Entry & Individual Strategy');st.caption('Individual wird unabhängig von den drei Standardprofilen in einem breiten Parameterraum trainiert. Standardprofile dienen nur als Benchmark.')
 stocks=[x for x in WatchlistRepository().load_all() if x.active];labels={f'{x.company_name} ({x.symbol})':x.symbol for x in stocks}
 if not labels:st.info('Keine aktiven Watchlist-Aktien.');return
 trainer,management,advanced,standards=st.tabs(['Individual automatisch trainieren','Individual verwalten','Advanced Research','Standardprofile'])
 with trainer:
  label=st.selectbox('Aktie',list(labels),key='individual_training_symbol');a,b=st.columns(2);max_candidates=a.slider('Parameterkombinationen',60,300,180,20);top_candidates=b.slider('Top-Kandidaten validieren',3,12,8)
  st.caption('Suchraum: RSI 15–45, Bollinger 0,05–0,50, ADX 10–40, Stochastic 5–45. Die Auswahl ist unabhängig von Conservative, Balanced und Aggressive.')
  if st.button('Individual Strategy automatisch trainieren',type='primary'):
   with st.spinner('Breiter Parameterraum, Validation und Walk-Forward werden ausgeführt...'):result=IndividualStrategyTrainingUseCase().execute(labels[label],max_candidates,top_candidates)
   st.session_state['individual_training_result']=result
  result=st.session_state.get('individual_training_result')
  if result:
   if result.status=='PROPOSAL_READY':st.success(f'Robuster Vorschlag gefunden: {result.symbol} Individual v{result.proposed_version}')
   else:st.warning('Kein robuster Individual-Kandidat gefunden. Die Standardprofile bleiben die beste verfügbare Basis.')
   c1,c2,c3=st.columns(3);c1.metric('Untersucht',result.searched_candidate_count);c2.metric('Validiert',result.validated_candidate_count);c3.metric('Status',result.status)
   st.dataframe(pd.DataFrame([{'Version':x.version,'Status':x.status,'RSI':x.rsi_oversold_threshold,'Bollinger':x.bollinger_lower_threshold,'ADX':x.adx_trend_strength_threshold,'Stochastic':x.stochastic_oversold_threshold,'Validation Hit %':round(x.validation_target_hit_rate*100,1),'Validation Fälle':x.validation_sample_count,'Benchmark %':round(x.benchmark_target_hit_rate*100,1),'Stable Folds %':round(x.stable_fold_rate*100,1),'Objective':round(x.objective_score,1),'Vorschlag':'JA' if x.profile_id==result.proposed_profile_id else ''} for x in result.candidates]),width='stretch',hide_index=True)
   if result.proposed_profile_id:
    confirm=st.checkbox('Ich bestätige die Aktivierung des vorgeschlagenen VALIDATED Individual-Profils.',key='confirm_individual_proposal')
    if st.button('Vorgeschlagenes Individual-Profil aktivieren',disabled=not confirm):p=ActivateFittedProfileUseCase().execute(result.proposed_profile_id);st.success(f'{p.symbol} Individual v{p.version} ist jetzt ACTIVE.');st.rerun()
 with management:
  label=st.selectbox('Aktie verwalten',list(labels),key='individual_manage_symbol');symbol=labels[label];repo=FittedProfileRepository();active=repo.load_active(symbol);profiles=repo.load_by_symbol(symbol)
  if active:
   signal=FittedProfileSignalUseCase().evaluate(symbol);st.success(f'Aktiv: {symbol} Individual v{active.version} · {signal.signal}');st.dataframe(pd.DataFrame([{'RSI':active.rsi_oversold_threshold,'Bollinger':active.bollinger_lower_threshold,'ADX':active.adx_trend_strength_threshold,'Stochastic':active.stochastic_oversold_threshold,'Bedingungen':f'{signal.matched_conditions}/{signal.required_conditions}'}]),width='stretch',hide_index=True)
   if st.button('Individual deaktivieren'):DeactivateFittedProfileUseCase().execute(symbol);st.rerun()
  else:st.info('Kein Individual-Profil aktiv.')
  st.dataframe(pd.DataFrame([{'Version':x.version,'Status':x.status,'RSI':x.rsi_oversold_threshold,'Bollinger':x.bollinger_lower_threshold,'ADX':x.adx_trend_strength_threshold,'Stochastic':x.stochastic_oversold_threshold} for x in profiles]),width='stretch',hide_index=True) if profiles else st.caption('Keine Versionen vorhanden.')
 with advanced:
  st.warning('Advanced Research ist optional. Der Standardworkflow ist das automatische Training.')
  label=st.selectbox('Aktie Advanced',list(labels),key='advanced_symbol');base=st.selectbox('Benchmarkprofil',['conservative','balanced','aggressive'],index=1);limit=st.slider('Kandidaten',5,25,15,key='advanced_limit')
  if st.button('Gezielte Kandidatensuche'):st.session_state['fitted_rows']=FittedProfileSearchUseCase().search(labels[label],base,limit)
  rows=st.session_state.get('fitted_rows',[])
  if rows:st.dataframe(pd.DataFrame([{'ID':x.candidate_id,'RSI':x.rsi_oversold_threshold,'Bollinger':x.bollinger_lower_threshold,'ADX':x.adx_trend_strength_threshold,'Stochastic':x.stochastic_oversold_threshold,'Perioden':x.complete_period_count,'Target Hit %':round(x.target_hit_rate*100,1),'Objective':round(x.objective_score,1)} for x in rows]),width='stretch',hide_index=True)
 with standards:
  label=st.selectbox('Aktie Standardprofile',list(labels),key='standard_profile_symbol')
  if st.button('Standardprofile vergleichen'):r=ProfileValidationUseCase().analyze(labels[label]);st.dataframe(pd.DataFrame([{'Profil':x.profile_name,'Rollen-Fit':x.profile_role_status,'Perioden':x.period_count,'Target Hit %':round(x.target_hit_rate*100,1),'Coverage %':round(x.signal_coverage_rate*100,2)} for x in r.rows]),width='stretch',hide_index=True)
  if st.button('Standardprofile über Watchlist'):rows=CrossStockProfileValidationUseCase().analyze();st.dataframe(pd.DataFrame([{'Profil':x.profile_name,'Rollen-Fit':x.role_fit_status,'Perioden':x.total_complete_periods,'Target Hit %':round(x.weighted_target_hit_rate*100,1)} for x in rows]),width='stretch',hide_index=True)
