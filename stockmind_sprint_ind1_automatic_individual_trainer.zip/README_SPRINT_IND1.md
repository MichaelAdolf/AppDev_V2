# Sprint IND1: Automatic Individual Strategy Trainer

## Ziel
- Unabhängiger breiter Parameterraum, nicht um Conservative/Balanced/Aggressive zentriert.
- Automatisches Suchen, Ranking, Speichern, Validieren und Vorschlagen eines robusten Individual-Profils.
- Standardprofile dienen nur als Benchmark.
- Kein Kandidat wird ohne Bestätigung aktiviert.

## Suchraum
- RSI Oversold: 15 bis 45
- Bollinger Position: 0,05 bis 0,50
- ADX: 10 bis 40
- Stochastic Oversold: 5 bis 45

Der vollständige Raum enthält über 6.000 Kombinationen. Pro Lauf wird eine deterministische, gleichmäßig über den Raum verteilte Stichprobe von standardmäßig 180 Kombinationen bewertet. Die besten 8 werden vollständig validiert.

## Ranking
- 45 % Target-Hit-Rate
- 20 % Stichprobengröße
- 15 % Coverage
- 10 % Drawdown
- 10 % Geschwindigkeit bis +8 %

## Bedienung
Strategien → Entry & Individual → Individual automatisch trainieren.

## Tests
```powershell
python -m unittest tests.test_individual_parameter_space tests.test_individual_strategy_training tests.test_fitted_profile_validation
```

## Grenzen
- IND1 erzeugt BUY/HOLD für Individual, aber noch keinen vollständigen Opportunity Score, Confidence oder eigene Historical-Evidence-Pipeline.
- Diese Gleichstellung als viertes vollständiges StockMind-Profil folgt in IND2.
