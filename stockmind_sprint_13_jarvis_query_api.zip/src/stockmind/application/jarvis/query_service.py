from stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case import BuyPeriodDashboardUseCase
from stockmind.application.dashboard.use_cases.daily_intelligence_dashboard_use_case import DailyIntelligenceDashboardUseCase
from stockmind.application.dashboard.use_cases.fundamental_dashboard_use_case import FundamentalDashboardUseCase
from stockmind.application.dashboard.use_cases.profile_comparison_dashboard_use_case import ProfileComparisonDashboardUseCase
from stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case import StockDetailDashboardUseCase
from stockmind.application.dashboard.use_cases.watchlist_dashboard_use_case import WatchlistDashboardUseCase
from stockmind.application.jarvis.models.jarvis_query_result import JarvisQueryResult
from stockmind.infrastructure.history.indicator_chart_data_repository import IndicatorChartDataRepository
from stockmind.infrastructure.refresh.refresh_state_repository import RefreshStateRepository


class JarvisQueryService:
    def watchlist(self, profile_name: str = "balanced"):
        r=WatchlistDashboardUseCase().load(profile_name)
        ordered=sorted(r.stocks,key=lambda x:x.opportunity_score,reverse=True)
        top=ordered[:3]
        speech=f"Du beobachtest aktuell {r.stock_count} Aktien."
        if top:
            names=", ".join(f"{x.symbol} mit Score {x.opportunity_score:.0f}" for x in top)
            speech+=f" Die höchsten Opportunity Scores im Profil {profile_name} haben {names}."
        return JarvisQueryResult("watchlist",speech,{"profile_name":profile_name,"stock_count":r.stock_count,"buy_count":r.buy_count,"hold_count":r.hold_count,"sell_count":r.sell_count,"stocks":[self._watchlist_stock(x) for x in ordered]})

    def top_opportunities(self, profile_name="balanced", limit=3):
        r=DailyIntelligenceDashboardUseCase().load(profile_name)
        candidates=sorted(r.items,key=lambda x:(x.relevance_priority,x.current_score),reverse=True)[:limit]
        if not candidates:
            speech="Aktuell liegen keine auswertbaren Opportunities vor."
        else:
            speech="Die aktuell relevantesten StockMind-Kandidaten sind " + "; ".join(
                f"{x.symbol}: {x.current_signal}, Score {x.current_score:.0f}, historische Trefferquote {x.target_hit_rate:.0%} aus {x.complete_period_count} vollständigen Perioden" for x in candidates
            ) + "."
        return JarvisQueryResult("top_opportunities",speech,{"profile_name":profile_name,"items":[self._daily_item(x) for x in candidates]})

    def daily_changes(self, profile_name="balanced"):
        r=DailyIntelligenceDashboardUseCase().load(profile_name)
        changed=[x for x in r.items if x.new_buy_period or x.signal_changed or (x.score_change is not None and abs(x.score_change)>=5)]
        if changed:
            bits=[]
            for x in changed[:5]:
                if x.new_buy_period: bits.append(f"{x.symbol} hat eine neue BUY-Periode")
                elif x.signal_changed: bits.append(f"{x.symbol} wechselte von {x.previous_signal} auf {x.current_signal}")
                else: bits.append(f"{x.symbol} veränderte den Opportunity Score um {x.score_change:+.1f} Punkte")
            speech="Seit dem vorherigen verfügbaren Handelstag: " + ". ".join(bits) + "."
        else:
            speech="Seit dem vorherigen verfügbaren Handelstag gibt es keine wesentlichen StockMind-Veränderungen."
        return JarvisQueryResult("daily_changes",speech,{"profile_name":profile_name,"latest_trading_date":r.latest_trading_date,"previous_trading_date":r.previous_trading_date,"items":[self._daily_item(x) for x in changed]})

    def morning_briefing(self, profile_name="balanced", limit=3):
        r=DailyIntelligenceDashboardUseCase().load(profile_name)
        relevant=[x for x in r.items if x.relevance_priority>0][:limit]
        changes=[x for x in r.items if x.new_buy_period or x.signal_changed or (x.score_change is not None and abs(x.score_change)>=5)]
        if changes:
            change_text=[]
            for x in changes[:3]:
                if x.new_buy_period: change_text.append(f"Bei {x.symbol} ist eine neue BUY-Periode entstanden")
                elif x.signal_changed: change_text.append(f"{x.symbol} wechselte von {x.previous_signal} auf {x.current_signal}")
                else: change_text.append(f"{x.symbol} änderte den Score um {x.score_change:+.1f} Punkte")
            speech="StockMind Tagesübersicht. " + ". ".join(change_text) + "."
        else:
            speech="StockMind Tagesübersicht. Es gibt keine wesentlichen Veränderungen zum vorherigen Handelstag."
        if relevant:
            speech += " Aktuell besonders relevant: " + "; ".join(f"{x.symbol} mit Score {x.current_score:.0f}, Signal {x.current_signal}" for x in relevant) + "."
        return JarvisQueryResult("morning_briefing",speech,{"profile_name":profile_name,"latest_trading_date":r.latest_trading_date,"previous_trading_date":r.previous_trading_date,"changes":[self._daily_item(x) for x in changes],"top_items":[self._daily_item(x) for x in relevant],"summary":{"stock_count":r.stock_count,"relevant_count":r.relevant_count,"new_buy_period_count":r.new_buy_period_count,"signal_change_count":r.signal_change_count,"consensus_count":r.consensus_count}})

    def stock_analysis(self,symbol,profile_name="balanced"):
        r=StockDetailDashboardUseCase().load(profile_name,symbol.upper())
        period=(f"Eine aktive BUY-Periode läuft seit {r.active_buy_period.start_date} und enthält {r.active_buy_period.buy_signal_count} BUY-Signaltage." if r.active_buy_period else "Aktuell besteht keine aktive BUY-Periode.")
        speech=(f"{r.company_name}, {r.symbol}, wird im Profil {profile_name} aktuell mit Signal {r.signal} bewertet. Opportunity Score {r.score:.0f}, Confidence {r.confidence:.0%}, Risiko {r.risk_level}. {period} Historisch erreichten {r.period_target_hit_rate:.0%} von {r.complete_buy_period_count} vollständigen BUY-Perioden das Ziel von plus 8 Prozent innerhalb von 60 Kalendertagen. {r.profile_consensus}")
        return JarvisQueryResult("stock_analysis",speech,self._stock_data(r))

    def buy_period(self,symbol,profile_name="balanced"):
        r=BuyPeriodDashboardUseCase().load(symbol.upper(),profile_name,"5y",3);s=r.statistics
        if r.active_period:
            speech=f"Ja. Für {symbol.upper()} läuft im Profil {profile_name} eine BUY-Periode seit {r.active_period.start_date}. Sie dauert {r.active_period.calendar_duration_days} Kalendertage und liegt im {r.active_period_phase.lower()}."
        else:speech=f"Für {symbol.upper()} besteht im Profil {profile_name} aktuell keine aktive BUY-Periode."
        return JarvisQueryResult("buy_period",speech,{"symbol":symbol.upper(),"profile_name":profile_name,"active_period":self._period(r.active_period),"active_period_phase":r.active_period_phase,"statistics":self._period_stats(s)})

    def historical_quality(self,symbol,profile_name="balanced"):
        r=BuyPeriodDashboardUseCase().load(symbol.upper(),profile_name,"5y",3);s=r.statistics
        speech=(f"{symbol.upper()} erreicht im Profil {profile_name} historisch eine Trefferquote von {s.target_hit_rate:.0%} aus {s.complete_period_count} vollständigen BUY-Perioden. Median bis zum Ziel sind {s.median_days_to_target:.0f} Tage. Der durchschnittliche maximale Drawdown erfolgreicher Perioden beträgt {s.successful_average_max_drawdown_pct:.1f} Prozent.")
        return JarvisQueryResult("historical_quality",speech,{"symbol":symbol.upper(),"profile_name":profile_name,"statistics":self._period_stats(s)})

    def profiles(self,symbol):
        r=ProfileComparisonDashboardUseCase().load(symbol.upper(),"5y",3)
        buy=[x.profile_name for x in r.entries if x.signal=="BUY" or x.current_buy_signal is True]
        speech=(f"Für {symbol.upper()} bestätigen {len(set(buy))} von 3 Profilen aktuell BUY. " + ("Bestätigend sind " + ", ".join(buy) + "." if buy else "Kein Profil bestätigt aktuell BUY."))
        return JarvisQueryResult("profile_comparison",speech,{"symbol":r.symbol,"analysis_period":r.analysis_period,"buy_profiles":buy,"entries":[self._profile(x) for x in r.entries]})

    def explain(self,symbol,profile_name="balanced"):
        r=StockDetailDashboardUseCase().load(profile_name,symbol.upper())
        components=", ".join(f"{k} {v:+.1f}" for k,v in r.score_components.items())
        speech=f"Für {r.symbol} basiert die Einschätzung auf {len(r.strengths)} erfüllten und {len(r.weaknesses)} nicht erfüllten Kriterien. Die Score-Komponenten sind {components}. Historische Trefferquote {r.period_target_hit_rate:.0%}, Confidence {r.confidence:.0%}, Risiko {r.risk_level}."
        return JarvisQueryResult("explain",speech,{"symbol":r.symbol,"profile_name":profile_name,"summary":r.summary,"fulfilled_criteria":r.strengths,"unfulfilled_criteria":r.weaknesses,"score_components":r.score_components,"target_hit_rate":r.period_target_hit_rate,"complete_period_count":r.complete_buy_period_count,"confidence":r.confidence,"risk_level":r.risk_level})

    def indicator(self,symbol,indicator):
        points=IndicatorChartDataRepository().load_by_symbol(symbol.upper())
        if not points: raise ValueError(f"Keine Indikatordaten für {symbol.upper()} gefunden.")
        p=points[-1];key=indicator.lower();mapping={"rsi":("RSI 14",p.rsi_14),"macd":("MACD",p.macd),"adx":("ADX",p.adx),"stochastic":("Stochastic %K",p.stoch_k),"stoch":("Stochastic %K",p.stoch_k)}
        if key not in mapping: raise ValueError("Unterstützte Indikatoren: rsi, macd, adx, stochastic.")
        label,value=mapping[key];speech=f"Der aktuelle {label} für {symbol.upper()} beträgt {value:.2f}." if value is not None else f"Für {symbol.upper()} liegt aktuell kein {label}-Wert vor."
        return JarvisQueryResult("indicator",speech,{"symbol":symbol.upper(),"trading_date":p.trading_date,"indicator":key,"value":value})

    def fundamentals(self,symbol):
        f=FundamentalDashboardUseCase().load(symbol.upper())
        if f is None: raise ValueError(f"Keine Fundamentaldaten für {symbol.upper()} gefunden.")
        upside=f" Analysten-Upside {f.target_upside_pct:.1f} Prozent." if f.target_upside_pct is not None else ""
        speech=f"{f.company_name or f.symbol} hat einen Fundamental Score von {f.fundamental_score:.0f} und die Bewertung {f.valuation}.{upside}"
        return JarvisQueryResult("fundamentals",speech,{"symbol":f.symbol,"company_name":f.company_name,"fundamental_score":f.fundamental_score,"valuation":f.valuation,"recommendation_key":f.recommendation_key,"current_price":f.current_price,"target_mean_price":f.target_mean_price,"target_upside_pct":f.target_upside_pct})

    def _watchlist_stock(self,x):return {"symbol":x.symbol,"company_name":x.company_name,"opportunity_score":x.opportunity_score,"confidence":x.confidence,"historical_success_rate":x.historical_success_rate,"risk_level":x.risk_level,"signal":x.signal}
    def _daily_item(self,x):return {"symbol":x.symbol,"company_name":x.company_name,"profile_name":x.profile_name,"score":x.current_score,"previous_score":x.previous_score,"score_change":x.score_change,"confidence":x.current_confidence,"confidence_change":x.confidence_change,"signal":x.current_signal,"previous_signal":x.previous_signal,"signal_changed":x.signal_changed,"risk":x.current_risk,"previous_risk":x.previous_risk,"active_period_start":x.active_period_start,"active_period_duration_days":x.active_period_duration_days,"new_buy_period":x.new_buy_period,"target_hit_rate":x.target_hit_rate,"complete_period_count":x.complete_period_count,"sample_quality":x.sample_quality,"profile_buy_count":x.profile_buy_count,"profile_consensus":x.profile_consensus,"relevance_status":x.relevance_status}
    def _period(self,p):return None if p is None else {"start_date":p.start_date,"end_date":p.end_date,"duration_days":p.calendar_duration_days,"buy_signal_count":p.buy_signal_count,"entry_price":p.entry_price,"outcome":p.outcome,"is_complete":p.is_complete}
    def _period_stats(self,s):return {"complete_period_count":s.complete_period_count,"incomplete_period_count":s.incomplete_period_count,"target_hit_rate":s.target_hit_rate,"below_target_rate":s.below_target_rate,"flat_rate":s.flat_rate,"negative_rate":s.negative_rate,"sample_quality":s.sample_quality,"average_days_to_target":s.average_days_to_target,"median_days_to_target":s.median_days_to_target,"successful_average_max_drawdown_pct":s.successful_average_max_drawdown_pct,"failed_average_max_drawdown_pct":s.failed_average_max_drawdown_pct}
    def _profile(self,x):return {"profile_name":x.profile_name,"score":x.score,"confidence":x.confidence,"signal":x.signal,"risk_level":x.risk_level,"current_buy_signal":x.current_buy_signal,"active_period_start":x.active_period_start,"active_period_duration_days":x.active_period_duration_days,"complete_period_count":x.complete_period_count,"target_hit_rate":x.target_hit_rate,"below_target_rate":x.below_target_rate,"flat_rate":x.flat_rate,"negative_rate":x.negative_rate}
    def _stock_data(self,r):return {"symbol":r.symbol,"company_name":r.company_name,"profile_name":r.profile_name,"signal":r.signal,"opportunity_score":r.score,"confidence":r.confidence,"risk_level":r.risk_level,"target_hit_rate":r.period_target_hit_rate,"complete_period_count":r.complete_buy_period_count,"sample_quality":r.period_statistics.sample_quality,"profile_consensus":r.profile_consensus,"profile_buy_count":r.profile_buy_count,"active_buy_period":self._period(r.active_buy_period),"score_components":r.score_components,"previous_score":r.previous_score,"score_change":r.score_change,"previous_signal":r.previous_signal,"confidence_change":r.confidence_change}
