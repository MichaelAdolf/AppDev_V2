from dataclasses import dataclass


@dataclass(frozen=True)
class JarvisQueryResult:
    intent: str
    speech: str
    data: dict
