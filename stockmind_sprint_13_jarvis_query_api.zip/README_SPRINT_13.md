# StockMind Sprint 13: Jarvis Query API

## Response Contract

Alle neuen Jarvis Queries liefern:

```json
{"intent":"...","speech":"...","data":{}}
```

`speech` ist eine kompakte, direkt TTS-fähige Antwort. `data` enthält strukturierte
Daten für Flutter, Node-RED oder Follow-up-Logik. StockMind bleibt Quelle der
fachlichen Interpretation; Node-RED muss keine Scoring- oder BUY-Logik duplizieren.

## Capabilities

- `/jarvis/watchlist-summary`
- `/jarvis/top-opportunities`
- `/jarvis/daily-changes`
- `/jarvis/morning-briefing`
- `/jarvis/stock-analysis/{symbol}`
- `/jarvis/buy-period/{symbol}`
- `/jarvis/historical-quality/{symbol}`
- `/jarvis/profile-comparison/{symbol}`
- `/jarvis/explain/{symbol}`
- `/jarvis/indicator/{symbol}?indicator=rsi|macd|adx|stochastic`
- `/jarvis/fundamentals/{symbol}`

## Morning Briefing

Das Morning Briefing priorisiert Veränderungen gegenüber dem vorherigen verfügbaren
Replay-Handelstag, besonders neue BUY-Perioden, Signalwechsel und deutliche
Score-Veränderungen. Danach nennt es maximal `limit` relevante Kandidaten.
Unveränderte Aktien werden nicht vollständig vorgelesen.

Die Wecker-/Home-Assistant-Auslösung ist bewusst noch nicht Bestandteil dieses
Sprints. Node-RED kann im nächsten Sprint `/jarvis/morning-briefing` beim Wecker-Event
aufrufen und den `speech`-Text an die vorhandene TTS-Pipeline übergeben.

## Tests

```powershell
python -m unittest tests.test_jarvis_query_service
```

## API

```powershell
uvicorn api.stockmind_api:app --reload
```

Danach die Jarvis-Endpunkte in Swagger testen. Für Stock-Abfragen empfiehlt sich
zunächst `profile_name=balanced`; Profile bleiben explizit überschreibbar.
