import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.jarvis.query_service import JarvisQueryService

class JarvisQueryServiceTest(unittest.TestCase):
    @patch("stockmind.application.jarvis.query_service.DailyIntelligenceDashboardUseCase")
    def test_morning_briefing_prioritizes_change(self,t):
        item=SimpleNamespace(symbol="NVDA",company_name="Nvidia",profile_name="balanced",current_score=82.0,previous_score=75.0,score_change=7.0,current_confidence=.8,confidence_change=.1,current_signal="BUY",previous_signal="HOLD",signal_changed=True,current_risk="MEDIUM",previous_risk="MEDIUM",active_period_start="2026-09-25",active_period_duration_days=1,new_buy_period=True,target_hit_rate=.84,complete_period_count=38,sample_quality="MEDIUM",profile_buy_count=2,profile_consensus="2/3 BUY",relevance_status="Neue BUY-Periode",relevance_priority=100)
        t.return_value.load.return_value=SimpleNamespace(profile_name="balanced",latest_trading_date="2026-09-25",previous_trading_date="2026-09-24",stock_count=1,relevant_count=1,new_buy_period_count=1,signal_change_count=1,consensus_count=0,score_gainer_count=1,items=[item])
        result=JarvisQueryService().morning_briefing("balanced",3)
        self.assertEqual(result.intent,"morning_briefing")
        self.assertIn("neue BUY-Periode",result.speech)
        self.assertEqual(result.data["changes"][0]["symbol"],"NVDA")

    @patch("stockmind.application.jarvis.query_service.IndicatorChartDataRepository")
    def test_indicator_returns_only_requested_value(self,t):
        t.return_value.load_by_symbol.return_value=[SimpleNamespace(trading_date="2026-09-25",rsi_14=34.2,macd=.5,adx=22.0,stoch_k=18.0)]
        result=JarvisQueryService().indicator("NVDA","rsi")
        self.assertEqual(result.data["indicator"],"rsi")
        self.assertEqual(result.data["value"],34.2)

if __name__=="__main__":unittest.main()
