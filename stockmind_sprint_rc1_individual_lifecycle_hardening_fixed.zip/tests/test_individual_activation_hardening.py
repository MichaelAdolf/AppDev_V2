import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.strategy.individual_profile_activation_orchestrator import IndividualProfileActivationOrchestrator
class IndividualActivationHardeningTest(unittest.TestCase):
 @patch('stockmind.application.strategy.individual_profile_activation_orchestrator.RunIndividualAnalysisUseCase')
 @patch('stockmind.application.strategy.individual_profile_activation_orchestrator.IndividualHistoryBackfillUseCase')
 @patch('stockmind.application.strategy.individual_profile_activation_orchestrator.IndividualHistoryResetUseCase')
 @patch('stockmind.application.strategy.individual_profile_activation_orchestrator.FittedProfileRepository')
 def test_activation_resets_backfills_and_analyzes_immediately(self,repo,reset,backfill,analysis):
  candidate=SimpleNamespace(id='new',symbol='NVDA',status='VALIDATED',version=2);repo.return_value.load.side_effect=[candidate,SimpleNamespace(id='new',status='ACTIVE')];repo.return_value.load_active.return_value=SimpleNamespace(id='old');result=IndividualProfileActivationOrchestrator().execute('new');repo.return_value.activate.assert_called_once_with('new','NVDA');reset.return_value.execute.assert_called_once_with('NVDA');backfill.return_value.execute.assert_called_once_with('NVDA');analysis.return_value.execute.assert_called_once_with('NVDA');self.assertEqual(result.profile.status,'ACTIVE')
if __name__=='__main__':unittest.main()
