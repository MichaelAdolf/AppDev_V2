from stockmind.application.dashboard.models.profile_comparison_result import ProfileComparisonEntry,ProfileComparisonResult
from stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case import BuyPeriodDashboardUseCase
from stockmind.infrastructure.history.daily_buy_signal_repository import DailyBuySignalRepository
from stockmind.infrastructure.history.latest_analysis_repository import LatestAnalysisRepository
from stockmind.infrastructure.strategy.fitted_profile_repository import FittedProfileRepository
class ProfileComparisonDashboardUseCase:
 PROFILES=['conservative','balanced','aggressive']
 def load(self,symbol,analysis_period='5y',max_gap_days=3):
  symbol=symbol.upper();profiles=list(self.PROFILES)
  if FittedProfileRepository().load_active(symbol):profiles.append('individual')
  entries=[];analysis_repo=LatestAnalysisRepository();signal_repo=DailyBuySignalRepository();period_uc=BuyPeriodDashboardUseCase()
  for name in profiles:
   stock=next((x for x in analysis_repo.load_all(name) if x.symbol.upper()==symbol),None)
   if stock is None:continue
   latest_signal=signal_repo.load_latest(symbol,name,analysis_period);period=period_uc.load(symbol,name,analysis_period,max_gap_days);active=period.active_period;stats=period.statistics
   entries.append(ProfileComparisonEntry(name,stock.opportunity_score,stock.confidence,stock.signal,stock.risk_level,latest_signal.is_buy if latest_signal else None,active.start_date if active else None,active.calendar_duration_days if active else None,period.period_count,stats.complete_period_count,stats.incomplete_period_count,stats.target_hit_rate,stats.below_target_rate,stats.flat_rate,stats.negative_rate))
  return ProfileComparisonResult(symbol,analysis_period,entries)
