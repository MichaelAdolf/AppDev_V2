from dataclasses import dataclass
from stockmind.application.strategy.individual_history_backfill_use_case import IndividualHistoryBackfillUseCase
from stockmind.application.strategy.individual_history_reset_use_case import IndividualHistoryResetUseCase
from stockmind.application.strategy.run_individual_analysis_use_case import RunIndividualAnalysisUseCase
from stockmind.infrastructure.strategy.fitted_profile_repository import FittedProfileRepository

@dataclass(frozen=True)
class IndividualActivationResult:
    profile:object;backfill:object;analysis:object

class IndividualProfileActivationOrchestrator:
    def __init__(self,database_path=None):self._database_path=database_path;self._repo=FittedProfileRepository(database_path)
    def execute(self,profile_id):
        candidate=self._repo.load(profile_id)
        if candidate is None:raise ValueError('Fitted Profile wurde nicht gefunden.')
        if candidate.status!='VALIDATED':raise ValueError('Nur ein VALIDATED Fitted Profile darf aktiviert werden.')
        previous=self._repo.load_active(candidate.symbol)
        self._repo.activate(profile_id,candidate.symbol)
        try:
            IndividualHistoryResetUseCase(self._database_path).execute(candidate.symbol)
            backfill=IndividualHistoryBackfillUseCase().execute(candidate.symbol)
            analysis=RunIndividualAnalysisUseCase(self._database_path).execute(candidate.symbol)
            return IndividualActivationResult(self._repo.load(profile_id),backfill,analysis)
        except Exception:
            # Restore a coherent active-version state. Derived Individual data remain cleared
            # or partially replaced and will be rebuilt by the next explicit activation.
            self._repo.restore_active(candidate.symbol,previous.id if previous else None)
            raise
