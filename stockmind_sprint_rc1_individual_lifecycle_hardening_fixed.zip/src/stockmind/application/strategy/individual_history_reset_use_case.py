import sqlite3
from stockmind.shared.config.settings import Settings

class IndividualHistoryResetUseCase:
    """Remove only derived productive Individual data for one symbol.

    Fitted profile versions and validation records are deliberately retained.
    """
    TABLES = (
        ("daily_buy_signals", "symbol = ? AND profile_name = ? AND analysis_period = ?"),
        ("historical_setups", "symbol = ? AND profile_name = ? AND analysis_period = ?"),
        ("buy_periods", "symbol = ? AND profile_name = ? AND analysis_period = ?"),
        ("historical_opportunities", "symbol = ? AND profile_name = ?"),
        ("latest_analysis", "symbol = ? AND profile_name = ?"),
        ("analysis_history", "symbol = ? AND profile_name = ?"),
        ("analysis_detail", "symbol = ? AND profile_name = ?"),
        ("individual_analysis_metadata", "symbol = ?"),
    )
    def __init__(self,database_path=None):
        self._database_path=database_path or Settings.load().database_path
    def execute(self,symbol,profile_name='individual',analysis_period='5y'):
        symbol=symbol.upper().strip();connection=sqlite3.connect(self._database_path)
        try:
            connection.execute('BEGIN')
            existing={row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            for table,where in self.TABLES:
                if table not in existing:continue
                params=(symbol,) if table=='individual_analysis_metadata' else ((symbol,profile_name) if table in ('historical_opportunities','latest_analysis','analysis_history','analysis_detail') else (symbol,profile_name,analysis_period))
                connection.execute(f'DELETE FROM {table} WHERE {where}',params)
            connection.commit()
        except Exception:
            connection.rollback();raise
        finally:connection.close()
