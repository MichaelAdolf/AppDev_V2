from stockmind.application.strategy.individual_profile_activation_orchestrator import IndividualProfileActivationOrchestrator
from stockmind.infrastructure.strategy.fitted_profile_repository import FittedProfileRepository
class ActivateFittedProfileUseCase:
 def __init__(self,database_path=None):self._database_path=database_path
 def execute(self,profile_id):return IndividualProfileActivationOrchestrator(self._database_path).execute(profile_id).profile
class DeactivateFittedProfileUseCase:
 def __init__(self,database_path=None):self._repo=FittedProfileRepository(database_path)
 def execute(self,symbol):self._repo.deactivate_symbol(symbol)
