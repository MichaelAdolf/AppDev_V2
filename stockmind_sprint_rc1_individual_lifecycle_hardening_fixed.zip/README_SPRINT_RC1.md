# RC1 Individual Lifecycle Hardening

## Umgesetzt
- sofortige Sichtbarkeit nach Aktivierung
- versionsreiner Wechsel durch Reset der abgeleiteten Individual-Daten
- historischer 5y Full Backfill für Daily Signals, Setups, BUY-Perioden und Opportunities
- Profilvergleich nutzt das persistierte Daily BUY Signal
- Konsensanzeige arbeitet dynamisch mit drei oder vier Profilen

## Aktivierungsablauf
VALIDATED aktivieren → alte aktive Version auf VALIDATED → Individual-Derivate zurücksetzen → 5y Backfill → aktuelle Analyse → Dashboard sofort aktuell.

Validation, Profilversionen und Trainingsergebnisse werden nicht gelöscht.

## Integration
1. ZIP entpacken.
2. Konsens-Patch ausführen:
```powershell
python scripts/apply_rc1_consensus_patch.py
```
3. Tests:
```powershell
python -m unittest tests.test_individual_activation_hardening tests.test_fitted_profile_activation tests.test_individual_daily_refresh_policy
```

## Laufzeit
Der Full Backfill berechnet etwa fünf Jahre täglicher Zustände und Historical Opportunities. Je Aktie kann die Aktivierung daher deutlich länger dauern als bisher. Dies passiert nur bei Aktivierung bzw. Versionswechsel, nicht beim normalen Daily Refresh.

## Fehlerverhalten
Scheitert Reset, Backfill oder aktuelle Analyse, wird der zuvor aktive Profilstatus wiederhergestellt. Abgeleitete Individual-Daten können zu diesem Zeitpunkt bereits zurückgesetzt sein. In diesem Fall Aktivierung nach Behebung des Fehlers erneut ausführen; der Backfill ist reproduzierbar und ersetzt die Daten vollständig.
