from pathlib import Path

p = Path("src/stockmind/application/dashboard/use_cases/stock_detail_dashboard_use_case.py")
text = p.read_text(encoding="utf-8")

old = '''        consensus=("Profil-Konsens: alle drei Profile bestätigen BUY." if len(set(buys))==3 else
                   f"Profil-Divergenz: {', '.join(buys)} bestätigen BUY." if buys else "Kein Profil bestätigt aktuell BUY.")'''
new = '''        available_profiles={entry.profile_name for entry in comparison.entries}
        buy_profiles=set(buys)
        consensus=(
            f"Profil-Konsens: alle {len(available_profiles)} verfügbaren Profile bestätigen BUY."
            if available_profiles and buy_profiles == available_profiles
            else f"Profil-Divergenz: {', '.join(sorted(buy_profiles))} bestätigen BUY."
            if buy_profiles
            else "Kein Profil bestätigt aktuell BUY."
        )'''

if new not in text:
    if old not in text:
        raise SystemExit("Consensus block not found.")
    text = text.replace(old, new, 1)

p.write_text(text, encoding="utf-8")
print(f"Patched {p}")
