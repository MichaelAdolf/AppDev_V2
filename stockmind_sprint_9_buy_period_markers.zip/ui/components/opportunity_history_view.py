import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from components.buy_period_marker_utils import add_period_marker_traces
from stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case import (
    BuyPeriodDashboardUseCase,
)
from stockmind.infrastructure.history.chart_data_repository import ChartDataRepository


def render(history, profile_name, symbol=None):
    if not history:
        st.warning("Kein historischer Opportunity-Replay vorhanden.")
        return

    df = pd.DataFrame([
        {
            "Datum": item.trading_date,
            "Opportunity Score": item.opportunity_score,
            "Confidence %": item.confidence * 100,
            "Signal": item.signal,
            "Risiko": item.risk_level,
        }
        for item in history
    ])
    points = ChartDataRepository().load_by_symbol(symbol) if symbol else []
    periods = (
        BuyPeriodDashboardUseCase().load(
            symbol=symbol,
            profile_name=profile_name,
            analysis_period="5y",
            max_gap_days=3,
        ).periods
        if symbol else []
    )

    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.06,
        row_heights=[0.55, 0.45],
    )
    fig.add_trace(
        go.Scatter(
            x=[point.trading_date for point in points],
            y=[point.close_price for point in points],
            name="Kurs",
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=df["Datum"],
            y=df["Opportunity Score"],
            name="Opportunity Score",
            line=dict(color="#1f77b4", width=2),
        ),
        row=2,
        col=1,
    )

    score_by_date = dict(zip(df["Datum"], df["Opportunity Score"]))
    add_period_marker_traces(
        fig=fig,
        periods=periods,
        value_by_date=score_by_date,
        row=2,
        col=1,
    )

    fig.update_layout(
        title=f"Kurs und Opportunity Score ({profile_name})",
        hovermode="x unified",
    )
    fig.update_yaxes(title_text="Kurs", row=1, col=1)
    fig.update_yaxes(title_text="Score", range=[0, 100], row=2, col=1)
    st.plotly_chart(fig, width="stretch")
