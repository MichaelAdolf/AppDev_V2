from collections import defaultdict

import plotly.graph_objects as go


STATUS_STYLE = {
    "success": {
        "name": "Ziel erreicht",
        "color": "#00a046",
        "symbol": "circle",
    },
    "failed": {
        "name": "Ziel nicht erreicht",
        "color": "#d22d2d",
        "symbol": "circle",
    },
    "open": {
        "name": "Beobachtungszeitraum offen",
        "color": "#7a7a7a",
        "symbol": "circle-open",
    },
}


def period_status(period) -> str:
    if not period.is_complete or period.outcome == "INCOMPLETE_WINDOW":
        return "open"
    if period.outcome == "TARGET_HIT":
        return "success"
    return "failed"


def format_optional(value, suffix: str = "") -> str:
    if value is None:
        return "-"
    if isinstance(value, float):
        return f"{value:.2f}{suffix}"
    return f"{value}{suffix}"


def grouped_period_markers(periods, value_by_date: dict[str, float]):
    """Return one marker per period when an exact start-date value exists."""
    grouped = defaultdict(list)
    for period in periods:
        y_value = value_by_date.get(period.start_date)
        if y_value is None:
            continue
        status = period_status(period)
        grouped[status].append({
            "x": period.start_date,
            "y": y_value,
            "custom": [
                period.start_date,
                period.end_date,
                "Ziel erreicht" if status == "success"
                else "Beobachtungszeitraum offen" if status == "open"
                else "Ziel nicht erreicht",
                period.buy_signal_count,
                period.calendar_duration_days,
                format_optional(period.entry_price),
                format_optional(period.days_to_target),
                format_optional(period.max_gain_pct, "%"),
                format_optional(period.max_drawdown_pct, "%"),
            ],
        })
    return grouped


def add_period_marker_traces(
    fig,
    periods,
    value_by_date: dict[str, float],
    row: int | None = None,
    col: int | None = None,
    legend_prefix: str = "BUY-Periode",
):
    grouped = grouped_period_markers(periods, value_by_date)
    for status in ("success", "failed", "open"):
        markers = grouped.get(status, [])
        if not markers:
            continue
        style = STATUS_STYLE[status]
        trace = go.Scatter(
            x=[item["x"] for item in markers],
            y=[item["y"] for item in markers],
            customdata=[item["custom"] for item in markers],
            mode="markers",
            name=f"{legend_prefix}: {style['name']}",
            marker=dict(
                color=style["color"],
                symbol=style["symbol"],
                size=10,
                line=dict(color="white", width=1),
            ),
            hovertemplate=(
                "Periodenstart: %{customdata[0]}<br>"
                "Periodenende: %{customdata[1]}<br>"
                "Ergebnis: %{customdata[2]}<br>"
                "BUY-Signaltage: %{customdata[3]}<br>"
                "Periodendauer: %{customdata[4]} Kalendertage<br>"
                "Einstiegskurs: %{customdata[5]}<br>"
                "Tage bis Ziel: %{customdata[6]}<br>"
                "Maximaler Kursgewinn: %{customdata[7]}<br>"
                "Maximaler Rückgang: %{customdata[8]}"
                "<extra></extra>"
            ),
        )
        if row is None or col is None:
            fig.add_trace(trace)
        else:
            fig.add_trace(trace, row=row, col=col)
