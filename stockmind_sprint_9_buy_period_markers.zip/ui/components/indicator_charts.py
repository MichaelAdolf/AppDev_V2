import plotly.graph_objects as go
import streamlit as st

from components.buy_period_marker_utils import add_period_marker_traces
from stockmind.infrastructure.history.indicator_chart_data_repository import (
    IndicatorChartDataRepository,
)


def _add_markers(fig, points, periods, value_getter):
    if not periods:
        return
    add_period_marker_traces(
        fig=fig,
        periods=periods,
        value_by_date={
            point.trading_date: value_getter(point)
            for point in points
            if value_getter(point) is not None
        },
    )


def render_rsi_chart(symbol: str, periods=None):
    points = IndicatorChartDataRepository().load_by_symbol(symbol)
    if not points:
        st.warning("Keine RSI-Daten vorhanden.")
        return
    dates = [point.trading_date for point in points]
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.rsi_14 for point in points],
        mode="lines",
        name="RSI 14",
    ))
    fig.add_hline(
        y=30,
        line_dash="dash",
        line_color="green",
        annotation_text="Oversold",
    )
    fig.add_hline(
        y=70,
        line_dash="dash",
        line_color="red",
        annotation_text="Overbought",
    )
    _add_markers(fig, points, periods, lambda point: point.rsi_14)
    fig.update_layout(
        title=f"{symbol} RSI",
        xaxis_title="Datum",
        yaxis_title="RSI",
        yaxis=dict(range=[0, 100]),
    )
    st.plotly_chart(fig, width="stretch")


def render_macd_chart(symbol: str, periods=None):
    points = IndicatorChartDataRepository().load_by_symbol(symbol)
    if not points:
        st.warning("Keine MACD-Daten vorhanden.")
        return
    dates = [point.trading_date for point in points]
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=dates,
        y=[point.macd_histogram for point in points],
        name="MACD Histogram",
    ))
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.macd for point in points],
        mode="lines",
        name="MACD",
    ))
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.macd_signal for point in points],
        mode="lines",
        name="Signal",
    ))
    _add_markers(fig, points, periods, lambda point: point.macd)
    fig.update_layout(
        title=f"{symbol} MACD",
        xaxis_title="Datum",
        yaxis_title="MACD",
    )
    st.plotly_chart(fig, width="stretch")


def render_adx_chart(symbol: str, periods=None):
    points = IndicatorChartDataRepository().load_by_symbol(symbol)
    if not points:
        st.warning("Keine ADX-Daten vorhanden.")
        return
    dates = [point.trading_date for point in points]
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.adx for point in points],
        name="ADX",
    ))
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.plus_di for point in points],
        name="+DI",
    ))
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.minus_di for point in points],
        name="-DI",
    ))
    _add_markers(fig, points, periods, lambda point: point.adx)
    fig.update_layout(
        title=f"{symbol} ADX",
        xaxis_title="Datum",
        yaxis_title="ADX",
    )
    st.plotly_chart(fig, width="stretch")


def render_stochastic_chart(symbol: str, periods=None):
    points = IndicatorChartDataRepository().load_by_symbol(symbol)
    if not points:
        st.warning("Keine Stochastics-Daten vorhanden.")
        return
    dates = [point.trading_date for point in points]
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.stoch_k for point in points],
        name="%K",
    ))
    fig.add_trace(go.Scatter(
        x=dates,
        y=[point.stoch_d for point in points],
        name="%D",
    ))
    _add_markers(fig, points, periods, lambda point: point.stoch_k)
    fig.update_layout(
        title=f"{symbol} Stochastics",
        xaxis_title="Datum",
        yaxis_title="Stochastics",
    )
    st.plotly_chart(fig, width="stretch")
