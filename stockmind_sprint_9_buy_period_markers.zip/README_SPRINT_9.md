# StockMind Sprint 9: BUY-Period Markers & Indicator Overlay

## Inhalt

- Opportunity-Verlauf zeigt genau einen Marker am Beginn jeder BUY-Periode.
- Historischer BUY-Perioden-Chart behält Periodenflächen und ergänzt Startmarker.
- Eintägige Perioden sind durch den Marker sichtbar.
- Tab `Indikatoren` erhält einen gemeinsamen Toggle für Periodenmarker.
- Bei aktiviertem Toggle erscheinen Marker auf Kurs/Bollinger, RSI, MACD, ADX
  und Stochastic.
- Grün = Ziel erreicht, Rot = Ziel nicht erreicht, Grau = noch offen.
- Marker werden nur bei einer exakten Übereinstimmung des Periodenstartdatums mit
  dem jeweiligen Chartdatum gesetzt. Es erfolgt keine stille Verschiebung auf einen
  benachbarten Handelstag.

## Neue Datei

```text
ui/components/buy_period_marker_utils.py
```

Die Datei zentralisiert Farbstatus, Hoverinformationen und Markerlogik, damit alle
Charts dieselbe Semantik verwenden.

## Tests

Da der Test eine UI-Hilfsdatei importiert, muss `ui` im Python-Pfad liegen. In
PowerShell vom Projektroot:

```powershell
$env:PYTHONPATH = "$PWD;$PWD\\ui"
python -m unittest tests.test_buy_period_marker_utils
```

Erwartung:

```text
Ran 3 tests
OK
```

## Dashboard-Test

```powershell
streamlit run ui/streamlit_app.py
```

Prüfen:

1. Tab `Historie & BUY-Perioden`: Opportunity-Chart hat grüne/rote/graue
   Periodenstartmarker auf der Score-Linie.
2. Historischer BUY-Perioden-Chart zeigt weiterhin Flächen und zusätzlich Punkte.
3. Eine eintägige Periode ist als Punkt erkennbar.
4. Tab `Indikatoren`: Toggle ist standardmäßig aus.
5. Toggle an: periodengleiche Marker erscheinen in allen fünf Charts.
6. Toggle aus: Indikatorcharts entsprechen wieder der cleanen Darstellung.

## Daten

Keine Migration und kein neuer Refresh sind erforderlich. Sprint 9 verwendet die
bereits vorhandenen BUY-Perioden, Opportunity-Replay-, Kurs- und Indikatordaten.
