import unittest
from types import SimpleNamespace

from components.buy_period_marker_utils import grouped_period_markers, period_status


class BuyPeriodMarkerUtilsTest(unittest.TestCase):
    def _period(self, start, end, outcome, complete=True):
        return SimpleNamespace(
            start_date=start,
            end_date=end,
            outcome=outcome,
            is_complete=complete,
            buy_signal_count=1,
            calendar_duration_days=1,
            entry_price=100.0,
            days_to_target=10 if outcome == "TARGET_HIT" else None,
            max_gain_pct=9.0,
            max_drawdown_pct=-3.0,
        )

    def test_single_day_period_creates_visible_marker(self):
        period = self._period(
            "2026-01-05",
            "2026-01-05",
            "TARGET_HIT",
        )
        grouped = grouped_period_markers(
            [period],
            {"2026-01-05": 72.0},
        )
        self.assertEqual(len(grouped["success"]), 1)
        self.assertEqual(grouped["success"][0]["x"], "2026-01-05")
        self.assertEqual(grouped["success"][0]["y"], 72.0)

    def test_failed_and_open_periods_use_separate_groups(self):
        failed = self._period(
            "2026-01-06",
            "2026-01-07",
            "NEGATIVE",
        )
        open_period = self._period(
            "2026-01-08",
            "2026-01-08",
            "INCOMPLETE_WINDOW",
            complete=False,
        )
        grouped = grouped_period_markers(
            [failed, open_period],
            {"2026-01-06": 55.0, "2026-01-08": 60.0},
        )
        self.assertEqual(len(grouped["failed"]), 1)
        self.assertEqual(len(grouped["open"]), 1)
        self.assertEqual(period_status(open_period), "open")

    def test_period_without_exact_start_value_is_not_shifted(self):
        period = self._period(
            "2026-01-05",
            "2026-01-05",
            "TARGET_HIT",
        )
        grouped = grouped_period_markers(
            [period],
            {"2026-01-06": 72.0},
        )
        self.assertEqual(dict(grouped), {})


if __name__ == "__main__":
    unittest.main()
