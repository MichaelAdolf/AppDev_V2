# Sprint E1.2 Cross-Stock Exit Validation

## Inhalt
- Validiert jede Exitstrategie über alle aktiven Watchlist-Aktien je Profil.
- Aggregiert STABLE, DEGRADED, FAILED und INSUFFICIENT_SAMPLE.
- Zeigt Ø/Median Validation Return, Positive Rate, Drawdown, Worst-Aktie, Degradation und Walk-Forward-Fold-Stabilität.
- Robustness Score ist eine transparente Rankinghilfe, keine Tradingentscheidung.
- ROBUST_CANDIDATE: mindestens 3 bewertbare Aktien, mindestens 60 % STABLE, positiver Ø Validation Return, Worst-Aktien-Return > -5 %.
- Keine Strategie wird automatisch aktiviert.

## Test
python -m unittest tests.test_cross_stock_exit_validation tests.test_exit_research_validation tests.test_exit_strategy_research

## Bedienung
Portfolio → Exit Strategy Research → Cross-Stock Validation. Profil wählen und Cross-Stock Validation starten.
