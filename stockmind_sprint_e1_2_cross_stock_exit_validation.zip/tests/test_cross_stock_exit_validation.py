import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.exit.cross_stock_exit_validation_use_case import CrossStockExitValidationUseCase
class CrossStockExitValidationTest(unittest.TestCase):
 @patch('stockmind.application.exit.cross_stock_exit_validation_use_case.ExitResearchValidationUseCase')
 @patch('stockmind.application.exit.cross_stock_exit_validation_use_case.WatchlistRepository')
 def test_aggregates_stable_strategy_across_multiple_stocks(self,watch_type,validator_type):
  watch_type.return_value.load_all.return_value=[SimpleNamespace(symbol=s,company_name=s,active=True) for s in ('AAA','BBB','CCC')]
  def validate(symbol,profile):
   rows=[SimpleNamespace(strategy_name='BASELINE_8PCT_60D',robustness_status='STABLE',train_sample_count=20,validation_sample_count=8,validation_average_return_pct=6.0,validation_positive_rate=.75,validation_average_drawdown_pct=-4.0,return_degradation_pct=-.5)]
   # Ensure all candidates exist; non-baseline are deliberately failed.
   from stockmind.domain.exit.exit_strategy import ExitStrategy
   rows += [SimpleNamespace(strategy_name=x.name,robustness_status='FAILED_VALIDATION',train_sample_count=20,validation_sample_count=8,validation_average_return_pct=-1.0,validation_positive_rate=.4,validation_average_drawdown_pct=-7.0,return_degradation_pct=-4.0) for x in ExitStrategy.research_candidates() if x.name!='BASELINE_8PCT_60D']
   return {'sufficient_sample':True,'rows':rows,'walk_forward':[]}
  validator_type.return_value.validate.side_effect=validate
  result=CrossStockExitValidationUseCase().analyze('balanced');top=next(x for x in result['summaries'] if x.strategy_name=='BASELINE_8PCT_60D')
  self.assertEqual(top.stable_stock_count,3);self.assertEqual(top.recommendation_status,'ROBUST_CANDIDATE');self.assertGreater(top.robustness_score,50)
if __name__=='__main__':unittest.main()
