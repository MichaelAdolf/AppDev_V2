import unittest
from stockmind.application.notifications.daily_mail_renderer import DailyMailRenderer
from stockmind.application.notifications.models.daily_mail_result import DailyMailResult,ProfileSignalMailItem,StockMailItem,PortfolioMailItem
class DailyMailV3Test(unittest.TestCase):
 def test_action_briefing_contains_entry_exit_watch_and_individual(self):
  individual=ProfileSignalMailItem('individual','BUY',.76,37,'MEDIUM',81,.84,'MEDIUM');stock=StockMailItem('ALV.DE','Allianz',[individual],True,['individual'],'individual');exit_item=PortfolioMailItem('AAPL','Apple',100,0.086,34,26,True,'HOLD',65,-5,'CRITICAL',['TARGET_REACHED'],'EXIT_REVIEW','BASELINE_8PCT_60D',['TARGET_REACHED'],'ROBUST_CANDIDATE');watch_item=PortfolioMailItem('AMD','AMD',30,0.032,54,6,False,'HOLD',60,-2,'ATTENTION',['TIME_WINDOW_NEAR_END'],'WATCH','BASELINE_8PCT_60D',[],'ROBUST_CANDIDATE');r=DailyMailResult('2026-11-08','2026-11-07','subject',[stock],[],[stock],[exit_item,watch_item],12500,13150,650,1380)
  html=DailyMailRenderer().render(r);self.assertIn('Entry Opportunities',html);self.assertIn('Individual',html);self.assertIn('EXIT REVIEW',html);self.assertIn('WATCH',html);self.assertIn('Portfolio Summary',html)
if __name__=='__main__':unittest.main()
