# Daily Mail V3: Action Briefing

## Reihenfolge
1. 🟢 Entry Opportunities
2. 🔴 Exit Review
3. 🟡 Watch
4. 🔵 Portfolio Summary
5. 📈 Daily Changes
6. 📋 Watchlist

## Entry
Die Primärdarstellung nutzt bevorzugt ein BUY des Individual-Profils, danach Balanced, Conservative und Aggressive. Angezeigt werden Opportunity Score, Confidence, Historical Hit, Sample und Risk.

## Unverändert
SMTP, Versandlogik, Deduplizierung, force=true, Node-RED, Tradingregeln und Portfolio-/Exit-Berechnung bleiben unverändert.

## Tests
```powershell
python -m unittest tests.test_daily_mail_v3 tests.test_daily_mail_use_case tests.test_productive_exit_engine
```

## Preview
Nach Integration den vorhandenen Daily-Mail-Preview-Endpunkt verwenden und HTML visuell prüfen.
