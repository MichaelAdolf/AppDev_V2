# Sprint S2 Fitted Profile Foundation

- Conservative, Balanced und Aggressive bleiben unverändert.
- Pro Aktie werden begrenzte Fitted-Kandidaten um ein gewähltes Ausgangsprofil erzeugt.
- Bewertung nutzt historische Indikator- und OHLC-Daten, +8 % in 60 Tagen, Stichprobe, Coverage und Drawdown.
- Kandidaten können versioniert als CANDIDATE gespeichert werden.
- Keine automatische Aktivierung und keine Änderung produktiver Signale.

## Test
python -m unittest tests.test_fitted_profile_search tests.test_profile_validation

## Bedienung
Portfolio → Entry Strategy Research → Fitted Candidate Search.

## Nächster Sprint
S2.1 validiert gespeicherte Kandidaten chronologisch mit Train/Validation und Walk-Forward. Erst danach kann ein Kandidat manuell ACTIVE werden.
