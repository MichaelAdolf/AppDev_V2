import streamlit as st


def render():
    st.subheader("Begriffe & Methodik")
    terms = {
        "Opportunity Score": "Gesamtbewertung der aktuellen Gelegenheit aus Qualität, Confidence, historischer Evidenz und Risiko. Keine Renditewahrscheinlichkeit.",
        "Confidence": "Modellvertrauen aus Regelkonfidenz und historischer Evidenz, gewichtet nach Stichprobenqualität.",
        "BUY-Signaltag": "Handelstag, an dem die Bedingungen des ausgewählten Profils und die Mindestqualität erfüllt sind.",
        "BUY-Periode": "Zusammengefasste BUY-Signaltage mit maximal drei Kalendertagen Unterbrechung.",
        "Ziel erreicht": "Mindestens +8 % innerhalb 60 Kalendertagen; geprüft über das Tageshoch.",
        "Positiv unter Ziel": "Nach 60 Kalendertagen mehr als +1 %, aber das +8-%-Ziel wurde nicht erreicht.",
        "Seitwärts": "Rendite nach 60 Kalendertagen zwischen -1 % und +1 %.",
        "Negativ": "Rendite nach 60 Kalendertagen unter -1 %.",
        "Beobachtungszeitraum offen": "Seit Periodenbeginn sind noch keine vollständigen 60 Kalendertage vergangen.",
        "Maximaler Kursgewinn": "Höchster zwischenzeitlicher Gewinn gegenüber dem Einstiegskurs.",
        "Maximaler Drawdown": "Größter zwischenzeitlicher Kursrückgang gegenüber dem Einstiegskurs.",
        "Historisches Setup": "Einzelner historischer BUY-Signaltag; nicht identisch mit einer zusammengefassten BUY-Periode.",
        "Sample Quality": "Stichprobenqualität nach Anzahl vollständiger Fälle: HIGH ab 50, MEDIUM ab 20, LOW ab 1.",
        "Risk": "StockMind-Risikoklasse aus den aktuellen technischen Merkmalen.",
    }
    for term, explanation in terms.items():
        with st.expander(term):
            st.write(explanation)
