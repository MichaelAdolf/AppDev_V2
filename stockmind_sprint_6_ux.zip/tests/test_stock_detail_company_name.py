import unittest
from unittest.mock import patch
from types import SimpleNamespace
from stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case import StockDetailDashboardUseCase

class StockDetailCompanyNameTest(unittest.TestCase):
    @patch("stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case.BuyPeriodDashboardUseCase")
    @patch("stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case.HistoricalSetupDashboardUseCase")
    @patch("stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case.AnalysisHistoryRepository")
    @patch("stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case.AnalysisDetailRepository")
    @patch("stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case.WatchlistRepository")
    @patch("stockmind.application.dashboard.use_cases.stock_detail_dashboard_use_case.LatestAnalysisRepository")
    def test_company_name_from_watchlist(self, latest, watchlist, detail, history, setups, periods):
        latest.return_value.load_all.return_value=[SimpleNamespace(symbol="AAPL",opportunity_score=1,confidence=.5,historical_success_rate=.6,risk_level="LOW",signal="HOLD")]
        watchlist.return_value.load_all.return_value=[SimpleNamespace(symbol="AAPL",company_name="Apple Inc.")]
        detail.return_value.load.return_value=None; history.return_value.load_by_symbol.return_value=[]
        setups.return_value.load.return_value=SimpleNamespace(setups=[],setup_count=0,successful_count=0,failed_count=0,success_rate=0,average_days=0,average_gain=0,average_drawdown=0)
        stats=SimpleNamespace(complete_period_count=0,incomplete_period_count=0,target_hit_rate=0,below_target_rate=0,flat_rate=0,negative_rate=0)
        periods.return_value.load.return_value=SimpleNamespace(statistics=stats,active_period=None,period_count=0)
        result=StockDetailDashboardUseCase().load("balanced","AAPL")
        self.assertEqual(result.company_name,"Apple Inc.")

if __name__ == "__main__": unittest.main()
