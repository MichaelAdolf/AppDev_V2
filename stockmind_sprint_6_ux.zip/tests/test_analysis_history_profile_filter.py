import tempfile
import unittest
from pathlib import Path
from stockmind.domain.history.analysis_history_entry import AnalysisHistoryEntry
from stockmind.infrastructure.history.analysis_history_repository import AnalysisHistoryRepository

class AnalysisHistoryProfileFilterTest(unittest.TestCase):
    def test_filters_profile_and_keeps_latest_row_per_day(self):
        with tempfile.TemporaryDirectory() as d:
            repo=AnalysisHistoryRepository(str(Path(d)/"test.db"))
            for profile,score in [("balanced",10),("balanced",20),("aggressive",90)]:
                repo.save(AnalysisHistoryEntry("2026-01-01","AAPL",profile,score,0.5,0.6,"LOW","HOLD"))
            rows=repo.load_by_symbol("AAPL","balanced")
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0].opportunity_score,20)
            self.assertEqual(rows[0].profile_name,"balanced")

if __name__ == "__main__": unittest.main()
