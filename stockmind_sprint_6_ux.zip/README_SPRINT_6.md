# StockMind Sprint 6: Dashboard UX & Visual Analytics

## Änderungen

- Sidebar unverändert.
- Haupttabs direkt unter der StockMind-Überschrift.
- Aktienauswahl und Detailansicht danach.
- Watchlist-Reihenfolge: Kennzahlen, Tabelle, Alerts.
- Firmenname plus Symbol in der Detailüberschrift.
- KPI-Leiste mit BUY-Perioden-Trefferquote und Evidenzquelle.
- Einfacher Kurschart in der Übersicht.
- Profilreiner, täglich deduplizierter Opportunity-Verlauf.
- Historienchart mit Kurs und BUY-Perioden ohne überlagernde Annotationen.
- Indikatorchart nur mit Kurs und Bollinger-Bändern.
- Chartdaten-Refresh von 1y auf 5y.
- Verständlichere Begriffe in Profilvergleich und BUY-Perioden.
- Neuer Glossar-Tab.

## Wichtig

Vor dem Dashboard-Test müssen die Chartdaten neu geladen werden:

```powershell
python scripts/refresh_chart_data.py
```

## Tests

```powershell
python -m unittest tests.test_analysis_history_profile_filter
python -m unittest tests.test_stock_detail_company_name
```

Anschließend alle bestehenden Regressionstests aus Sprint 1 bis 5 ausführen.

## Dashboard

```powershell
streamlit run ui/streamlit_app.py
```

## Deployment

Nach erfolgreichem lokalen Test `src`, `scripts` und `ui` in den Add-on-Build-Kontext übernehmen und das Add-on neu bauen.
