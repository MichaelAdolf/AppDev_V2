from dataclasses import dataclass


@dataclass(frozen=True)
class AlertResult:
    title: str
    message: str
    severity: str
    symbol: str
    profile_name: str
    reason: str
