from stockmind.application.dashboard.models.alert_result import AlertResult
from stockmind.infrastructure.history.latest_analysis_repository import LatestAnalysisRepository


class AlertsDashboardUseCase:
    def load(self, profile_name: str) -> list[AlertResult]:
        results = LatestAnalysisRepository().load_all(profile_name)
        alerts = []
        for item in results:
            if item.opportunity_score >= 85:
                alerts.append(AlertResult(
                    title="Hot Opportunity",
                    message=f"{item.symbol} erreicht einen Opportunity Score von {item.opportunity_score:.1f}.",
                    severity="success", symbol=item.symbol,
                    profile_name=profile_name,
                    reason="Opportunity Score mindestens 85",
                ))
            elif item.opportunity_score >= 75:
                alerts.append(AlertResult(
                    title="Interessantes Setup",
                    message=f"{item.symbol} ist mit einem Opportunity Score von {item.opportunity_score:.1f} beobachtenswert.",
                    severity="info", symbol=item.symbol,
                    profile_name=profile_name,
                    reason="Opportunity Score mindestens 75",
                ))
            if item.confidence >= 0.75:
                alerts.append(AlertResult(
                    title="Hohe Confidence",
                    message=f"{item.symbol} besitzt eine Confidence von {item.confidence:.1%}.",
                    severity="success", symbol=item.symbol,
                    profile_name=profile_name,
                    reason="Confidence mindestens 75 %",
                ))
            if item.risk_level == "HIGH":
                alerts.append(AlertResult(
                    title="Erhöhtes Risiko",
                    message=f"{item.symbol} besitzt aktuell ein hohes Risikoniveau.",
                    severity="warning", symbol=item.symbol,
                    profile_name=profile_name,
                    reason="Risk Level HIGH",
                ))
            if item.signal == "BUY":
                alerts.append(AlertResult(
                    title="BUY-Signal",
                    message=f"{item.symbol} besitzt aktuell ein BUY-Signal.",
                    severity="success", symbol=item.symbol,
                    profile_name=profile_name,
                    reason="Signal Engine liefert BUY",
                ))
        return alerts
