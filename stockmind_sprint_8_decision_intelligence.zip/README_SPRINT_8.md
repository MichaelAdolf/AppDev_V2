# StockMind Sprint 8: Decision Intelligence, Calibration & Transparency

Umgesetzt sind Perioden-Risikoqualität, Zeit-bis-Ziel-Verteilung, aktuelle Periodenphase,
Stichprobenqualität, Profil-Konsens, Score-Komponenten, kombinierter Kurs-/Score-Chart,
Score-Band-Kalibrierung, Technical-vs-Fundamental, Analystenzielvergleich, Änderungen
zum vorherigen Handelstag, Warum-Expander und Datenstatus.

## Daten aktualisieren

```powershell
python scripts/refresh_historical_setups.py
python scripts/refresh_historical_opportunities.py
python scripts/run_daily_refresh.py
```

Der Replay muss neu laufen, da Sprint 8 zusätzliche Score-Komponenten und das spätere
60-Tage-Outcome je historischem Handelstag speichert.

## Tests

```powershell
python -m unittest tests.test_period_quality_statistics
python -m unittest tests.test_score_calibration
```

Danach bestehende Regressionstests aus Sprint 1 bis 7 ausführen.

## Methodik

Historische Outcomes sind ausschließlich nachträgliche Validierungswerte. Sie fließen
nicht in den damaligen Opportunity Score ein. Unvollständige 60-Tage-Fenster werden
nicht in die Kalibrierungsquote aufgenommen.
