import pandas as pd
import plotly.graph_objects as go
import streamlit as st
def render(stats,phase):
 st.subheader("Erfolgsqualität der BUY-Perioden");st.caption(f"Stichprobe: {stats.complete_period_count} vollständige Perioden | Sample Quality: {stats.sample_quality}")
 c1,c2,c3,c4=st.columns(4);c1.metric("Ø Drawdown erfolgreich",f"{stats.successful_average_max_drawdown_pct:.1f}%");c2.metric("Ø Drawdown Ziel verfehlt",f"{stats.failed_average_max_drawdown_pct:.1f}%");c3.metric("Median Drawdown",f"{stats.median_max_drawdown_pct:.1f}%");c4.metric("Aktuelle Periodenphase",phase)
 c1,c2,c3,c4=st.columns(4);c1.metric("Median Tage bis Ziel",f"{stats.median_days_to_target:.1f}");c2.metric("Ø Tage bis Ziel",f"{stats.average_days_to_target:.1f}");c3.metric("Schnellstes Ziel",stats.fastest_days_to_target or "-");c4.metric("Spätestes Ziel",stats.slowest_days_to_target or "-")
 df=pd.DataFrame([{"Zeitraum":b.label,"Anzahl":b.count,"Anteil %":b.rate*100} for b in stats.target_time_buckets]);fig=go.Figure(go.Bar(x=df["Zeitraum"],y=df["Anzahl"],text=df["Anteil %"].map(lambda x:f"{x:.1f}%"),textposition="auto"));fig.update_layout(title="Zeit bis zum +8-%-Ziel",xaxis_title="Kalendertage",yaxis_title="Erfolgreiche Perioden");st.plotly_chart(fig,width="stretch")
