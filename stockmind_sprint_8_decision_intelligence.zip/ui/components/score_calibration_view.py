import pandas as pd
import streamlit as st
def render(rows):
 st.subheader("Opportunity-Score-Kalibrierung");st.caption("Nachträgliche Validierung: Das Outcome beeinflusst den historischen Score nicht.")
 df=pd.DataFrame([{"Score-Band":r.label,"Handelstage":r.trading_day_count,"BUY-Signale":r.buy_signal_count,"Vollständige Fälle":r.complete_case_count,"Target Hit %":round(r.target_hit_rate*100,1),"Ø Tage bis Ziel":round(r.average_days_to_target,1),"Median Tage":round(r.median_days_to_target,1),"Ø Drawdown %":round(r.average_max_drawdown_pct,1)} for r in rows]);st.dataframe(df,width="stretch",hide_index=True)
