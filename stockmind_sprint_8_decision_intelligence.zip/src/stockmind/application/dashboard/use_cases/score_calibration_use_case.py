from statistics import median
from stockmind.application.dashboard.models.score_calibration_result import ScoreBandResult
from stockmind.infrastructure.history.historical_opportunity_repository import HistoricalOpportunityRepository
class ScoreCalibrationUseCase:
    BANDS=[("< 50",float("-inf"),50),("50-60",50,60),("60-70",60,70),("70-80",70,80),(">= 80",80,float("inf"))]
    def load(self,symbol,profile_name):
        entries=HistoricalOpportunityRepository().load_by_symbol(symbol,profile_name);results=[]
        for label,lo,hi in self.BANDS:
            members=[e for e in entries if lo<=e.opportunity_score<hi];complete=[e for e in members if e.is_complete]
            hits=[e for e in complete if e.outcome=="TARGET_HIT"];days=[e.days_to_target for e in hits if e.days_to_target is not None]
            draw=[e.max_drawdown_pct for e in complete if e.max_drawdown_pct is not None]
            results.append(ScoreBandResult(label,len(members),sum(e.signal=="BUY" for e in members),len(complete),len(hits)/len(complete) if complete else 0.0,sum(days)/len(days) if days else 0.0,float(median(days)) if days else 0.0,sum(draw)/len(draw) if draw else 0.0))
        return results
