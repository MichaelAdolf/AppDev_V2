from dataclasses import dataclass
@dataclass(frozen=True)
class ScoreBandResult:
    label:str
    trading_day_count:int
    buy_signal_count:int
    complete_case_count:int
    target_hit_rate:float
    average_days_to_target:float
    median_days_to_target:float
    average_max_drawdown_pct:float
