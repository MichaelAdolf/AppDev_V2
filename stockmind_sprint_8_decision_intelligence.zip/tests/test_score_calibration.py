import unittest
from unittest.mock import patch
from types import SimpleNamespace
from stockmind.application.dashboard.use_cases.score_calibration_use_case import ScoreCalibrationUseCase
class T(unittest.TestCase):
 @patch("stockmind.application.dashboard.use_cases.score_calibration_use_case.HistoricalOpportunityRepository")
 def test_bands(self,r):
  r.return_value.load_by_symbol.return_value=[SimpleNamespace(opportunity_score=75,signal="BUY",is_complete=True,outcome="TARGET_HIT",days_to_target=20,max_drawdown_pct=-4)]
  band=next(x for x in ScoreCalibrationUseCase().load("A","balanced") if x.label=="70-80");self.assertEqual(band.target_hit_rate,1);self.assertEqual(band.complete_case_count,1)
if __name__=="__main__":unittest.main()
