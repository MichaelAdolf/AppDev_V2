import unittest
from unittest.mock import patch
from stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case import BuyPeriodDashboardUseCase
from stockmind.domain.history.buy_period_entry import BuyPeriodEntry
class T(unittest.TestCase):
 @patch("stockmind.application.dashboard.use_cases.buy_period_dashboard_use_case.BuyPeriodRepository")
 def test_statistics(self,r):
  def p(out,d,dd):return BuyPeriodEntry("A","balanced","5y","2025-01-01","2025-01-02",2,1,0,0,100,.08,out,out=="TARGET_HIT",d,"2025-03-01",0,10,dd,True)
  r.return_value.load_by_symbol.return_value=[p("TARGET_HIT",10,-4),p("TARGET_HIT",30,-6),p("NEGATIVE",None,-12)]
  s=BuyPeriodDashboardUseCase().load("A").statistics;self.assertEqual(s.median_days_to_target,20);self.assertEqual(s.successful_average_max_drawdown_pct,-5);self.assertEqual(s.failed_average_max_drawdown_pct,-12)
if __name__=="__main__":unittest.main()
