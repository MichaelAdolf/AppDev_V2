"""Reference helper for the two integration changes required in AnalyzeStockUseCase.
Use the provided README or apply the accompanying patch script.
"""

def resolve_profile(repository,profile_name,symbol):
    return repository.get_by_name(profile_name,symbol=symbol)
