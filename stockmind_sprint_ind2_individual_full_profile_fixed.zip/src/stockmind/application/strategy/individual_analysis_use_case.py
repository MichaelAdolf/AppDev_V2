from stockmind.application.use_cases.analyze_stock_use_case import AnalyzeStockUseCase

class IndividualAnalysisUseCase:
    def execute(self,symbol):
        return AnalyzeStockUseCase().execute(symbol=symbol,profile_name="individual")
