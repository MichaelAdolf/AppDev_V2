from stockmind.application.strategy.individual_trading_profile_factory import IndividualTradingProfileFactory
from stockmind.domain.profiles.trading_profile import TradingProfile

class ProfileRepository:
    def __init__(self,database_path=None):self._database_path=database_path
    def get_by_name(self,name,symbol=None):
        normalized=name.lower()
        if normalized=="conservative":return TradingProfile.conservative()
        if normalized=="balanced":return TradingProfile.balanced()
        if normalized=="aggressive":return TradingProfile.aggressive()
        if normalized=="individual":
            if not symbol:raise ValueError("symbol is required for the individual profile")
            return IndividualTradingProfileFactory(self._database_path).create(symbol)
        raise ValueError(f"Unknown trading profile: {name}")
    def get_all(self,symbol=None):
        profiles=[TradingProfile.conservative(),TradingProfile.balanced(),TradingProfile.aggressive()]
        if symbol:
            try:profiles.append(IndividualTradingProfileFactory(self._database_path).create(symbol))
            except ValueError:pass
        return profiles
