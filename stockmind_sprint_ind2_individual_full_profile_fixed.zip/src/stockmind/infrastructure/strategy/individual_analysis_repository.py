import sqlite3
from datetime import datetime
from stockmind.shared.config.settings import Settings

class IndividualAnalysisRepository:
    def __init__(self,database_path=None):self._database_path=database_path or Settings.load().database_path;self._initialize()
    def _connect(self):c=sqlite3.connect(self._database_path);c.row_factory=sqlite3.Row;return c
    def _initialize(self):
        c=self._connect();c.execute("""CREATE TABLE IF NOT EXISTS individual_analysis_metadata(symbol TEXT PRIMARY KEY,profile_id TEXT NOT NULL,profile_version INTEGER NOT NULL,analyzed_at TEXT NOT NULL)""");c.commit();c.close()
    def save(self,symbol,profile):
        c=self._connect();c.execute("INSERT OR REPLACE INTO individual_analysis_metadata VALUES(?,?,?,?)",(symbol.upper(),profile.id,profile.version,datetime.now().isoformat(timespec='seconds')));c.commit();c.close()
    def load(self,symbol):
        c=self._connect();r=c.execute("SELECT * FROM individual_analysis_metadata WHERE symbol=?",(symbol.upper(),)).fetchone();c.close();return dict(r) if r else None
