# Sprint IND2: Individual as Full StockMind Profile

## Ergebnis
Ein ACTIVE Individual-Profil wird zu einem echten TradingProfile und läuft durch dieselben Engines wie Standardprofile:
FeatureEngine → RuleEngine → CoreSetup → Quality → Confidence → Risk → OpportunityScore → Signal.

## Scoring
Die Entry-Schwellen stammen ausschließlich aus dem aktiven Individual-Profil. Für die Opportunity-Score-Gewichte nutzt IND2 bewusst die stabile Balanced-Komposition 30/40/20/10. Gewichte werden noch nicht optimiert.

## Historische Evidenz
Individual verwendet die persistierte Out-of-Sample-Validation des aktiven Profils als historische Evidenz. Quelle: INDIVIDUAL_VALIDATION. Dadurch werden Sample, Validation Hit Rate und Confidence korrekt berücksichtigt, ohne die Standardprofil-Historie zu vermischen.

## Integration
1. Paket entpacken.
2. AnalyzeStock patchen:
```powershell
python scripts/apply_ind2_analyze_stock_patch.py
```
3. Syntax prüfen:
```powershell
python -m py_compile src/stockmind/application/use_cases/analyze_stock_use_case.py
```
4. Aktive Individual-Aktie analysieren:
```powershell
python -c "from stockmind.application.strategy.run_individual_analysis_use_case import RunIndividualAnalysisUseCase; print(RunIndividualAnalysisUseCase().execute('NVDA'))"
```
Symbol entsprechend ersetzen.

## Tests
```powershell
python -m unittest tests.test_individual_trading_profile_factory tests.test_profile_repository_individual tests.test_individual_strategy_training
```

## Wichtige Grenze
IND2 persistiert Latest Analysis unter profile_name='individual' und zeigt Individual im Profilvergleich. Eine vollständige tägliche Historical-Replay- und BUY-Perioden-Persistenz für Individual benötigt noch die Einbindung in den Daily Refresh. Validation Evidence ist bis dahin die belastbare historische Quelle.
