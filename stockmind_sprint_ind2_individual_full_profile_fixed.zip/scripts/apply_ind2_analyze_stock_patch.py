from pathlib import Path

path = Path("src/stockmind/application/use_cases/analyze_stock_use_case.py")
text = path.read_text(encoding="utf-8")

old = """ProfileRepository()
            .get_by_name(
                profile_name
            )"""
new = """ProfileRepository()
            .get_by_name(
                profile_name,
                symbol=symbol
            )"""
if old not in text:
    raise SystemExit("AnalyzeStock profile lookup block not found or already patched.")
text = text.replace(old, new, 1)

import_line = """from stockmind.application.strategy.individual_historical_evidence_use_case import (
    IndividualHistoricalEvidenceUseCase
)
"""
anchor = """from stockmind.application.history.historical_evidence_service import (
    HistoricalEvidenceService
)
"""
if import_line not in text:
    if anchor not in text:
        raise SystemExit("HistoricalEvidenceService import block not found.")
    text = text.replace(anchor, anchor + import_line, 1)

old_evidence = """historical_evidence = (
            HistoricalEvidenceService()
            .build(
                symbol=symbol,
                profile_name=profile_name,
                setup_result=historical_result,
                analysis_period="5y",
                max_gap_days=3
            )
        )"""
new_evidence = """historical_evidence = (
            IndividualHistoricalEvidenceUseCase().load(symbol)
            if profile_name.lower() == "individual"
            else HistoricalEvidenceService().build(
                symbol=symbol,
                profile_name=profile_name,
                setup_result=historical_result,
                analysis_period="5y",
                max_gap_days=3
            )
        )"""
if old_evidence not in text:
    raise SystemExit("Historical evidence block not found or already patched.")
text = text.replace(old_evidence, new_evidence, 1)
path.write_text(text, encoding="utf-8")
print(f"Patched {path}")
