import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.infrastructure.profiles.profile_repository import ProfileRepository
class ProfileRepositoryIndividualTest(unittest.TestCase):
 @patch('stockmind.infrastructure.profiles.profile_repository.IndividualTradingProfileFactory')
 def test_individual_requires_symbol_and_uses_factory(self,factory):
  factory.return_value.create.return_value=SimpleNamespace(name='individual');p=ProfileRepository().get_by_name('individual',symbol='NVDA');self.assertEqual(p.name,'individual');factory.return_value.create.assert_called_once_with('NVDA')
if __name__=='__main__':unittest.main()
