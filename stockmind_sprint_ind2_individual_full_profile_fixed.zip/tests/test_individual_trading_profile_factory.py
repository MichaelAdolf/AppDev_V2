import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.strategy.individual_trading_profile_factory import IndividualTradingProfileFactory
class IndividualTradingProfileFactoryTest(unittest.TestCase):
 @patch('stockmind.application.strategy.individual_trading_profile_factory.FittedProfileRepository')
 def test_active_profile_becomes_trading_profile(self,repo):
  repo.return_value.load_active.return_value=SimpleNamespace(version=3,rsi_oversold_threshold=27.5,rsi_overbought_threshold=70,bollinger_lower_threshold=.2,adx_trend_strength_threshold=25,stochastic_oversold_threshold=15)
  p=IndividualTradingProfileFactory().create('ALV.DE');self.assertEqual(p.name,'individual');self.assertEqual(p.rsi_oversold_threshold,27.5);self.assertEqual(p.opportunity_profile.name,'individual')
if __name__=='__main__':unittest.main()
