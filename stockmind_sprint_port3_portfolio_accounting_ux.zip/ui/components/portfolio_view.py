from datetime import date
import pandas as pd
import streamlit as st
from components.portfolio_exit_view import render as render_portfolio_exit
from stockmind.application.exit.portfolio_exit_use_case import PortfolioExitUseCase
from stockmind.application.portfolio.add_position_use_case import AddPositionUseCase
from stockmind.application.portfolio.delete_portfolio_use_cases import DeletePurchaseLotUseCase,DeleteTradeUseCase
from stockmind.application.portfolio.portfolio_dashboard_use_case import PortfolioDashboardUseCase
from stockmind.application.portfolio.portfolio_intelligence_use_case import PortfolioIntelligenceUseCase
from stockmind.application.portfolio.portfolio_performance_use_case import PortfolioPerformanceUseCase
from stockmind.application.portfolio.sell_position_use_case import SellPositionUseCase
from stockmind.application.portfolio.update_purchase_lot_use_case import UpdatePurchaseLotUseCase
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository

def money(v,signed=False):return '–' if v is None else (f'{v:+,.2f} €' if signed else f'{v:,.2f} €')
def pct(v):return '–' if v is None else f'{v:.2%}'
def render():
 result=PortfolioDashboardUseCase().load();intelligence=PortfolioIntelligenceUseCase().load();decisions=PortfolioExitUseCase().load();st.header('Portfolio');st.caption('Alle Kauf- und Verkaufspreise sind EUR je Aktie. Gesamtwerte berechnet StockMind automatisch.')
 a,b,c,d=st.columns(4);a.metric('Investiertes Kapital',money(result.invested_amount));b.metric('Aktueller Marktwert',money(result.market_value));c.metric('Unrealisierter P/L',money(result.unrealized_profit,True),pct(result.unrealized_return_pct));d.metric('Realisierter Nettogewinn',money(result.realized_net_profit,True))
 e,f,g=st.columns(3);e.metric('Realisierter Bruttogewinn',money(result.realized_gross_profit,True));f.metric('Gebühren realisiert',money(result.realized_fees));g.metric('Steuern realisiert',money(result.realized_tax_paid))
 s1,s2,s3=st.columns(3);s1.metric('🔴 EXIT REVIEW',sum(x.status=='EXIT_REVIEW' for x in decisions));s2.metric('🟡 WATCH',sum(x.status=='WATCH' for x in decisions));s3.metric('🔵 HOLD',sum(x.status=='HOLD' for x in decisions))
 tabs=st.tabs(['Position Intelligence','Exit Intelligence','Offene Positionen','Kauf hinzufügen','Kauftranchen verwalten','Position verkaufen','Trade History','Performance'])
 with tabs[0]:
  if not intelligence:st.info('Noch keine offenen Positionen vorhanden.')
  for x in intelligence:
   icon='🔴' if x.attention_level=='CRITICAL' else '🟡' if x.attention_level=='ATTENTION' else '🔵'
   with st.container(border=True):
    st.subheader(f'{icon} {x.company_name} ({x.symbol})');c1,c2,c3,c4=st.columns(4);c1.metric('Aktueller P/L',money(x.unrealized_profit,True),pct(x.unrealized_return_pct));c2.metric('+8-%-Zielkurs je Aktie',money(x.target_price));c3.metric('Verbleibende Tage',x.remaining_strategy_days);c4.metric('Handlungsstatus',x.attention_level)
    if x.attention_reasons:st.warning('Prüfhintergrund: '+', '.join(x.attention_reasons))
    changed=[]
    if x.score_change is not None and abs(x.score_change)>=0.1:changed.append(f'Score {x.entry_score:.1f} → {x.current_score:.1f} ({x.score_change:+.1f})')
    if x.confidence_change is not None and abs(x.confidence_change)>=.01:changed.append(f'Confidence {x.entry_confidence:.1%} → {x.current_confidence:.1%} ({x.confidence_change:+.1%})')
    if x.entry_risk!=x.current_risk:changed.append(f'Risiko {x.entry_risk} → {x.current_risk}')
    if x.entry_signal!=x.current_signal:changed.append(f'Signal {x.entry_signal} → {x.current_signal}')
    st.caption('Relevante Veränderungen: '+('; '.join(changed) if changed else 'keine wesentliche Veränderung seit Einstieg.'))
    with st.expander('Alle Kennzahlen seit Einstieg'):
     st.dataframe(pd.DataFrame([{'Kennzahl':'Opportunity Score','Einstieg':x.entry_score,'Heute':x.current_score,'Delta':x.score_change},{'Kennzahl':'Confidence','Einstieg':x.entry_confidence,'Heute':x.current_confidence,'Delta':x.confidence_change},{'Kennzahl':'Risiko','Einstieg':x.entry_risk,'Heute':x.current_risk,'Delta':''},{'Kennzahl':'Signal','Einstieg':x.entry_signal,'Heute':x.current_signal,'Delta':''}]),hide_index=True,width='stretch')
 with tabs[1]:render_portfolio_exit()
 with tabs[2]:
  if not result.positions:st.info('Noch keine offenen Positionen vorhanden.')
  else:st.dataframe(pd.DataFrame([{'Aktie':f'{x.position.company_name} ({x.position.symbol})','Tranchen':len(x.lots),'Stückzahl':x.position.quantity,'Ø Kaufpreis/Aktie €':round(x.position.purchase_price,2),'Kaufwert gesamt €':round(x.purchase_value,2),'Investiert gesamt €':round(x.invested_amount,2),'Aktueller Kurs/Aktie €':None if x.current_price is None else round(x.current_price,2),'Marktwert gesamt €':None if x.market_value is None else round(x.market_value,2),'P/L je Aktie €':None if x.profit_per_share is None else round(x.profit_per_share,2),'P/L gesamt €':None if x.unrealized_profit is None else round(x.unrealized_profit,2),'P/L %':None if x.unrealized_return_pct is None else round(x.unrealized_return_pct*100,2)} for x in result.positions]),hide_index=True,width='stretch')
 with tabs[3]:
  watch=[x for x in WatchlistRepository().load_all() if x.active];labels={f'{x.company_name} ({x.symbol})':x.symbol for x in watch}
  if not labels:st.warning('Keine aktiven Watchlist-Aktien.')
  else:
   with st.form('add_portfolio_lot'):
    label=st.selectbox('Aktie',list(labels));purchase_date=st.date_input('Kaufdatum',date.today());c1,c2,c3=st.columns(3);price=c1.number_input('Kaufpreis je Aktie (€)',min_value=.01);quantity=c2.number_input('Stückzahl',min_value=.0001,format='%.4f');fees=c3.number_input('Kaufgebühren gesamt (€)',min_value=0.0);st.info(f'Kaufwert gesamt: {money(price*quantity)} · Investiertes Kapital: {money(price*quantity+fees)}');profile=st.selectbox('Entry-Profil',['conservative','balanced','aggressive','individual'],index=1);note=st.text_area('Notiz');submit=st.form_submit_button('Kauf hinzufügen',type='primary')
   if submit:AddPositionUseCase().execute(labels[label],purchase_date,price,quantity,fees,profile,note);st.success('Kauf hinzugefügt.');st.rerun()
 with tabs[4]:
  lots=[(view,lot) for view in result.positions for lot in view.lots]
  if not lots:st.info('Keine Kauftranchen vorhanden.')
  else:
   choices={f'{view.position.symbol} · {lot.purchase_date} · {lot.quantity:g} Stück zu {lot.purchase_price:.2f} € je Aktie':lot.id for view,lot in lots};selected=st.selectbox('Kauftranche',list(choices));lot=next(x for _,x in lots if x.id==choices[selected])
   with st.form('edit_portfolio_lot'):
    purchase_date=st.date_input('Kaufdatum',date.fromisoformat(lot.purchase_date));c1,c2,c3=st.columns(3);price=c1.number_input('Kaufpreis je Aktie (€)',min_value=.01,value=float(lot.purchase_price));quantity=c2.number_input('Stückzahl',min_value=.0001,value=float(lot.quantity),format='%.4f');fees=c3.number_input('Kaufgebühren gesamt (€)',min_value=0.0,value=float(lot.purchase_fees));st.info(f'Kaufwert gesamt: {money(price*quantity)} · Investiertes Kapital: {money(price*quantity+fees)}');profiles=['conservative','balanced','aggressive','individual'];profile=st.selectbox('Entry-Profil',profiles,index=profiles.index(lot.entry_profile) if lot.entry_profile in profiles else 1);note=st.text_area('Notiz',lot.note);save=st.form_submit_button('Änderungen speichern')
   if save:UpdatePurchaseLotUseCase().execute(lot.id,purchase_date,price,quantity,fees,profile,note);st.success('Kauftranche aktualisiert.');st.rerun()
   confirm=st.checkbox('Kauftranche dauerhaft löschen.');
   if st.button('Kauftranche löschen',disabled=not confirm):DeletePurchaseLotUseCase().execute(lot.id);st.rerun()
 with tabs[5]:
  if not result.positions:st.info('Keine offene Position vorhanden.')
  else:
   choices={f'{x.position.company_name} ({x.position.symbol}) · {x.position.quantity:g} Stück':x.position.id for x in result.positions};label=st.selectbox('Position',list(choices));view=next(x for x in result.positions if x.position.id==choices[label]);sale_date=st.date_input('Verkaufsdatum',date.today());c1,c2,c3=st.columns(3);price=c1.number_input('Verkaufspreis je Aktie (€)',min_value=.01);fees=c2.number_input('Verkaufsgebühren gesamt (€)',min_value=0.0);tax=c3.number_input('Tatsächlich belastete Steuern gesamt (€)',min_value=0.0,help='Kapitalertragsteuer, Solidaritätszuschlag und ggf. Kirchensteuer laut Brokerabrechnung.');preview=SellPositionUseCase.preview(view.position,price,fees,tax);st.subheader('Verkaufsabrechnung');st.dataframe(pd.DataFrame([{'Position':'Kaufwert gesamt','Betrag':money(preview['purchase_value'])},{'Position':'Verkaufserlös brutto','Betrag':money(preview['sale_value'])},{'Position':'Bruttogewinn','Betrag':money(preview['gross_profit'],True)},{'Position':'Gebühren Kauf + Verkauf','Betrag':money(preview['total_fees'])},{'Position':'Steuern','Betrag':money(preview['tax_paid'])},{'Position':'Nettoerlös','Betrag':money(preview['net_sale_proceeds'])},{'Position':'Nettogewinn','Betrag':money(preview['net_profit'],True)},{'Position':'Nettogewinn %','Betrag':pct(preview['net_return_pct'])}]),hide_index=True,width='stretch');reason=st.selectbox('Exit-Grund',['MANUAL','TARGET_REACHED','TIME_LIMIT','STOP_LOSS','SIGNAL_DETERIORATION']);note=st.text_area('Verkaufsnotiz');confirm=st.checkbox('Ich bestätige den vollständigen Verkauf dieser Position.')
   if st.button('Position vollständig verkaufen',type='primary',disabled=not confirm):trade=SellPositionUseCase().execute(choices[label],sale_date,price,fees,tax,reason,note);st.success(f'Trade abgeschlossen. Nettogewinn: {money(trade.net_profit,True)}');st.rerun()
 with tabs[6]:
  if not result.trades:st.info('Noch keine abgeschlossenen Trades.')
  else:
   st.dataframe(pd.DataFrame([{'Aktie':f'{t.company_name} ({t.symbol})','Kaufdatum':t.purchase_date,'Verkaufsdatum':t.sale_date,'Tage':t.holding_days,'Kaufpreis/Aktie €':round(t.purchase_price,2),'Stückzahl':t.quantity,'Kaufwert €':round(t.purchase_value,2),'Kaufgebühr €':round(t.purchase_fees,2),'Verkaufspreis/Aktie €':round(t.sale_price,2),'Verkaufserlös €':round(t.sale_value,2),'Verkaufsgebühr €':round(t.sale_fees,2),'Bruttogewinn €':round(t.gross_profit,2),'Bruttogewinn %':round(t.gross_return_pct*100,2),'Steuern €':round(t.tax_paid,2),'Nettogewinn €':round(t.net_profit,2),'Nettogewinn %':round(t.net_return_pct*100,2),'Profil':t.entry_profile,'Exit-Grund':t.exit_reason} for t in result.trades]),hide_index=True,width='stretch');choices={f'{t.symbol} · {t.sale_date} · {t.net_profit:+.2f} € Nettogewinn':t.id for t in result.trades};selected=st.selectbox('Fehlerhaften Trade löschen',list(choices));confirm=st.checkbox('Trade dauerhaft löschen.');
   if st.button('Trade löschen',disabled=not confirm):DeleteTradeUseCase().execute(choices[selected]);st.rerun()
 with tabs[7]:
  performance=PortfolioPerformanceUseCase().load();periods={'month':'Dieser Monat','six_months':'Letzte 6 Monate','ytd':'Seit 01.01.','twelve_months':'Letzte 12 Monate','all':'Gesamt'};st.dataframe(pd.DataFrame([{'Zeitraum':label,'Trades':performance[k]['trade_count'],'Gewinner':performance[k]['winner_count'],'Verlierer':performance[k]['loser_count'],'Win Rate %':round(performance[k]['win_rate']*100,1),'Bruttogewinn €':round(performance[k]['gross_profit'],2),'Bruttogewinn %':round(performance[k]['gross_return_pct']*100,2),'Gebühren €':round(performance[k]['fees_paid'],2),'Steuern €':round(performance[k]['tax_paid'],2),'Nettogewinn €':round(performance[k]['net_profit'],2),'Nettogewinn %':round(performance[k]['net_return_pct']*100,2),'Ø Gewinner €':round(performance[k]['average_winner'],2),'Ø Verlierer €':round(performance[k]['average_loser'],2),'Ø Tage':round(performance[k]['average_holding_days'],1)} for k,label in periods.items()]),hide_index=True,width='stretch');st.subheader('Performance nach Entry-Profil');st.dataframe(pd.DataFrame([{'Profil':p.title(),'Trades':v['trade_count'],'Win Rate %':round(v['win_rate']*100,1),'Bruttogewinn €':round(v['gross_profit'],2),'Steuern €':round(v['tax_paid'],2),'Nettogewinn €':round(v['net_profit'],2),'Nettogewinn %':round(v['net_return_pct']*100,2),'Ø Tage':round(v['average_holding_days'],1)} for p,v in performance['by_profile'].items()]),hide_index=True,width='stretch')
