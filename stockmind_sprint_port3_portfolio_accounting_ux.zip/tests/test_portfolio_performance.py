import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.portfolio.portfolio_performance_use_case import PortfolioPerformanceUseCase
class PortfolioPerformanceTest(unittest.TestCase):
 @patch('stockmind.application.portfolio.portfolio_performance_use_case.PortfolioRepository')
 def test_gross_fees_tax_and_net_are_transparent(self,repo):
  trade=SimpleNamespace(sale_date='2026-11-01',entry_profile='balanced',net_profit=80,gross_profit=100,profit_after_fees=90,tax_paid=10,purchase_fees=5,sale_fees=5,purchase_value=1000,invested_amount=1005,total_fees=10,holding_days=30);repo.return_value.load_trades.return_value=[trade];r=PortfolioPerformanceUseCase().load()['all'];self.assertEqual(r['gross_profit'],100);self.assertEqual(r['fees_paid'],10);self.assertEqual(r['tax_paid'],10);self.assertEqual(r['net_profit'],80);self.assertAlmostEqual(r['gross_return_pct'],.1);self.assertAlmostEqual(r['net_return_pct'],80/1005)
if __name__=='__main__':unittest.main()
