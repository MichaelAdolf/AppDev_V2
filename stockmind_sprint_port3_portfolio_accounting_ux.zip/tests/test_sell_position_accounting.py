import unittest
from types import SimpleNamespace
from stockmind.application.portfolio.sell_position_use_case import SellPositionUseCase
class SellPositionAccountingTest(unittest.TestCase):
 def test_preview_uses_per_share_prices_and_total_fees_tax(self):
  p=SimpleNamespace(purchase_price=250,quantity=4,purchase_fees=1);r=SellPositionUseCase.preview(p,280,1,31);self.assertEqual(r['purchase_value'],1000);self.assertEqual(r['sale_value'],1120);self.assertEqual(r['gross_profit'],120);self.assertEqual(r['total_fees'],2);self.assertEqual(r['net_sale_proceeds'],1088);self.assertEqual(r['net_profit'],87);self.assertAlmostEqual(r['net_return_pct'],87/1001)
if __name__=='__main__':unittest.main()
