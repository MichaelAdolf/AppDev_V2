from datetime import date,timedelta
from stockmind.infrastructure.portfolio.portfolio_repository import PortfolioRepository
class PortfolioPerformanceUseCase:
 def __init__(self,database_path=None):self._repository=PortfolioRepository(database_path)
 def load(self):
  trades=self._repository.load_trades();today=date.today();starts={'month':today.replace(day=1),'six_months':today-timedelta(days=183),'ytd':date(today.year,1,1),'twelve_months':today-timedelta(days=365)};result={'all':self._aggregate(trades)}
  for key,start in starts.items():result[key]=self._aggregate([t for t in trades if date.fromisoformat(t.sale_date)>=start])
  profiles=sorted(set(['conservative','balanced','aggressive','individual']+[t.entry_profile for t in trades]));result['by_profile']={p:self._aggregate([t for t in trades if t.entry_profile==p]) for p in profiles};return result
 def _aggregate(self,trades):
  winners=[t for t in trades if t.net_profit>0];losers=[t for t in trades if t.net_profit<0];purchase_value=sum(t.purchase_value for t in trades);invested=sum(t.invested_amount for t in trades);gross=sum(t.gross_profit for t in trades);net=sum(t.net_profit for t in trades);fees=sum(t.total_fees for t in trades);tax=sum(t.tax_paid for t in trades)
  return {'trade_count':len(trades),'winner_count':len(winners),'loser_count':len(losers),'win_rate':len(winners)/len(trades) if trades else 0.0,'purchase_value':purchase_value,'invested_amount':invested,'gross_profit':gross,'gross_return_pct':gross/purchase_value if purchase_value else 0.0,'fees_paid':fees,'profit_after_fees':sum(t.profit_after_fees for t in trades),'tax_paid':tax,'net_profit':net,'net_return_pct':net/invested if invested else 0.0,'average_holding_days':sum(t.holding_days for t in trades)/len(trades) if trades else 0.0,'average_winner':sum(t.net_profit for t in winners)/len(winners) if winners else 0.0,'average_loser':sum(t.net_profit for t in losers)/len(losers) if losers else 0.0,'best_trade':max((t.net_profit for t in trades),default=0.0),'worst_trade':min((t.net_profit for t in trades),default=0.0)}
