from datetime import date,datetime
from uuid import uuid4
from stockmind.domain.portfolio.portfolio_trade import PortfolioTrade
from stockmind.infrastructure.portfolio.portfolio_repository import PortfolioRepository
class SellPositionUseCase:
 def __init__(self,database_path=None):self._repository=PortfolioRepository(database_path)
 @staticmethod
 def preview(position,sale_price,sale_fees=0.0,tax_paid=0.0):
  purchase_value=position.purchase_price*position.quantity;sale_value=float(sale_price)*position.quantity;gross=sale_value-purchase_value;after_fees=gross-position.purchase_fees-float(sale_fees);net=after_fees-float(tax_paid);invested=purchase_value+position.purchase_fees
  return {'purchase_value':purchase_value,'invested_amount':invested,'sale_value':sale_value,'gross_profit':gross,'gross_return_pct':gross/purchase_value if purchase_value else 0.0,'purchase_fees':position.purchase_fees,'sale_fees':float(sale_fees),'total_fees':position.purchase_fees+float(sale_fees),'tax_paid':float(tax_paid),'profit_after_fees':after_fees,'net_sale_proceeds':sale_value-float(sale_fees)-float(tax_paid),'net_profit':net,'net_return_pct':net/invested if invested else 0.0}
 def execute(self,position_id,sale_date,sale_price,sale_fees=0.0,tax_paid=0.0,exit_reason='MANUAL',note=''):
  position=self._repository.load_position(position_id)
  if position is None or position.status!='OPEN':raise ValueError('Offene Position wurde nicht gefunden.')
  if sale_price<=0:raise ValueError('Verkaufspreis je Aktie muss größer als 0 sein.')
  if sale_fees<0 or tax_paid<0:raise ValueError('Gebühren und Steuern dürfen nicht negativ sein.')
  purchase_day=date.fromisoformat(position.purchase_date);sale_day=date.fromisoformat(str(sale_date))
  if sale_day<purchase_day:raise ValueError('Verkaufsdatum darf nicht vor dem Kaufdatum liegen.')
  values=self.preview(position,sale_price,sale_fees,tax_paid);now=datetime.now().isoformat(timespec='seconds');trade=PortfolioTrade(str(uuid4()),position.id,position.symbol,position.company_name,position.purchase_date,position.purchase_price,str(sale_date),float(sale_price),position.quantity,position.purchase_fees,float(sale_fees),float(tax_paid),values['gross_profit'],values['profit_after_fees'],values['net_profit'],values['gross_return_pct'],values['net_return_pct'],(sale_day-purchase_day).days,position.entry_profile,position.entry_signal,position.entry_opportunity_score,exit_reason,note.strip(),now);self._repository.close_position(position.id,now,trade);return trade
