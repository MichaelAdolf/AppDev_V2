# PORT3 Portfolio Accounting & UX

## Accounting contract
- Purchase price and sale price are always EUR per share.
- Quantity multiplies the per-share price.
- Purchase/sale fees and tax are total EUR amounts for the transaction.
- Tax is the actually charged broker amount (capital gains tax, solidarity surcharge, and church tax where applicable). StockMind does not estimate German tax.

## Definitions
- Purchase value = purchase price/share × quantity
- Invested amount = purchase value + purchase fees
- Gross sale proceeds = sale price/share × quantity
- Gross profit = gross sale proceeds − purchase value
- Profit after fees = gross profit − purchase fees − sale fees
- Net profit = profit after fees − tax
- Net sale proceeds = gross sale proceeds − sale fees − tax
- Gross return % = gross profit / purchase value
- Net return % = net profit / invested amount

## Scope
Full position sales only. Partial sells and FIFO are deliberately excluded.

## Tests
```powershell
python -m unittest tests.test_sell_position_accounting tests.test_portfolio_performance tests.test_portfolio_foundation tests.test_portfolio_lots tests.test_portfolio_intelligence tests.test_productive_exit_engine
```
