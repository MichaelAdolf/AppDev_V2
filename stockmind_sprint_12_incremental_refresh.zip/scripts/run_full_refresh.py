from stockmind.application.refresh.bootstrap_stock_use_case import BootstrapStockUseCase
from stockmind.infrastructure.refresh.refresh_state_repository import RefreshStateRepository
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository

def main():
    state=RefreshStateRepository()
    for symbol in WatchlistRepository().load_active_symbols():
        print(f"FULL REBUILD: {symbol}");BootstrapStockUseCase().execute(symbol);state.mark_success(symbol,"full")
    print("[OK] Full rebuild complete")
if __name__=="__main__":main()
