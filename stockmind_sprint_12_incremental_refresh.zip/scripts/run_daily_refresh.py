from datetime import datetime
from stockmind.application.refresh.refresh_coordinator import RefreshCoordinator

def main():
    start=datetime.now();print("\n=== STOCKMIND INCREMENTAL REFRESH START ===")
    results=RefreshCoordinator().run_daily()
    for result in results:print(f"[OK] {result.symbol}: {result.mode}")
    print(f"=== DONE | Dauer: {datetime.now()-start} ===\n")
    return results
if __name__=="__main__":main()
