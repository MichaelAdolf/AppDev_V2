import argparse
from stockmind.application.refresh.bootstrap_stock_use_case import BootstrapStockUseCase
from stockmind.infrastructure.refresh.refresh_state_repository import RefreshStateRepository

def main():
    parser=argparse.ArgumentParser();parser.add_argument("symbol");args=parser.parse_args();symbol=args.symbol.upper()
    BootstrapStockUseCase().execute(symbol);RefreshStateRepository().mark_success(symbol,"bootstrap");print(f"[OK] Bootstrap complete: {symbol}")
if __name__=="__main__":main()
