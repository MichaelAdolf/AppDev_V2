import unittest
from unittest.mock import patch
from stockmind.application.refresh.refresh_coordinator import RefreshCoordinator

class RefreshCoordinatorTest(unittest.TestCase):
    @patch("stockmind.application.refresh.refresh_coordinator.DailySymbolRefreshUseCase")
    @patch("stockmind.application.refresh.refresh_coordinator.BootstrapStockUseCase")
    @patch("stockmind.application.refresh.refresh_coordinator.ChartDataRepository")
    @patch("stockmind.application.refresh.refresh_coordinator.RefreshStateRepository")
    @patch("stockmind.application.refresh.refresh_coordinator.WatchlistRepository")
    def test_new_symbol_bootstrap_existing_incremental(self,watch,state,chart,bootstrap,daily):
        watch.return_value.load_active_symbols.return_value=["NEW","OLD"]
        state.return_value.is_bootstrapped.return_value=False
        chart.return_value.get_latest_date.side_effect=[None,"2026-09-25"]
        results=RefreshCoordinator().run_daily()
        bootstrap.return_value.execute.assert_called_once_with("NEW")
        daily.return_value.execute.assert_called_once_with("OLD")
        self.assertEqual([r.mode for r in results],["bootstrap","incremental"])
if __name__=="__main__":unittest.main()
