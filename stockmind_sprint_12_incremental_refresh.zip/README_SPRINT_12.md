# StockMind Sprint 12: Incremental Refresh Architecture

## Modi

- `run_daily_refresh.py`: Coordinator erkennt neue vs. bestehende Symbole.
- `bootstrap_stock.py SYMBOL`: gezielter 5-Jahres-Aufbau einer Aktie.
- `run_full_refresh.py`: bewusster kompletter Neuaufbau aller aktiven Symbole.

## Wichtige Transparenz zur aktuellen Iteration

Chart- und Indicator-DB-Schreibvorgänge sind inkrementell. Eine neue Aktie erhält nur
für dieses Symbol den 5-Jahres-Bootstrap. Der Daily Coordinator vermeidet außerdem
1m/6m/1y/3y Historical-Setup-Replays und arbeitet täglich nur mit dem kanonischen
5y-Zeitraum.

Die bestehenden `HistoricalSetupReplayUseCase`- und
`HistoricalOpportunityReplayUseCase`-Implementierungen sind jedoch intern noch auf
vollständigen Replay ausgelegt: sie laden historische Kursdaten und ersetzen ihre
profilspezifischen Resultate. Sprint 12 ändert diese fachkritischen Engines deshalb
nicht zu einem unsicheren Append-Verfahren. So bleibt die Ergebnislogik unverändert,
während bereits redundante Watchlist- und Multi-Period-Arbeit entfällt.

Ein weitergehendes echtes Daily-Append dieser beiden Replay-Engines sollte separat
umgesetzt und gegen Look-Ahead-/Outcome-Regressionen getestet werden.

## Test

```powershell
python -m unittest tests.test_refresh_coordinator
```

## Betrieb

Node-RED / API ruft weiterhin `POST /refresh` auf. Dieser Endpoint nutzt jetzt den
Refresh Coordinator.

Manuell neue Aktie:

```powershell
python scripts/bootstrap_stock.py NFLX
```

Kompletter Rebuild nach Regel-/Strategieänderungen:

```powershell
python scripts/run_full_refresh.py
```
