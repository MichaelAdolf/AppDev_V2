from stockmind.application.history.daily_buy_signal_evaluator import DailyBuySignalEvaluator
from stockmind.domain.indicators.indicator_result import IndicatorResult
from stockmind.infrastructure.profiles.profile_repository import ProfileRepository


def main():
    indicator_result = IndicatorResult(
        symbol="TEST",
        values={
            "rsi_14": 32.0,
            "sma_20": 100.0,
            "ema_20": 99.0,
            "macd": -0.5,
            "bollinger_position": 0.30,
            "adx_14": 17.0,
            "stoch_k_14": 23.0,
        },
    )
    evaluator = DailyBuySignalEvaluator()
    results = {}
    for profile in ProfileRepository().get_all():
        result = evaluator.evaluate(
            symbol="TEST",
            profile=profile,
            analysis_period="test",
            trading_date="2026-01-02",
            entry_price=100.0,
            indicator_result=indicator_result,
        )
        results[profile.name] = result
        print(
            f"{profile.name}: BUY={result.is_buy}, "
            f"quality={result.quality}, missing={result.missing_rules}"
        )

    assert results["conservative"].is_buy is False
    assert results["balanced"].is_buy is False
    assert results["aggressive"].is_buy is True
    print("Profile-dependent BUY signal test: OK")


if __name__ == "__main__":
    main()
