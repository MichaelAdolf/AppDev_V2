# StockMind Sprint 2

## Inhalt

Sprint 2 führt eine einheitliche, profilabhängige Tages-BUY-Auswertung ein.

- Conservative, Balanced und Aggressive werden separat ausgewertet.
- Die Profilgrenzen aus `TradingProfile` wirken über die bestehende `FeatureEngine`.
- BUY basiert auf dem gemeinsamen RuleSet, CoreSetup und einer Mindestqualität MEDIUM.
- Jeder auswertbare Handelstag wird gespeichert, ohne Cooldown.
- Historical Success und Historical Setup Replay verwenden dieselbe Tages-BUY-Logik.
- Neue Tabelle: `daily_buy_signals`.

## SignalDecision statt signal_result.py

Im vorhandenen Projekt liefert `SignalEngine` ein `SignalDecision` zurück. Eine Datei
`signal_result.py` ist deshalb für Sprint 2 nicht erforderlich.

## Neue Dateien

- `domain/history/daily_buy_signal.py`
- `application/history/daily_buy_signal_evaluator.py`
- `infrastructure/history/daily_buy_signal_repository.py`
- zwei Tests

## Vor der Übernahme

1. Git-Checkpoint erstellen.
2. `config/stockmind/stockmind.db` sichern.
3. Sprint-1-Dateien müssen bereits aktiv sein.

## Tests

```powershell
python scripts/test_daily_buy_signals.py
python -m unittest tests.test_daily_buy_signal_repository
python tests/test_historical_outcomes.py
python scripts/test_historical_success_engine.py
python scripts/refresh_historical_setups.py
```

Erwartung für den Profiltest:

```text
conservative: BUY=False
balanced: BUY=False
aggressive: BUY=True
Profile-dependent BUY signal test: OK
```

## Datenbankprüfung

Nach `refresh_historical_setups.py` existiert die Tabelle `daily_buy_signals`.
Für dasselbe Symbol und Datum können drei Datensätze vorhanden sein, jeweils einer
für conservative, balanced und aggressive.

## Bewusst noch nicht enthalten

- BUY-Periodenbildung mit maximal drei Gap-Kalendertagen
- neue `buy_periods`-Tabelle
- API- und Dashboard-Erweiterungen
- Opportunity-Score-Umstellung
- Jarvis-Profilvergleich
