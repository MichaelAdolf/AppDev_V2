import pandas as pd

from stockmind.application.history.daily_buy_signal_evaluator import (
    DailyBuySignalEvaluator,
)
from stockmind.domain.features.feature_engine import FeatureEngine
from stockmind.domain.history.historical_outcome import HistoricalOutcome, evaluate_price_window
from stockmind.domain.historical_similarity.similarity_candidate import SimilarityCandidate
from stockmind.domain.historical_similarity.similarity_engine import SimilarityEngine
from stockmind.domain.historical_success.historical_success_result import HistoricalSuccessResult
from stockmind.domain.indicators.indicator_result import IndicatorResult
from stockmind.domain.profiles.trading_profile import TradingProfile


class HistoricalSuccessEngine:
    FLAT_THRESHOLD_PCT = 1.0

    def analyze(
        self,
        symbol: str,
        data: pd.DataFrame,
        profile: TradingProfile,
        rule_set_name: str = "entry_setup",
        target_pct: float = 0.08,
        lookahead_days: int = 60,
        min_quality: str = "MEDIUM",
        top_n_similar: int | None = None,
    ) -> HistoricalSuccessResult:
        prepared = self._prepare_data(data)
        current_features = self._build_current_features(symbol, prepared, profile)
        evaluator = DailyBuySignalEvaluator()
        similarity_engine = SimilarityEngine()
        candidates = []

        for index in range(30, len(prepared)):
            row = prepared.iloc[index]
            if not self._is_valid_row(row):
                continue
            indicator_result = self._indicator_result(symbol, row)
            signal = evaluator.evaluate(
                symbol=symbol,
                profile=profile,
                analysis_period="5y",
                trading_date=row.name.date().isoformat(),
                entry_price=float(row["Close"]),
                indicator_result=indicator_result,
                rule_set_name=rule_set_name,
                min_quality=min_quality,
            )
            if not signal.is_buy:
                continue
            historical_features = FeatureEngine().build(indicator_result, profile)
            evaluation = evaluate_price_window(
                data=prepared[["High", "Low", "Close"]],
                setup_date=row.name,
                entry_price=signal.entry_price,
                target_pct=target_pct,
                lookahead_calendar_days=lookahead_days,
                flat_threshold_pct=self.FLAT_THRESHOLD_PCT,
            )
            similarity = similarity_engine.calculate(
                current=current_features,
                historical=historical_features,
            )
            max_future_high = (
                signal.entry_price * (1 + evaluation.max_gain_pct / 100)
                if evaluation.max_gain_pct is not None
                else signal.entry_price
            )
            candidates.append(
                SimilarityCandidate(
                    trading_date=row.name.date(),
                    similarity_score=similarity,
                    successful=evaluation.outcome == HistoricalOutcome.TARGET_HIT,
                    entry_price=signal.entry_price,
                    max_future_high=max_future_high,
                    outcome=evaluation.outcome.value,
                    is_complete=evaluation.is_complete,
                    window_end_return_pct=evaluation.window_end_return_pct,
                    max_drawdown_pct=evaluation.max_drawdown_pct,
                    days_to_target=evaluation.days_to_target,
                )
            )

        selected = candidates
        if top_n_similar is not None:
            selected = sorted(
                candidates,
                key=lambda item: item.similarity_score,
                reverse=True,
            )[:top_n_similar]

        complete = [item for item in selected if item.is_complete]
        counts = {
            outcome: sum(1 for item in complete if item.outcome == outcome.value)
            for outcome in (
                HistoricalOutcome.TARGET_HIT,
                HistoricalOutcome.BELOW_TARGET,
                HistoricalOutcome.FLAT,
                HistoricalOutcome.NEGATIVE,
            )
        }
        incomplete_count = len(selected) - len(complete)
        complete_count = len(complete)
        target_hit_count = counts[HistoricalOutcome.TARGET_HIT]
        average_similarity = (
            sum(item.similarity_score for item in selected) / len(selected)
            if selected else None
        )

        return HistoricalSuccessResult(
            symbol=symbol,
            profile_name=profile.name,
            rule_set_name=rule_set_name,
            setup_count=len(selected),
            success_count=target_hit_count,
            failure_count=complete_count - target_hit_count,
            success_rate=self._rate(target_hit_count, complete_count),
            target_pct=target_pct,
            lookahead_days=lookahead_days,
            min_quality=min_quality,
            sample_quality=self._sample_quality(complete_count),
            similarity_mode=top_n_similar is not None,
            top_n_similar=top_n_similar,
            average_similarity=average_similarity,
            complete_count=complete_count,
            target_hit_count=target_hit_count,
            below_target_count=counts[HistoricalOutcome.BELOW_TARGET],
            flat_count=counts[HistoricalOutcome.FLAT],
            negative_count=counts[HistoricalOutcome.NEGATIVE],
            incomplete_count=incomplete_count,
            target_hit_rate=self._rate(target_hit_count, complete_count),
            below_target_rate=self._rate(counts[HistoricalOutcome.BELOW_TARGET], complete_count),
            flat_rate=self._rate(counts[HistoricalOutcome.FLAT], complete_count),
            negative_rate=self._rate(counts[HistoricalOutcome.NEGATIVE], complete_count),
        )

    def _build_current_features(self, symbol, prepared, profile):
        for index in range(len(prepared) - 1, 30, -1):
            row = prepared.iloc[index]
            if self._is_valid_row(row):
                return FeatureEngine().build(self._indicator_result(symbol, row), profile)
        raise ValueError("No valid current feature row found.")

    def _indicator_result(self, symbol, row):
        return IndicatorResult(symbol=symbol, values={
            "rsi_14": float(row["rsi_14"]),
            "sma_20": float(row["sma_20"]),
            "ema_20": float(row["ema_20"]),
            "macd": float(row["macd"]),
            "bollinger_position": float(row["bollinger_position"]),
            "adx_14": float(row["adx_14"]),
            "stoch_k_14": float(row["stoch_k_14"]),
        })

    def _prepare_data(self, data):
        prepared = data.copy()
        prepared.index = pd.to_datetime(prepared.index)
        if prepared.index.tz is not None:
            prepared.index = prepared.index.tz_localize(None)
        prepared = prepared.sort_index()
        prepared["sma_20"] = prepared["Close"].rolling(20).mean()
        prepared["ema_20"] = prepared["Close"].ewm(span=20).mean()
        delta = prepared["Close"].diff()
        gain = delta.where(delta > 0, 0).rolling(14).mean()
        loss = -delta.where(delta < 0, 0).rolling(14).mean()
        prepared["rsi_14"] = 100 - 100 / (1 + gain / loss)
        prepared["macd"] = prepared["Close"].ewm(span=12).mean() - prepared["Close"].ewm(span=26).mean()
        mean = prepared["Close"].rolling(20).mean()
        std = prepared["Close"].rolling(20).std()
        prepared["bollinger_position"] = (prepared["Close"] - (mean - 2 * std)) / (4 * std)
        high, low, close = prepared["High"], prepared["Low"], prepared["Close"]
        up_move, down_move = high.diff(), low.shift(1) - low
        plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
        minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0.0)
        tr = pd.concat([high-low, (high-close.shift(1)).abs(), (low-close.shift(1)).abs()], axis=1).max(axis=1)
        atr = tr.rolling(14).mean()
        plus_di = 100 * plus_dm.rolling(14).mean() / atr
        minus_di = 100 * minus_dm.rolling(14).mean() / atr
        prepared["adx_14"] = (100 * (plus_di-minus_di).abs() / (plus_di+minus_di)).rolling(14).mean()
        low_14, high_14 = low.rolling(14).min(), high.rolling(14).max()
        prepared["stoch_k_14"] = 100 * (close-low_14) / (high_14-low_14)
        return prepared

    def _is_valid_row(self, row):
        required = ["Close", "High", "Low", "rsi_14", "sma_20", "ema_20", "macd", "bollinger_position", "adx_14", "stoch_k_14"]
        return all(not pd.isna(row[column]) for column in required)

    def _rate(self, count, total):
        return count / total if total else 0.0

    def _sample_quality(self, count):
        if count >= 50: return "HIGH"
        if count >= 20: return "MEDIUM"
        if count > 0: return "LOW"
        return "NO_SAMPLE"
