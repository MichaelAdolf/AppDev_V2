import tempfile
import unittest
from pathlib import Path

from stockmind.domain.history.daily_buy_signal import DailyBuySignal
from stockmind.infrastructure.history.daily_buy_signal_repository import DailyBuySignalRepository


class DailyBuySignalRepositoryTest(unittest.TestCase):
    def test_replace_and_load_profile_specific_signals(self):
        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "test.db")
            repository = DailyBuySignalRepository(database_path)
            signals = [
                DailyBuySignal(
                    symbol="AAPL",
                    profile_name="balanced",
                    analysis_period="1y",
                    trading_date="2026-01-02",
                    is_buy=True,
                    quality="HIGH",
                    quality_score=55.0,
                    core_setup_detected=True,
                    satisfied_rules=3,
                    required_rules=3,
                    reasons=["test"],
                    missing_rules=[],
                    entry_price=100.0,
                )
            ]
            repository.replace_for("AAPL", "balanced", "1y", signals)
            loaded = repository.load_by_symbol("AAPL", "balanced", "1y")
            self.assertEqual(len(loaded), 1)
            self.assertTrue(loaded[0].is_buy)
            self.assertEqual(loaded[0].profile_name, "balanced")


if __name__ == "__main__":
    unittest.main()
