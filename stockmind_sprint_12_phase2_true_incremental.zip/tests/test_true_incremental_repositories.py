import tempfile
import unittest
from pathlib import Path
from stockmind.domain.history.daily_buy_signal import DailyBuySignal
from stockmind.infrastructure.history.daily_buy_signal_repository import DailyBuySignalRepository

class TrueIncrementalRepositoryTest(unittest.TestCase):
    def test_daily_signal_upsert_does_not_delete_previous_day(self):
        with tempfile.TemporaryDirectory() as d:
            repo=DailyBuySignalRepository(str(Path(d)/"test.db"))
            def signal(day,buy):
                return DailyBuySignal("AAPL","balanced","5y",day,buy,"MEDIUM",50.0,buy,3,3,[],[],100.0)
            repo.upsert(signal("2026-09-24",False));repo.upsert(signal("2026-09-25",True))
            rows=repo.load_by_symbol("AAPL","balanced","5y")
            self.assertEqual(len(rows),2)
            self.assertEqual(repo.get_latest_date("AAPL","balanced","5y"),"2026-09-25")

if __name__=="__main__":unittest.main()
