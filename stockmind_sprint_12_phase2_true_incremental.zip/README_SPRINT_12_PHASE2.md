# Sprint 12 Phase 2: True Incremental Replay

## Änderungen

- Daily BUY Signals werden per UPSERT ergänzt, alte Tage bleiben unverändert.
- Historical Setups besitzen einen eindeutigen Index und werden per UPSERT aktualisiert.
- Nur unvollständige Historical Setup Outcomes werden erneut bewertet.
- Historical Opportunity Scores werden nicht neu berechnet; bei offenen Replay-Tagen
  wird ausschließlich das spätere 60-Tage-Validierungs-Outcome aktualisiert.
- DailySymbolRefreshUseCase verwendet ab jetzt den True-Incremental-Pfad.

## Bewusst verbleibende Arbeit

`RunAnalysisUseCase` ruft weiterhin die aktuelle AnalyzeStock-Pipeline auf. Diese lädt
aktuell selbst fünf Jahre Kursdaten und berechnet HistoricalSuccessEngine neu. Deshalb
ist nach diesem Zwischensprint ein weiterer Performanceblock vorhanden. Der historische
Opportunity Replay selbst wird im Daily-Pfad dagegen nicht mehr vollständig neu erzeugt.

BUY-Perioden werden aus den bereits persistierten Tages-BUY-Signalen neu gruppiert.
Das ist datenbankseitig leichtgewichtig und erhält die bestehende, getestete
3-Kalendertage-Gap-Semantik des BuyPeriodBuilder.

## Tests

```powershell
python -m unittest tests.test_true_incremental_repositories
python -m unittest tests.test_refresh_coordinator
```

## Benchmark

Vorher zuletzt beobachtet: ca. 9 Minuten für den Daily Run. Nach Integration bitte
`python scripts/run_daily_refresh.py` erneut ausführen und die ausgegebene Dauer als
neue Benchmark notieren.
