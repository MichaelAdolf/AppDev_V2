# FX1 Final Indicator Integration

This package directly replaces the actual uploaded `refresh_indicator_chart_data.py`; no patch script is required.

## Permanent behavior
- Indicator source is `EurMarketDataService().history(...).data_eur`.
- Empty or shorter-than-60-row histories return `[]` before TA calculations.
- Main refresh skips invalid symbols and continues.
- Repository refuses to erase existing indicator history when replacement points are empty.
- Incremental refresh uses the same EUR builders and preserves data on temporary Yahoo failures.

## Integration
Extract into project root and replace files.

## Tests
```powershell
python -m unittest tests.test_indicator_refresh_fx1 tests.test_eur_market_data_service tests.test_chart_data_repository_quality tests.test_productive_exit_engine
```

## One-time migration
```powershell
python scripts/rebuild_eur_market_data.py
```
Expected for MUV2: skip and continue. Daily `/refresh` thereafter automatically stores EUR OHLC and computes indicators from EUR prices.
