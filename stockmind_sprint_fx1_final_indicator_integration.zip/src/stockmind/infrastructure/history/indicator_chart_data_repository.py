import math
import sqlite3
from stockmind.domain.history.indicator_chart_point import IndicatorChartPoint
from stockmind.shared.config.settings import Settings

class IndicatorChartDataRepository:
    def __init__(self,database_path=None):self._database_path=database_path or Settings.load().database_path;self._initialize()
    def _connect(self):return sqlite3.connect(self._database_path)
    def _initialize(self):
        c=self._connect();c.execute("""CREATE TABLE IF NOT EXISTS indicator_chart_data(symbol TEXT NOT NULL,trading_date TEXT NOT NULL,rsi_14 REAL,macd REAL,macd_signal REAL,macd_histogram REAL,adx REAL,plus_di REAL,minus_di REAL,stoch_k REAL,stoch_d REAL,PRIMARY KEY(symbol,trading_date))""");c.commit();c.close()
    @staticmethod
    def _optional(value):
        if value is None:return None
        try:n=float(value);return n if math.isfinite(n) else None
        except (TypeError,ValueError):return None
    def replace_for_symbol(self,symbol,points):
        if not points:return
        c=self._connect();c.execute('DELETE FROM indicator_chart_data WHERE symbol=?',(symbol.upper(),));self._write(c,points);c.commit();c.close()
    def upsert_points(self,points):
        if not points:return
        c=self._connect();self._write(c,points);c.commit();c.close()
    def _write(self,c,points):
        c.executemany("""INSERT OR REPLACE INTO indicator_chart_data(symbol,trading_date,rsi_14,macd,macd_signal,macd_histogram,adx,plus_di,minus_di,stoch_k,stoch_d) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",[(p.symbol.upper(),p.trading_date,self._optional(p.rsi_14),self._optional(p.macd),self._optional(p.macd_signal),self._optional(p.macd_histogram),self._optional(p.adx),self._optional(p.plus_di),self._optional(p.minus_di),self._optional(p.stoch_k),self._optional(p.stoch_d)) for p in points])
    def get_latest_date(self,symbol):
        c=self._connect();r=c.execute('SELECT MAX(trading_date) FROM indicator_chart_data WHERE symbol=?',(symbol.upper(),)).fetchone();c.close();return r[0] if r else None
    def load_by_symbol(self,symbol):
        c=self._connect();rows=c.execute('SELECT symbol,trading_date,rsi_14,macd,macd_signal,macd_histogram,adx,plus_di,minus_di,stoch_k,stoch_d FROM indicator_chart_data WHERE symbol=? ORDER BY trading_date',(symbol.upper(),)).fetchall();c.close();return [IndicatorChartPoint(*row) for row in rows]
