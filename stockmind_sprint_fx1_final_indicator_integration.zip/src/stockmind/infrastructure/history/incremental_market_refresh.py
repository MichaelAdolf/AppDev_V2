from stockmind.infrastructure.history.chart_data_repository import ChartDataRepository
from stockmind.infrastructure.history.indicator_chart_data_repository import IndicatorChartDataRepository

try:
    from scripts.refresh_chart_data import build_chart_points
    from scripts.refresh_indicator_chart_data import build_indicator_points
except ModuleNotFoundError:
    from refresh_chart_data import build_chart_points
    from refresh_indicator_chart_data import build_indicator_points


def refresh_symbol(symbol: str, full: bool = False):
    chart_repo = ChartDataRepository()
    indicator_repo = IndicatorChartDataRepository()
    latest = chart_repo.get_latest_date(symbol)

    try:
        chart_all = build_chart_points(symbol)
        indicator_all = build_indicator_points(symbol)
    except Exception as error:
        print(f"Skipping market refresh for {symbol}: {error}")
        return

    if full or latest is None:
        # Never erase existing history because Yahoo temporarily returned no data.
        if chart_all:
            chart_repo.replace_for_symbol(symbol, chart_all)
        if indicator_all:
            indicator_repo.replace_for_symbol(symbol, indicator_all)
        return

    chart_points = [p for p in chart_all if p.trading_date > latest]
    indicator_points = [p for p in indicator_all if p.trading_date > latest]
    chart_repo.upsert_points(chart_points)
    indicator_repo.upsert_points(indicator_points)
