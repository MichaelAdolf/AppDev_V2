import math
import ta

from stockmind.application.currency.eur_market_data_service import EurMarketDataService
from stockmind.domain.history.indicator_chart_point import IndicatorChartPoint
from stockmind.infrastructure.history.indicator_chart_data_repository import IndicatorChartDataRepository
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository

MIN_HISTORY_ROWS = 60


def get_symbols():
    return WatchlistRepository().load_active_symbols()


def _to_optional_float(value):
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def calculate_rsi(data, window: int = 14):
    delta = data["Close"].diff()
    gain = delta.where(delta > 0, 0).rolling(window=window).mean()
    loss = -delta.where(delta < 0, 0).rolling(window=window).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))


def build_indicator_points(symbol: str) -> list[IndicatorChartPoint]:
    result = EurMarketDataService().history(symbol, period="5y")
    data = result.data_eur.copy()

    required = {"High", "Low", "Close"}
    if data.empty or len(data) < MIN_HISTORY_ROWS or not required.issubset(data.columns):
        return []

    # Remove unusable rows before handing the arrays to the TA library.
    data = data.dropna(subset=["High", "Low", "Close"]).copy()
    if len(data) < MIN_HISTORY_ROWS:
        return []

    data["RSI_14"] = calculate_rsi(data)
    ema_12 = data["Close"].ewm(span=12).mean()
    ema_26 = data["Close"].ewm(span=26).mean()
    data["MACD"] = ema_12 - ema_26
    data["MACD_Signal"] = data["MACD"].ewm(span=9).mean()
    data["MACD_Histogram"] = data["MACD"] - data["MACD_Signal"]

    adx = ta.trend.ADXIndicator(
        high=data["High"],
        low=data["Low"],
        close=data["Close"],
        window=14,
    )
    data["ADX"] = adx.adx()
    data["+DI"] = adx.adx_pos()
    data["-DI"] = adx.adx_neg()

    stoch = ta.momentum.StochasticOscillator(
        high=data["High"],
        low=data["Low"],
        close=data["Close"],
        window=14,
        smooth_window=3,
    )
    data["STOCH_K"] = stoch.stoch()
    data["STOCH_D"] = stoch.stoch_signal()

    return [
        IndicatorChartPoint(
            symbol=symbol.upper(),
            trading_date=index.date().isoformat(),
            rsi_14=_to_optional_float(row["RSI_14"]),
            macd=_to_optional_float(row["MACD"]),
            macd_signal=_to_optional_float(row["MACD_Signal"]),
            macd_histogram=_to_optional_float(row["MACD_Histogram"]),
            adx=_to_optional_float(row["ADX"]),
            plus_di=_to_optional_float(row["+DI"]),
            minus_di=_to_optional_float(row["-DI"]),
            stoch_k=_to_optional_float(row["STOCH_K"]),
            stoch_d=_to_optional_float(row["STOCH_D"]),
        )
        for index, row in data.iterrows()
    ]


def main():
    repository = IndicatorChartDataRepository()
    for symbol in get_symbols():
        print(f"Refreshing EUR indicator chart data for {symbol}")
        try:
            points = build_indicator_points(symbol)
        except Exception as error:
            print(f"Skipping indicator refresh for {symbol}: {error}")
            continue
        if not points:
            print(f"Skipping indicator refresh for {symbol}: no valid EUR market data")
            continue
        repository.replace_for_symbol(symbol=symbol, points=points)
    print("EUR indicator chart data refresh complete.")


if __name__ == "__main__":
    main()
