import unittest
from unittest.mock import patch
import pandas as pd
from scripts.refresh_indicator_chart_data import build_indicator_points
class IndicatorRefreshFx1Test(unittest.TestCase):
 @patch('scripts.refresh_indicator_chart_data.EurMarketDataService')
 def test_empty_eur_history_returns_empty_points(self,service):
  service.return_value.history.return_value.data_eur=pd.DataFrame();self.assertEqual(build_indicator_points('MUV2'),[])
 @patch('scripts.refresh_indicator_chart_data.EurMarketDataService')
 def test_short_eur_history_returns_empty_points(self,service):
  service.return_value.history.return_value.data_eur=pd.DataFrame({'High':[1]*20,'Low':[1]*20,'Close':[1]*20});self.assertEqual(build_indicator_points('TEST'),[])
if __name__=='__main__':unittest.main()
