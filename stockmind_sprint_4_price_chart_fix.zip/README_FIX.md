# Sprint 4 Price Chart Fix

Ersetzt im Projekt:

- `ui/components/price_chart.py`
- `ui/components/stock_detail_view.py`

Der Kurschart verwendet nun das neue BUY-Periodenmodell mit `outcome` statt des
alten Feldes `status`. Zugleich erhält der Chart das aktuell ausgewählte Profil.

Test:

```powershell
streamlit run ui/streamlit_app.py
```
