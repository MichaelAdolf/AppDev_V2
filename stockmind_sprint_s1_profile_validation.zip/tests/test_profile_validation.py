import unittest
from types import SimpleNamespace
from unittest.mock import patch
from stockmind.application.strategy.profile_validation_use_case import ProfileValidationUseCase
class ProfileValidationTest(unittest.TestCase):
 @patch('stockmind.application.strategy.profile_validation_use_case.DailyBuySignalRepository')
 @patch('stockmind.application.strategy.profile_validation_use_case.BuyPeriodRepository')
 def test_profile_metrics_and_roles(self,period_repo,signal_repo):
  def periods(symbol,profile,analysis):
   counts={'conservative':2,'balanced':3,'aggressive':4}[profile]
   hits={'conservative':2,'balanced':2,'aggressive':2}[profile]
   return [SimpleNamespace(is_complete=True,outcome='TARGET_HIT' if i<hits else 'NEGATIVE',target_hit=i<hits,days_to_target=20 if i<hits else None,max_gain_pct=9,max_drawdown_pct=-3 if i<hits else -8,calendar_duration_days=2,buy_signal_count=2) for i in range(counts)]
  period_repo.return_value.load_by_symbol.side_effect=periods
  signal_repo.return_value.load_by_symbol.side_effect=lambda s,p,a,b:[SimpleNamespace(is_buy=i<{'conservative':2,'balanced':3,'aggressive':4}[p],trading_date=str(i)) for i in range(10)]
  r=ProfileValidationUseCase().analyze('NVDA');by={x.profile_name:x for x in r.rows};self.assertEqual(by['conservative'].target_hit_rate,1);self.assertEqual(by['balanced'].period_count,3);self.assertEqual(by['aggressive'].profile_role_status,'ROLE_FIT')
if __name__=='__main__':unittest.main()
