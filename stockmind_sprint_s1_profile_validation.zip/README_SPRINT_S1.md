# Sprint S1 Profile Validation Foundation

## Inhalt
- Misst Conservative, Balanced und Aggressive je Aktie und über die aktive Watchlist.
- Kennzahlen: Perioden, vollständige Perioden, Target Hit, Below Target, Flat, Negative, Tage bis Ziel, Drawdown, BUY-Tage, Coverage, Periodendauer und Sample Quality.
- Prüft die gewünschte Rollenordnung: Conservative selektiv/präzise, Balanced mittig, Aggressive mehr Coverage.
- Keine Parameter werden verändert.

## Streamlit Integration
In `ui/components/portfolio_view.py` kann vorerst importiert werden:
```python
from components.entry_strategy_research_view import render as render_entry_research
```
Am einfachsten `render_entry_research()` am Ende des bestehenden Exit-Research-Tabs aufrufen oder einen neuen Tab `Entry Strategy Research` ergänzen. Für den späteren UX-Refresh wird Research in einen eigenen Hauptbereich verschoben.

## Tests
python -m unittest tests.test_profile_validation tests.test_historical_evidence_service tests.test_portfolio_intelligence
