from statistics import mean
from stockmind.application.strategy.profile_validation_use_case import ProfileValidationUseCase
from stockmind.application.strategy.models.profile_validation_result import CrossStockProfileValidationRow
from stockmind.infrastructure.watchlists.watchlist_repository import WatchlistRepository
class CrossStockProfileValidationUseCase:
 ROLES={'conservative':'High Precision','balanced':'Balanced Precision/Coverage','aggressive':'High Coverage'}
 def __init__(self,database_path=None):self._database_path=database_path
 def analyze(self):
  stocks=[x for x in WatchlistRepository(self._database_path).load_all() if x.active];results=[ProfileValidationUseCase(self._database_path).analyze(x.symbol) for x in stocks];rows=[]
  for profile in ('conservative','balanced','aggressive'):
   values=[next(x for x in r.rows if x.profile_name==profile) for r in results];eligible=[x for x in values if x.complete_period_count>0];complete=sum(x.complete_period_count for x in eligible);hits=sum(x.target_hit_count for x in eligible);quality='HIGH' if complete>=150 else 'MEDIUM' if complete>=60 else 'LOW' if complete else 'NO_SAMPLE'
   rows.append(CrossStockProfileValidationRow(profile,len(values),len(eligible),complete,hits,hits/complete if complete else 0,mean(x.period_count for x in values) if values else 0,mean(x.signal_coverage_rate for x in values) if values else 0,mean(x.median_days_to_target for x in eligible if x.median_days_to_target is not None) if any(x.median_days_to_target is not None for x in eligible) else None,mean(x.average_max_drawdown_pct for x in eligible if x.average_max_drawdown_pct is not None) if any(x.average_max_drawdown_pct is not None for x in eligible) else None,quality,self.ROLES[profile],'PENDING'))
  by={x.profile_name:x for x in rows};c,b,a=by['conservative'],by['balanced'],by['aggressive'];fit={'conservative':'ROLE_FIT' if c.weighted_target_hit_rate>=b.weighted_target_hit_rate and c.average_periods_per_stock<=b.average_periods_per_stock else 'ROLE_MISMATCH','balanced':'ROLE_FIT' if c.average_periods_per_stock<=b.average_periods_per_stock<=a.average_periods_per_stock else 'ROLE_MISMATCH','aggressive':'ROLE_FIT' if a.average_periods_per_stock>=b.average_periods_per_stock and a.average_signal_coverage_rate>=b.average_signal_coverage_rate else 'ROLE_MISMATCH'}
  return [CrossStockProfileValidationRow(**{**x.__dict__,'role_fit_status':fit[x.profile_name]}) for x in rows]
